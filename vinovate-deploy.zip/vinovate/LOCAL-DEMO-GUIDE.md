# 🎉 Wine Azone - Lokal Demo Guide

## ✅ Din demo körs nu!

### 🌐 Tillgängliga sidor (öppna i webbläsare):

#### **Huvudsidor:**
- **Landing Page:** http://localhost:3000
- **Sökfunktion:** http://localhost:3000/search
- **Skalbar Demo:** http://localhost:3000/demo-clean ⭐ **HUVUDDEMO**
- **Admin Panel:** http://localhost:3000/admin

#### **Extra demosidor:**
- **Enkel Demo:** http://localhost:3000/demo-simple
- **Full Demo:** http://localhost:3000/demo

#### **SEO & Metadata:**
- **Sitemap:** http://localhost:3000/sitemap.xml
- **Robots:** http://localhost:3000/robots.txt
- **Manifest:** http://localhost:3000/manifest.webmanifest
- **OG Image:** http://localhost:3000/opengraph-image

---

## 🎯 Rekommenderade sidor att visa

### **För investerare/partners:**
```
http://localhost:3000/demo-clean
```
Visar:
- ✅ Komplett översikt av plattformen
- ✅ Alla 6 huvudfunktioner med beskrivningar
- ✅ Skalningspotential (33 → 500+ importörer)
- ✅ 4 implementeringsfaser med tidsplan
- ✅ Teknisk stack och arkitektur
- ✅ Kostnadsuppskattningar

### **För slutanvändare:**
```
http://localhost:3000/search
```
Visar:
- ✅ Fungerande sökfunktion med 33 importörer
- ✅ Smart filtrering på land, druva, pris, etc.
- ✅ Beroende dropdowns som uppdateras dynamiskt
- ✅ Klickbara vinportföljer med tabellvy

### **För allmän översikt:**
```
http://localhost:3000
```
Visar:
- ✅ Landningssida med information
- ✅ Snabbsökning
- ✅ Senaste importörer
- ✅ Statistik över plattformen

---

## 🎬 Demoscenario

### **Scenario 1: Visa sökfunktionalitet**
1. Öppna: http://localhost:3000/search
2. Välj "Land: Frankrike"
3. Välj "Druva: Pinot Noir"
4. Se hur importörer filtreras
5. Klicka på antal viner för att se detaljer i popup

### **Scenario 2: Visa skalning**
1. Öppna: http://localhost:3000/demo-clean
2. Klicka på "Funktioner"-fliken
3. Visa alla 6 implementerade funktioner
4. Klicka på "Skalning"-fliken
5. Visa hur systemet kan växa till 500+ importörer

### **Scenario 3: Visa teknisk kompetens**
1. Öppna: http://localhost:3000/demo-clean
2. Klicka på "Teknisk Stack"-fliken
3. Visa kodstruktur och teknologier
4. Förklara PostgreSQL, API, caching

---

## 🖥️ Hantera lokal server

### **Starta servern:**
```bash
cd /Users/jorgenandersson/WineAzone
npm run dev
```

### **Stoppa servern:**
Tryck `Ctrl + C` i terminalen

### **Starta om servern:**
```bash
npm run dev
```

### **Kontrollera att den körs:**
```bash
curl http://localhost:3000
```

---

## 📱 Dela lokala demon

### **På samma nätverk:**
1. Hitta din IP-adress:
   ```bash
   ifconfig | grep "inet " | grep -v 127.0.0.1
   ```
2. Dela denna URL med andra på samma WiFi:
   ```
   http://[din-ip]:3000/demo-clean
   ```

### **För extern delning:**
Använd ngrok eller liknande:
```bash
# Installera ngrok
brew install ngrok

# Starta tunnel
ngrok http 3000
```
Du får en publik URL som: `https://xxxx.ngrok.io`

---

## 🎨 Anpassa demon

### **Ändra innehåll:**
- **Landing page:** `app/page.tsx`
- **Sökfunktion:** `app/search/page.tsx`
- **Skalbar demo:** `app/demo-clean/page.tsx`
- **Styling:** `app/globals.css`

### **Ändra data:**
- **Importörer & viner:** `data/importers.ts`

### **Efter ändringar:**
Spara filen - Next.js uppdaterar automatiskt (hot reload)!

---

## 📊 Statistik

### **Nuvarande data:**
- 33 svenska vinimportörer
- 112+ viner i databasen
- 12 länder representerade
- 72+ olika druvor
- Smart filtrering implementerad
- Responsiv design

---

## 🚀 Nästa steg efter demo

### **Om demon är lyckad:**

1. **Deploy till Vercel:**
   - Pushar koden till GitHub
   - Kopplar till Vercel
   - Live på internet på 5 minuter

2. **Skala upp databasen:**
   - Lägg till PostgreSQL databas
   - Aktivera API-endpoints
   - Implementera automatisk datainsamling

3. **Utöka funktionalitet:**
   - Admin-panel för CRUD
   - Automatisk scraping av importörer
   - Email-notifieringar
   - Analytics och monitoring

---

## 💡 Demo-tips

### **För bästa intryck:**
- ✅ Använd fullskärmsläge (F11)
- ✅ Börja med landing page, sedan demo-clean
- ✅ Visa live filtrering i search
- ✅ Öppna inspektören (F12) för att visa teknisk kvalitet
- ✅ Klicka runt för att visa responsivitet

### **Bra säljpoäng:**
- 🎯 "33 importörer redan implementerade"
- 📈 "Kan skalas till 500+ importörer"
- ⚡ "Sub-sekund svarstider med caching"
- 🛠️ "Modern teknisk stack"
- 💰 "Kostnadseffektiv drift"

---

## ❓ Felsökning

### **Port 3000 upptagen:**
```bash
# Hitta process på port 3000
lsof -ti:3000

# Döda processen
kill -9 $(lsof -ti:3000)

# Starta om
npm run dev
```

### **Ändringar syns inte:**
```bash
# Stoppa server (Ctrl + C)
# Rensa cache
rm -rf .next
# Starta om
npm run dev
```

### **npm-fel:**
```bash
# Installera om dependencies
rm -rf node_modules
npm install
npm run dev
```

---

## 🎉 Lycka till med demon!

**Alla sidor fungerar nu lokalt och är redo att visas!**

För frågor eller support, öppna denna guide! 📖
