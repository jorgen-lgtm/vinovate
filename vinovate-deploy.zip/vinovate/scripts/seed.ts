import { PrismaClient } from '@prisma/client';
import { importers } from '../data/importers';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Clear existing data
  await prisma.wine.deleteMany();
  await prisma.importer.deleteMany();

  // Seed importers and wines
  for (const importerData of importers) {
    const { portfolio, ...importerInfo } = importerData;
    
    const importer = await prisma.importer.create({
      data: {
        ...importerInfo,
        id: importerData.id,
        specialties: importerData.specialties || []
      }
    });

    console.log(`✅ Created importer: ${importer.name}`);

    // Create wines for this importer
    for (const wineData of portfolio) {
      await prisma.wine.create({
        data: {
          ...wineData,
          id: wineData.id,
          importerId: importer.id,
          grapeVarieties: wineData.grapeVarieties || []
        }
      });
    }

    console.log(`  📦 Created ${portfolio.length} wines`);
  }

  // Get final stats
  const importerCount = await prisma.importer.count();
  const wineCount = await prisma.wine.count();

  console.log(`\n🎉 Seeding completed!`);
  console.log(`📊 Created ${importerCount} importers and ${wineCount} wines`);
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
