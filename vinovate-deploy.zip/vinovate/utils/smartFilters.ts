import { Importer, SearchFilters } from '@/types';

// Få tillgängliga länder baserat på andra valda filter
export const getAvailableCountries = (
  importers: Importer[],
  filters: SearchFilters
): string[] => {
  const countries = new Set<string>();
  
  // Filtrera importörer först baserat på searchTerm och försäljningskanaler
  const filteredImporters = importers.filter(importer => {
    if (filters.sellsToRestaurants !== undefined && 
        importer.sellsToRestaurants !== filters.sellsToRestaurants) {
      return false;
    }
    
    if (filters.sellsToPrivate !== undefined && 
        importer.sellsToPrivate !== filters.sellsToPrivate) {
      return false;
    }

    // Filtrera på searchTerm om det finns
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const matchesName = importer.name.toLowerCase().includes(term);
      const matchesDescription = importer.description.toLowerCase().includes(term);
      const matchesSpecialty = importer.specialties.some(s => 
        s.toLowerCase().includes(term)
      );
      
      if (!matchesName && !matchesDescription && !matchesSpecialty) {
        return false;
      }
    }

    return true;
  });
  
  filteredImporters.forEach(importer => {
    importer.portfolio.forEach(wine => {
      // Kolla andra filter
      if (filters.region && wine.region !== filters.region) return;
      if (filters.type && wine.type !== filters.type) return;
      if (filters.priceRange && wine.priceRange !== filters.priceRange) return;
      if (filters.grapeVariety && !wine.grapeVarieties.includes(filters.grapeVariety)) return;
      
      countries.add(wine.country);
    });
  });
  
  return Array.from(countries).sort();
};

// Få tillgängliga regioner baserat på andra valda filter
export const getAvailableRegions = (
  importers: Importer[],
  filters: SearchFilters
): string[] => {
  const regions = new Set<string>();
  
  // Filtrera importörer först baserat på searchTerm och försäljningskanaler
  const filteredImporters = importers.filter(importer => {
    if (filters.sellsToRestaurants !== undefined && 
        importer.sellsToRestaurants !== filters.sellsToRestaurants) {
      return false;
    }
    
    if (filters.sellsToPrivate !== undefined && 
        importer.sellsToPrivate !== filters.sellsToPrivate) {
      return false;
    }

    // Filtrera på searchTerm om det finns
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const matchesName = importer.name.toLowerCase().includes(term);
      const matchesDescription = importer.description.toLowerCase().includes(term);
      const matchesSpecialty = importer.specialties.some(s => 
        s.toLowerCase().includes(term)
      );
      
      if (!matchesName && !matchesDescription && !matchesSpecialty) {
        return false;
      }
    }

    return true;
  });
  
  filteredImporters.forEach(importer => {
    importer.portfolio.forEach(wine => {
      if (filters.country && wine.country !== filters.country) return;
      if (filters.type && wine.type !== filters.type) return;
      if (filters.priceRange && wine.priceRange !== filters.priceRange) return;
      if (filters.grapeVariety && !wine.grapeVarieties.includes(filters.grapeVariety)) return;
      
      regions.add(wine.region);
    });
  });
  
  return Array.from(regions).sort();
};

// Få tillgängliga druvor baserat på andra valda filter
export const getAvailableGrapeVarieties = (
  importers: Importer[],
  filters: SearchFilters
): string[] => {
  const varieties = new Set<string>();
  
  // Filtrera importörer först baserat på searchTerm och försäljningskanaler
  const filteredImporters = importers.filter(importer => {
    if (filters.sellsToRestaurants !== undefined && 
        importer.sellsToRestaurants !== filters.sellsToRestaurants) {
      return false;
    }
    
    if (filters.sellsToPrivate !== undefined && 
        importer.sellsToPrivate !== filters.sellsToPrivate) {
      return false;
    }

    // Filtrera på searchTerm om det finns
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const matchesName = importer.name.toLowerCase().includes(term);
      const matchesDescription = importer.description.toLowerCase().includes(term);
      const matchesSpecialty = importer.specialties.some(s => 
        s.toLowerCase().includes(term)
      );
      
      if (!matchesName && !matchesDescription && !matchesSpecialty) {
        return false;
      }
    }

    return true;
  });
  
  filteredImporters.forEach(importer => {
    importer.portfolio.forEach(wine => {
      if (filters.country && wine.country !== filters.country) return;
      if (filters.region && wine.region !== filters.region) return;
      if (filters.type && wine.type !== filters.type) return;
      if (filters.priceRange && wine.priceRange !== filters.priceRange) return;
      
      wine.grapeVarieties.forEach(variety => varieties.add(variety));
    });
  });
  
  return Array.from(varieties).sort();
};

// Få tillgängliga vintyper baserat på andra valda filter
export const getAvailableTypes = (
  importers: Importer[],
  filters: SearchFilters
): string[] => {
  const types = new Set<string>();
  
  // Filtrera importörer först baserat på searchTerm och försäljningskanaler
  const filteredImporters = importers.filter(importer => {
    if (filters.sellsToRestaurants !== undefined && 
        importer.sellsToRestaurants !== filters.sellsToRestaurants) {
      return false;
    }
    
    if (filters.sellsToPrivate !== undefined && 
        importer.sellsToPrivate !== filters.sellsToPrivate) {
      return false;
    }

    // Filtrera på searchTerm om det finns
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const matchesName = importer.name.toLowerCase().includes(term);
      const matchesDescription = importer.description.toLowerCase().includes(term);
      const matchesSpecialty = importer.specialties.some(s => 
        s.toLowerCase().includes(term)
      );
      
      if (!matchesName && !matchesDescription && !matchesSpecialty) {
        return false;
      }
    }

    return true;
  });
  
  filteredImporters.forEach(importer => {
    importer.portfolio.forEach(wine => {
      if (filters.country && wine.country !== filters.country) return;
      if (filters.region && wine.region !== filters.region) return;
      if (filters.priceRange && wine.priceRange !== filters.priceRange) return;
      if (filters.grapeVariety && !wine.grapeVarieties.includes(filters.grapeVariety)) return;
      
      types.add(wine.type);
    });
  });
  
  return Array.from(types).sort();
};

// Få tillgängliga prisintervall baserat på andra valda filter
export const getAvailablePriceRanges = (
  importers: Importer[],
  filters: SearchFilters
): string[] => {
  const priceOrder = ['Under 100kr', '100-200kr', '200-400kr', 'Över 400kr'];
  const prices = new Set<string>();
  
  // Filtrera importörer först baserat på searchTerm och försäljningskanaler
  const filteredImporters = importers.filter(importer => {
    if (filters.sellsToRestaurants !== undefined && 
        importer.sellsToRestaurants !== filters.sellsToRestaurants) {
      return false;
    }
    
    if (filters.sellsToPrivate !== undefined && 
        importer.sellsToPrivate !== filters.sellsToPrivate) {
      return false;
    }

    // Filtrera på searchTerm om det finns
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const matchesName = importer.name.toLowerCase().includes(term);
      const matchesDescription = importer.description.toLowerCase().includes(term);
      const matchesSpecialty = importer.specialties.some(s => 
        s.toLowerCase().includes(term)
      );
      
      if (!matchesName && !matchesDescription && !matchesSpecialty) {
        return false;
      }
    }

    return true;
  });
  
  filteredImporters.forEach(importer => {
    importer.portfolio.forEach(wine => {
      if (filters.country && wine.country !== filters.country) return;
      if (filters.region && wine.region !== filters.region) return;
      if (filters.type && wine.type !== filters.type) return;
      if (filters.grapeVariety && !wine.grapeVarieties.includes(filters.grapeVariety)) return;
      
      prices.add(wine.priceRange);
    });
  });
  
  return priceOrder.filter(price => prices.has(price));
};

