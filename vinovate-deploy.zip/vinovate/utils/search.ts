import { Importer, SearchFilters } from '@/types';

export const searchImporters = (
  importers: Importer[],
  filters: SearchFilters
): Importer[] => {
  return importers.filter(importer => {
    // Filter by restaurant/private sales
    if (filters.sellsToRestaurants !== undefined && 
        importer.sellsToRestaurants !== filters.sellsToRestaurants) {
      return false;
    }
    
    if (filters.sellsToPrivate !== undefined && 
        importer.sellsToPrivate !== filters.sellsToPrivate) {
      return false;
    }

    // Filter by search term in importer name or description
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const matchesName = importer.name.toLowerCase().includes(term);
      const matchesDescription = importer.description.toLowerCase().includes(term);
      const matchesSpecialty = importer.specialties.some(s => 
        s.toLowerCase().includes(term)
      );
      
      if (!matchesName && !matchesDescription && !matchesSpecialty) {
        return false;
      }
    }

    // Check if importer has wines matching the criteria
    const hasMatchingWines = importer.portfolio.some(wine => {
      if (filters.country && wine.country !== filters.country) {
        return false;
      }
      
      if (filters.region && wine.region !== filters.region) {
        return false;
      }
      
      if (filters.type && wine.type !== filters.type) {
        return false;
      }
      
      if (filters.priceRange && wine.priceRange !== filters.priceRange) {
        return false;
      }
      
      if (filters.grapeVariety && 
          !wine.grapeVarieties.includes(filters.grapeVariety)) {
        return false;
      }
      
      return true;
    });

    // If wine-specific filters are set, only return importers with matching wines
    if (filters.country || filters.region || filters.type || 
        filters.priceRange || filters.grapeVariety) {
      return hasMatchingWines;
    }

    return true;
  });
};

export const getMatchingWinesCount = (
  importer: Importer,
  filters: SearchFilters
): number => {
  return importer.portfolio.filter(wine => {
    if (filters.country && wine.country !== filters.country) {
      return false;
    }
    
    if (filters.region && wine.region !== filters.region) {
      return false;
    }
    
    if (filters.type && wine.type !== filters.type) {
      return false;
    }
    
    if (filters.priceRange && wine.priceRange !== filters.priceRange) {
      return false;
    }
    
    if (filters.grapeVariety && 
        !wine.grapeVarieties.includes(filters.grapeVariety)) {
      return false;
    }
    
    return true;
  }).length;
};

