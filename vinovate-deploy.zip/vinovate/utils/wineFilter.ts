import { Wine, SearchFilters } from '@/types';

export const getMatchingWines = (
  wines: Wine[],
  filters: SearchFilters
): Wine[] => {
  return wines.filter(wine => {
    if (filters.country && wine.country !== filters.country) {
      return false;
    }
    
    if (filters.region && wine.region !== filters.region) {
      return false;
    }
    
    if (filters.type && wine.type !== filters.type) {
      return false;
    }
    
    if (filters.priceRange && wine.priceRange !== filters.priceRange) {
      return false;
    }
    
    if (filters.grapeVariety && 
        !wine.grapeVarieties.includes(filters.grapeVariety)) {
      return false;
    }
    
    return true;
  });
};

