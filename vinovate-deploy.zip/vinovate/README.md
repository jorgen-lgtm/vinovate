# 🍷 Wine Azone

En modern webbapplikation för att hitta och utforska vinimportörer i Sverige. Appen innehåller riktiga svenska vinimportörer med länkar till deras faktiska hemsidor.

## Funktioner

✨ **Sök efter vinimportörer** baserat på:
- Land (Italien, Frankrike, Spanien, Schweiz, Österrike, Georgien, Portugal, m.m.)
- Region (Piemonte, Bordeaux, Rioja, Rhône, Jura, Friaul, m.m.)
- Druva (Nebbiolo, Chardonnay, Tempranillo, Syrah, Gamay, Grüner Veltliner, m.m.)
- Vintyp (Rött, Vitt, Rosé, Mousserande, Dessert, Starkvin)
- Prisintervall (Under 100kr - Över 400kr)
- Försäljning till restauranger och/eller privatpersoner
- Fritext-sökning på importörens namn, beskrivning eller specialiteter

🔍 **Intelligent filtrering** - Se direkt hur många viner från varje importör som matchar dina kriterier

🔗 **Direktlänkar** till importörernas hemsidor där du kan genomföra köp

📱 **Responsiv design** - Fungerar perfekt på alla enheter

## Inkluderade Vinimportörer

Appen innehåller för närvarande **33 riktiga svenska vinimportörer och vinhandlare**, inklusive flera från Munskänkarnas lista och [Vinodino](https://vinodino.se/vinimportorer/):

### Traditionella Importörer (säljer till restauranger och/eller privatpersoner):
1. **Vinoliv Import** - Italienska kvalitetsviner
2. **Wine to Sweden** - Italienska viner från mindre vingårdar
3. **Jordmånen** - Naturviner utan tillsatser
4. **En halvpall AB** - Italienska hantverksviner
5. **VD Wines** - Sällsynta och naturnära viner
6. **Allégresse AB** - Naturviner och ekologiska viner
7. **Gullberg by Stockwine** - Brett sortiment av kvalitetsviner
8. **Skoogs Vinhandel** - Över 800 artiklar, privatimport via Systembolaget
9. **Sanler Wine** - Småskaliga, personligt utvalda viner
10. **Schweizisk Vinimport** - Kvalitetsviner från Schweiz
11. **Vinonista** - Hantverksviner med leverans från Danmark
12. **Louie Louie Wine** - Vinbar och naturvinsimportör
13. **Barrique** - Vinbar och butik i Stockholm
14. **Vinupplevelser Sverige AB** - Malmöbaserad, fokus på spanska viner
15. **Vingruppen i Norden AB** - Sammanslutning med omfattande sortiment
16. **Handpicked Wines Sweden AB** - Handplockade viner från små producenter
17. **C & E Gastro Import AB** - Gastronomiska viner från Frankrike och Spanien
18. **Vänersborgs Vinagentur** - Portugisiska och spanska viner
19. **Budbreak** - Hantverksmässiga och naturliga viner

### Restaurangfokus (säljer främst till restauranger):
20. **Gastrodev Vin & Sprit AB** - En av Sveriges större restaurangimportörer
21. **Wine Trade Sweden AB** - Distribution av internationella viner

### Online Vinhandel (hemleverans direkt till privatpersoner):
22. **Vinoteket** - Sveriges största vinbutik online
23. **Winefinder** - Nordisk kvalitetsvinhandel
24. **Vinfolket** - Bra viner till bra priser
25. **Bombwine** - Kontinuerliga vinsläpp från restaurangproducenter
26. **Vinlådan** - Ekologiska vinlådor för varje årstid
27. **Supervin** - Dansk vinhandel med leverans till Sverige
28. **Fanwine** - Vinprojekt och direktkontakt med producenter

### Stora Aktörer (från Vinodino):
29. **Oenoforos Group** - En av Sveriges största vinimportörer
30. **WinePartners Nordic AB** - Brett sortiment med kvalitetsfokus
31. **The WineAgency** - Kvalitetsviner från stora namn till boutique-vinerier
32. **WineWorld** - Viner från både gamla och nya världen
33. **Divine Wines** - Ekologiska, biodynamiska och naturviner

Alla hemsidor är riktiga och klickbara! Filtreringen visar endast importörer som har viner som matchar dina valda kriterier.

## Kom igång

### Installation

```bash
# Installera beroenden
npm install
```

### Utveckling

```bash
# Starta utvecklingsservern
npm run dev
```

Öppna [http://localhost:3000](http://localhost:3000) i din webbläsare.

### Produktion

```bash
# Bygg för produktion
npm run build

# Starta produktionsservern
npm start
```

## Teknisk stack

- **Next.js 14** - React-ramverk med server-side rendering
- **TypeScript** - Typsäker JavaScript
- **React Hooks** - Modern state management
- **CSS3** - Modern styling med gradients och animationer

## Projektstruktur

```
WineAzone/
├── app/
│   ├── globals.css      # Global styling
│   ├── layout.tsx       # Root layout
│   └── page.tsx         # Huvudsida med sökfunktion
├── data/
│   └── importers.ts     # Data för vinimportörer
├── types/
│   └── index.ts         # TypeScript-typer
├── utils/
│   └── search.ts        # Söklogik och filtrering
└── package.json
```

## Lägg till nya importörer

Redigera filen `data/importers.ts` för att lägga till fler vinimportörer:

```typescript
{
  id: 'unique-id',
  name: 'Importörens namn',
  website: 'https://example.com',
  description: 'Beskrivning av importören',
  contactEmail: 'info@example.com',
  contactPhone: '08-123 45 67',
  sellsToRestaurants: true,
  sellsToPrivate: true,
  specialties: ['Specialitet 1', 'Specialitet 2'],
  portfolio: [
    // Lägg till viner här
  ]
}
```

## Licens

Detta är ett öppen källkodsprojekt skapat för att hjälpa svenska vinälskare att hitta rätt importör.

## Support

För frågor eller förslag, kontakta projektets underhållare.

---

Skål! 🍷

