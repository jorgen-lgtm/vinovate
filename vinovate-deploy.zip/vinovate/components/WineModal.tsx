'use client';

import { Wine } from '@/types';

interface WineModalProps {
  isOpen: boolean;
  onClose: () => void;
  wines: Wine[];
  importerName: string;
  totalWines: number;
}

export default function WineModal({ isOpen, onClose, wines, importerName, totalWines }: WineModalProps) {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div className="modal-title-section">
            <h2>{importerName}</h2>
            <div className="modal-stats">
              <span className="stat-item">
                <strong>{wines.length}</strong> matchande viner
              </span>
              <span className="stat-divider">•</span>
              <span className="stat-item">
                <strong>{totalWines}</strong> totalt i portföljen
              </span>
            </div>
          </div>
          <button className="modal-close" onClick={onClose}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        <div className="table-container">
          <div className="table-header">
            <h3>Matchande viner</h3>
            <div className="table-controls">
              <span className="results-count">{wines.length} viner</span>
            </div>
          </div>
          <table className="wine-table">
            <thead>
              <tr>
                <th className="col-name">Vin</th>
                <th className="col-type">Typ</th>
                <th className="col-country">Land</th>
                <th className="col-region">Region</th>
                <th className="col-grapes">Druvor</th>
                <th className="col-price">Pris</th>
                <th className="col-year">År</th>
              </tr>
            </thead>
            <tbody>
              {wines.map((wine) => (
                <tr key={wine.id}>
                  <td className="wine-name-cell">
                    <strong>{wine.name}</strong>
                    {wine.description && (
                      <div className="wine-desc">{wine.description}</div>
                    )}
                  </td>
                  <td>
                    <span className={`type-badge type-${wine.type.toLowerCase()}`}>
                      {wine.type}
                    </span>
                  </td>
                  <td>{wine.country}</td>
                  <td>{wine.region}</td>
                  <td className="grapes-cell">
                    {wine.grapeVarieties.join(', ')}
                  </td>
                  <td className="price-cell">{wine.priceRange}</td>
                  <td className="year-cell">{wine.year || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

