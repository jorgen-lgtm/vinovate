import { Importer } from '@/types';

export const importers: Importer[] = [
  {
    id: '1',
    name: 'Vinoliv Import',
    website: 'https://www.vinoliv.se',
    description: 'Specialiserar sig på högkvalitativa italienska viner och levererar till både Systembolaget och restauranger.',
    contactEmail: 'info@vinoliv.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Italienska viner', 'Kvalitetsviner', 'Systembolaget'],
    portfolio: [
      {
        id: 'w1',
        name: 'Barolo DOCG',
        country: 'Italien',
        region: 'Piemonte',
        grapeVarieties: ['Nebbiolo'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2018,
        description: 'Ett klassiskt Barolo med djup smak av körsbär och tryffel.'
      },
      {
        id: 'w2',
        name: 'Chianti Classico',
        country: 'Italien',
        region: 'Toscana',
        grapeVarieties: ['Sangiovese'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Klassiskt italienskt rödvin med god syra och fruktighet.'
      },
      {
        id: 'w3',
        name: 'Vermentino di Sardegna',
        country: 'Italien',
        region: 'Sardinien',
        grapeVarieties: ['Vermentino'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Fräscht vitt vin med citrus och mineralitet.'
      }
    ]
  },
  {
    id: '2',
    name: 'Wine to Sweden',
    website: 'https://winetosweden.se',
    description: 'Fokuserar på italienska kvalitetsviner från mindre och medelstora vingårdar, med försäljning via privatimport och till restauranger.',
    contactEmail: 'info@winetosweden.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Italienska viner', 'Små producenter', 'Privatimport'],
    portfolio: [
      {
        id: 'w4',
        name: 'Brunello di Montalcino',
        country: 'Italien',
        region: 'Toscana',
        grapeVarieties: ['Sangiovese'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2017,
        description: 'Kraftfullt och elegant rödvin med stor lagringspotential.'
      },
      {
        id: 'w5',
        name: 'Soave Classico',
        country: 'Italien',
        region: 'Veneto',
        grapeVarieties: ['Garganega'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Fräscht och mineraliskt vitt vin med mandel och citrus.'
      },
      {
        id: 'w6',
        name: 'Prosecco Superiore',
        country: 'Italien',
        region: 'Veneto',
        grapeVarieties: ['Glera'],
        type: 'Mousserande',
        priceRange: '100-200kr',
        description: 'Friskt och fruktigt mousserande med blommiga toner.'
      }
    ]
  },
  {
    id: '3',
    name: 'Jordmånen',
    website: 'https://www.jordmanen.com',
    description: 'Stockholmsbaserad importör med fokus på naturviner utan tillsatser.',
    contactEmail: 'hej@jordmanen.com',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Naturviner', 'Ekologiska viner', 'Biodynamiska viner'],
    portfolio: [
      {
        id: 'w7',
        name: 'Orange Wine Georgien',
        country: 'Georgien',
        region: 'Kakheti',
        grapeVarieties: ['Rkatsiteli'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Spännande orange wine med amforalagrning och lång skalkontakt.'
      },
      {
        id: 'w8',
        name: 'Pet Nat Loire',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Chenin Blanc'],
        type: 'Mousserande',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Naturligt mousserande vin med äppel och honung.'
      },
      {
        id: 'w9',
        name: 'Gamay Beaujolais',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Gamay'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Lätt och friskt rödvin med röda bär och blommiga toner.'
      }
    ]
  },
  {
    id: '4',
    name: 'En halvpall AB',
    website: 'https://enhalvpall.se',
    description: 'Stockholmsbaserad importör som specialiserar sig på italienska hantverksviner.',
    contactEmail: 'info@enhalvpall.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Italienska hantverksviner', 'Små producenter', 'Terroir'],
    portfolio: [
      {
        id: 'w10',
        name: 'Etna Rosso',
        country: 'Italien',
        region: 'Sicilien',
        grapeVarieties: ['Nerello Mascalese'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Elegant vulkaniskt vin med mineralitet och röda bär.'
      },
      {
        id: 'w11',
        name: 'Fiano di Avellino',
        country: 'Italien',
        region: 'Kampanien',
        grapeVarieties: ['Fiano'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Komplext vitt vin med honung, nötter och mineralitet.'
      },
      {
        id: 'w12',
        name: 'Amarone della Valpolicella',
        country: 'Italien',
        region: 'Veneto',
        grapeVarieties: ['Corvina', 'Rondinella'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2016,
        description: 'Kraftfullt och koncentrerat vin från torkade druvor.'
      }
    ]
  },
  {
    id: '5',
    name: 'VD Wines',
    website: 'https://vdwines.se',
    description: 'Specialiserar sig på sällsynta och naturnära viner från olika delar av världen.',
    contactEmail: 'info@vdwines.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Sällsynta viner', 'Naturviner', 'Unika producenter'],
    portfolio: [
      {
        id: 'w13',
        name: 'Jura Chardonnay',
        country: 'Frankrike',
        region: 'Jura',
        grapeVarieties: ['Chardonnay'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Oxidativt lagrat vitt vin med nötter och kardemumma.'
      },
      {
        id: 'w14',
        name: 'Jurançon Sec',
        country: 'Frankrike',
        region: 'Sydväst',
        grapeVarieties: ['Gros Manseng'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Aromatiskt och fräscht vitt vin med tropiska frukter.'
      },
      {
        id: 'w15',
        name: 'Trousseau Arbois',
        country: 'Frankrike',
        region: 'Jura',
        grapeVarieties: ['Trousseau'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Lätt och elegant rödvin med vild jordgubbe och kryddor.'
      }
    ]
  },
  {
    id: '6',
    name: 'Allégresse AB',
    website: 'https://www.allegresse.se',
    description: 'Malmöbaserad vinimportör med fokus på naturviner och ekologiska viner.',
    contactEmail: 'info@allegresse.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Naturviner', 'Ekologiska viner', 'Orange vin'],
    portfolio: [
      {
        id: 'w16',
        name: 'Friaul Orange Wine',
        country: 'Italien',
        region: 'Friaul',
        grapeVarieties: ['Friulano'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Intensivt orange wine med aprikoston och tanniner.'
      },
      {
        id: 'w17',
        name: 'Pinot Noir Alsace',
        country: 'Frankrike',
        region: 'Alsace',
        grapeVarieties: ['Pinot Noir'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Elegant och lätt rödvin med röda bär och kryddor.'
      },
      {
        id: 'w18',
        name: 'Grüner Veltliner',
        country: 'Österrike',
        region: 'Wachau',
        grapeVarieties: ['Grüner Veltliner'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Fräscht vitt vin med vit peppar och citrus.'
      }
    ]
  },
  {
    id: '7',
    name: 'Gullberg by Stockwine',
    website: 'https://gullbergbystockwine.se',
    description: 'Stockholmsbaserad importör med brett sortiment av kvalitetsviner från hela världen.',
    contactEmail: 'info@gullberg.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Brett sortiment', 'Kvalitetsviner', 'Klassiska regioner'],
    portfolio: [
      {
        id: 'w19',
        name: 'Bordeaux Grand Cru',
        country: 'Frankrike',
        region: 'Bordeaux',
        grapeVarieties: ['Cabernet Sauvignon', 'Merlot'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2018,
        description: 'Prestigefyllt Bordeaux med stor lagringspotential.'
      },
      {
        id: 'w20',
        name: 'Chablis Premier Cru',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Chardonnay'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Elegant vitt vin med mineral och citrus.'
      },
      {
        id: 'w21',
        name: 'Champagne Brut',
        country: 'Frankrike',
        region: 'Champagne',
        grapeVarieties: ['Chardonnay', 'Pinot Noir', 'Pinot Meunier'],
        type: 'Mousserande',
        priceRange: '200-400kr',
        description: 'Elegant champagne med fin perlage och briochetoner.'
      }
    ]
  },
  {
    id: '8',
    name: 'Skoogs Vinhandel',
    website: 'https://www.skoogsvinhandel.se',
    description: 'Brett sortiment av över 800 artiklar med möjlighet till privatimport via Systembolaget.',
    contactEmail: 'info@skoogsvinhandel.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Brett sortiment', 'Privatimport', 'Värde för pengarna'],
    portfolio: [
      {
        id: 'w22',
        name: 'Rioja Gran Reserva',
        country: 'Spanien',
        region: 'Rioja',
        grapeVarieties: ['Tempranillo', 'Garnacha'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2016,
        description: 'Elegant och vällagrat rödvin med toner av vanilj och läder.'
      },
      {
        id: 'w23',
        name: 'Albariño Rías Baixas',
        country: 'Spanien',
        region: 'Galicien',
        grapeVarieties: ['Albariño'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Fräscht och fruktigt vitt vin perfekt till skaldjur.'
      },
      {
        id: 'w24',
        name: 'Vintage Port',
        country: 'Portugal',
        region: 'Douro',
        grapeVarieties: ['Touriga Nacional', 'Touriga Franca'],
        type: 'Starkvin',
        priceRange: 'Över 400kr',
        year: 2017,
        description: 'Kraftfull och söt portvinsklassiker.'
      }
    ]
  },
  {
    id: '9',
    name: 'Sanler Wine',
    website: 'https://sanlerwine.se',
    description: 'Fokuserar på småskaliga och personliga vinupplevelser med noga utvalda viner.',
    contactEmail: 'hello@sanlerwine.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Små producenter', 'Personligt urval', 'Hantverksviner'],
    portfolio: [
      {
        id: 'w25',
        name: 'Châteauneuf-du-Pape',
        country: 'Frankrike',
        region: 'Rhône',
        grapeVarieties: ['Grenache', 'Syrah', 'Mourvèdre'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2019,
        description: 'Kraftfullt och komplext rödvin med mörka bär och kryddor.'
      },
      {
        id: 'w26',
        name: 'Condrieu',
        country: 'Frankrike',
        region: 'Rhône',
        grapeVarieties: ['Viognier'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Aromatiskt vitt vin med aprikos och blommor.'
      },
      {
        id: 'w27',
        name: 'Côte-Rôtie',
        country: 'Frankrike',
        region: 'Rhône',
        grapeVarieties: ['Syrah'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2018,
        description: 'Elegant och kraftfullt rödvin med violer och peppar.'
      }
    ]
  },
  {
    id: '10',
    name: 'Schweizisk Vinimport',
    website: 'https://schweiziskvinimport.se',
    description: 'Importerar kvalitetsviner från Schweiz till den svenska marknaden.',
    contactEmail: 'info@schweiziskvinimport.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Schweiziska viner', 'Alpviner', 'Unika druvor'],
    portfolio: [
      {
        id: 'w28',
        name: 'Chasselas Lavaux',
        country: 'Schweiz',
        region: 'Vaud',
        grapeVarieties: ['Chasselas'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Delikat vitt vin med mineralitet och citrus.'
      },
      {
        id: 'w29',
        name: 'Pinot Noir Valais',
        country: 'Schweiz',
        region: 'Valais',
        grapeVarieties: ['Pinot Noir'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Elegant rödvin med röda bär och fin struktur.'
      },
      {
        id: 'w30',
        name: 'Petite Arvine',
        country: 'Schweiz',
        region: 'Valais',
        grapeVarieties: ['Petite Arvine'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Unikt schweiziskt vin med grapefrukt och mineralitet.'
      }
    ]
  },
  {
    id: '11',
    name: 'Vinoteket',
    website: 'https://vinoteket.se',
    description: 'En av Sveriges största vinbutiker online med brett sortiment och hemleverans över hela Sverige.',
    contactEmail: 'kundservice@vinoteket.se',
    sellsToRestaurants: false,
    sellsToPrivate: true,
    specialties: ['Brett sortiment', 'Hemleverans', 'Distanshandel'],
    portfolio: [
      {
        id: 'w31',
        name: 'Montepulciano d\'Abruzzo',
        country: 'Italien',
        region: 'Abruzzo',
        grapeVarieties: ['Montepulciano'],
        type: 'Rött',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Fruktig och rund italienare med mörka bär.'
      },
      {
        id: 'w32',
        name: 'Grüner Veltliner Kamptal',
        country: 'Österrike',
        region: 'Kamptal',
        grapeVarieties: ['Grüner Veltliner'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Krispigt österrikiskt vitt vin med peppar och citrus.'
      },
      {
        id: 'w33',
        name: 'Cava Brut Reserva',
        country: 'Spanien',
        region: 'Penedès',
        grapeVarieties: ['Macabeo', 'Xarel-lo', 'Parellada'],
        type: 'Mousserande',
        priceRange: '100-200kr',
        description: 'Spanskt mousserande med fin perlage och goda toner.'
      }
    ]
  },
  {
    id: '12',
    name: 'Winefinder',
    website: 'https://www.winefinder.se',
    description: 'Nordisk nätbutik för kvalitetsviner med hemleverans till Sverige. Aktiva sedan 2007.',
    contactEmail: 'info@winefinder.se',
    sellsToRestaurants: false,
    sellsToPrivate: true,
    specialties: ['Kvalitetsviner', 'Onlinehandel', 'Dansk vinhandel'],
    portfolio: [
      {
        id: 'w34',
        name: 'Barossa Shiraz',
        country: 'Australien',
        region: 'Barossa Valley',
        grapeVarieties: ['Shiraz'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Kraftfull australisk shiraz med mörka bär och kryddor.'
      },
      {
        id: 'w35',
        name: 'Margaret River Chardonnay',
        country: 'Australien',
        region: 'Margaret River',
        grapeVarieties: ['Chardonnay'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Elegant australisk chardonnay med tropisk frukt.'
      },
      {
        id: 'w36',
        name: 'Pinot Noir Martinborough',
        country: 'Nya Zeeland',
        region: 'Wairarapa',
        grapeVarieties: ['Pinot Noir'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Delikat pinot noir med röda bär och silkeslen textur.'
      }
    ]
  },
  {
    id: '13',
    name: 'Vinfolket',
    website: 'https://vinfolket.se',
    description: 'Ovanligt bra viner till ovanligt bra priser med hemleverans i hela Sverige.',
    contactEmail: 'info@vinfolket.se',
    sellsToRestaurants: false,
    sellsToPrivate: true,
    specialties: ['Bra priser', 'Hållbara viner', 'Hemleverans'],
    portfolio: [
      {
        id: 'w37',
        name: 'Côtes du Rhône Villages',
        country: 'Frankrike',
        region: 'Rhône',
        grapeVarieties: ['Grenache', 'Syrah'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Rödvin med kryddiga toner och mörka bär.'
      },
      {
        id: 'w38',
        name: 'Picpoul de Pinet',
        country: 'Frankrike',
        region: 'Languedoc',
        grapeVarieties: ['Picpoul'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Fräscht franskt vitt med citrus och mineralitet.'
      },
      {
        id: 'w39',
        name: 'Crémant de Bourgogne',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Chardonnay', 'Pinot Noir'],
        type: 'Mousserande',
        priceRange: '100-200kr',
        description: 'Mousserande från Bourgogne med fin elegans.'
      }
    ]
  },
  {
    id: '14',
    name: 'Vinonista',
    website: 'https://vinonista.dk',
    description: 'Hantverksmässigt producerade viner med leverans till Sverige. Fokus på personligt urval.',
    contactEmail: 'info@vinonista.dk',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Hantverksviner', 'Personligt urval', 'Små producenter'],
    portfolio: [
      {
        id: 'w40',
        name: 'Blaufränkisch Burgenland',
        country: 'Österrike',
        region: 'Burgenland',
        grapeVarieties: ['Blaufränkisch'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Elegant österrikisk röd med körsbär och kryddor.'
      },
      {
        id: 'w41',
        name: 'Riesling Mosel',
        country: 'Tyskland',
        region: 'Mosel',
        grapeVarieties: ['Riesling'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Klassisk Mosel Riesling med äpple och mineralitet.'
      },
      {
        id: 'w42',
        name: 'Spätburgunder Baden',
        country: 'Tyskland',
        region: 'Baden',
        grapeVarieties: ['Pinot Noir'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Tysk pinot noir med röda bär och elegant struktur.'
      }
    ]
  },
  {
    id: '15',
    name: 'Bombwine',
    website: 'https://bombwine.se',
    description: 'Kontinuerliga vinsläpp från producenter som tidigare endast funnits på bättre krogar.',
    contactEmail: 'hello@bombwine.se',
    sellsToRestaurants: false,
    sellsToPrivate: true,
    specialties: ['Vinsläpp', 'Restaurangkvalitet', 'Direktimport'],
    portfolio: [
      {
        id: 'w43',
        name: 'Valpolicella Ripasso',
        country: 'Italien',
        region: 'Veneto',
        grapeVarieties: ['Corvina', 'Rondinella'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Ripasso med körsbär och viol, elegant finish.'
      },
      {
        id: 'w44',
        name: 'Sancerre Blanc',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Sauvignon Blanc'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2022,
        description: 'Klassisk Sancerre med krusbär och mineralitet.'
      },
      {
        id: 'w45',
        name: 'Barbera d\'Alba',
        country: 'Italien',
        region: 'Piemonte',
        grapeVarieties: ['Barbera'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Frisk barbera med körsbär och god syra.'
      }
    ]
  },
  {
    id: '16',
    name: 'Vinlådan',
    website: 'https://www.vinladan.nu',
    description: 'Småskaliga, nischade och ekologiska viner. Nya vinlådor för varje årstid.',
    contactEmail: 'info@vinladan.nu',
    sellsToRestaurants: false,
    sellsToPrivate: true,
    specialties: ['Ekologiska viner', 'Vinlådor', 'Årstidsviner'],
    portfolio: [
      {
        id: 'w46',
        name: 'Côtes de Provence Rosé',
        country: 'Frankrike',
        region: 'Provence',
        grapeVarieties: ['Grenache', 'Cinsault', 'Syrah'],
        type: 'Rosé',
        priceRange: '100-200kr',
        year: 2023,
        description: 'Ljus provensalsk rosé med sommarblommor.'
      },
      {
        id: 'w47',
        name: 'Organic Grillo',
        country: 'Italien',
        region: 'Sicilien',
        grapeVarieties: ['Grillo'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Ekologiskt vitt vin med citrus och mandel.'
      },
      {
        id: 'w48',
        name: 'Primitivo Puglia Bio',
        country: 'Italien',
        region: 'Apulien',
        grapeVarieties: ['Primitivo'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Ekologisk primitivo med mörka bär och kryddor.'
      }
    ]
  },
  {
    id: '17',
    name: 'Supervin',
    website: 'https://www.supervin.se',
    description: 'Danmarks mest populära vinbutik online som levererar till Sverige. Stort urval till bra priser.',
    contactEmail: 'info@supervin.se',
    sellsToRestaurants: false,
    sellsToPrivate: true,
    specialties: ['Stort urval', 'Bra priser', 'Dansk vinhandel'],
    portfolio: [
      {
        id: 'w49',
        name: 'Chianti DOCG',
        country: 'Italien',
        region: 'Toscana',
        grapeVarieties: ['Sangiovese'],
        type: 'Rött',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Klassisk chianti med körsbär och god syra.'
      },
      {
        id: 'w50',
        name: 'Pinot Grigio delle Venezie',
        country: 'Italien',
        region: 'Veneto',
        grapeVarieties: ['Pinot Grigio'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Lättdrucket vitt vin med citrus och päron.'
      },
      {
        id: 'w51',
        name: 'Rueda Verdejo',
        country: 'Spanien',
        region: 'Rueda',
        grapeVarieties: ['Verdejo'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Fräscht spanskt vitt med citrus och persika.'
      }
    ]
  },
  {
    id: '18',
    name: 'Fanwine',
    website: 'https://fanwine.se',
    description: 'Hjälper dig att upptäcka och handla vin genom att ansluta dig till aktuella projekt och producenter.',
    contactEmail: 'info@fanwine.se',
    sellsToRestaurants: false,
    sellsToPrivate: true,
    specialties: ['Vinprojekt', 'Direktkontakt', 'Nya producenter'],
    portfolio: [
      {
        id: 'w52',
        name: 'Vinho Verde',
        country: 'Portugal',
        region: 'Minho',
        grapeVarieties: ['Loureiro', 'Alvarinho'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2023,
        description: 'Lätt och fräscht portugisiskt vitt med citrustoner.'
      },
      {
        id: 'w53',
        name: 'Dão Tinto',
        country: 'Portugal',
        region: 'Dão',
        grapeVarieties: ['Touriga Nacional', 'Tinta Roriz'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2020,
        description: 'Portugisiskt rödvin med mörka bär och kryddor.'
      },
      {
        id: 'w54',
        name: 'Alentejo Reserva',
        country: 'Portugal',
        region: 'Alentejo',
        grapeVarieties: ['Aragonez', 'Trincadeira'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2019,
        description: 'Fylligt rött vin från södra Portugal.'
      }
    ]
  },
  {
    id: '19',
    name: 'Louie Louie Wine',
    website: 'https://louielouie.se',
    description: 'Vinbar och importör med fokus på naturviner och hantverksmässig produktion.',
    contactEmail: 'info@louielouie.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Naturviner', 'Vinbar', 'Hantverksviner'],
    portfolio: [
      {
        id: 'w55',
        name: 'Beaujolais Villages',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Gamay'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Lätt och friskt rödvin med röda bär.'
      },
      {
        id: 'w56',
        name: 'Muscadet Sèvre et Maine',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Melon de Bourgogne'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Mineraliskt vitt vin perfekt till skaldjur.'
      },
      {
        id: 'w57',
        name: 'Chinon Rouge',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Cabernet Franc'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Cabernet franc med violer och röda bär.'
      }
    ]
  },
  {
    id: '20',
    name: 'Barrique',
    website: 'https://barrique.se',
    description: 'Vinbar och butik i Stockholm med eget import av spännande viner från hela världen.',
    contactEmail: 'info@barrique.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Vinbar', 'Stadsnära', 'Kurerade viner'],
    portfolio: [
      {
        id: 'w58',
        name: 'Nero d\'Avola',
        country: 'Italien',
        region: 'Sicilien',
        grapeVarieties: ['Nero d\'Avola'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Sicilianskt rödvin med mörka bär och kryddor.'
      },
      {
        id: 'w59',
        name: 'Verdicchio dei Castelli di Jesi',
        country: 'Italien',
        region: 'Marche',
        grapeVarieties: ['Verdicchio'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Elegant italienskt vitt med mandel och citrus.'
      },
      {
        id: 'w60',
        name: 'Franciacorta Brut',
        country: 'Italien',
        region: 'Lombardiet',
        grapeVarieties: ['Chardonnay', 'Pinot Noir'],
        type: 'Mousserande',
        priceRange: '200-400kr',
        description: 'Italienskt mousserande i champagnemetoden.'
      }
    ]
  },
  {
    id: '21',
    name: 'Vinupplevelser Sverige AB',
    website: 'https://www.vinupplevelser.se',
    description: 'Malmöbaserad importör med fokus på unika vinupplevelser från utvalda regioner.',
    contactEmail: 'info@vinupplevelser.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Spanska viner', 'Rioja', 'Vinprovningar'],
    portfolio: [
      {
        id: 'w61',
        name: 'Rioja Crianza',
        country: 'Spanien',
        region: 'Rioja',
        grapeVarieties: ['Tempranillo'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2020,
        description: 'Klassisk Rioja med vanilj och röda bär.'
      },
      {
        id: 'w62',
        name: 'Ribera del Duero Reserva',
        country: 'Spanien',
        region: 'Ribera del Duero',
        grapeVarieties: ['Tempranillo'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2018,
        description: 'Kraftfullt spanskt rödvin med mörka frukter.'
      },
      {
        id: 'w63',
        name: 'Godello Valdeorras',
        country: 'Spanien',
        region: 'Galicien',
        grapeVarieties: ['Godello'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Aromatiskt vitt vin med persika och mineralitet.'
      }
    ]
  },
  {
    id: '22',
    name: 'Vingruppen i Norden AB',
    website: 'https://www.vingruppen.se',
    description: 'Sammanslutning av vinimportörer med ett omfattande sortiment från hela världen.',
    contactEmail: 'info@vingruppen.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Brett sortiment', 'Flera regioner', 'Professionell service'],
    portfolio: [
      {
        id: 'w64',
        name: 'Priorat',
        country: 'Spanien',
        region: 'Priorat',
        grapeVarieties: ['Garnacha', 'Cariñena'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2019,
        description: 'Koncentrerat och kraftfullt vin från skiffermark.'
      },
      {
        id: 'w65',
        name: 'Pouilly-Fumé',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Sauvignon Blanc'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2022,
        description: 'Elegant Loire-vin med rökiga toner.'
      },
      {
        id: 'w66',
        name: 'Barolo Classico',
        country: 'Italien',
        region: 'Piemonte',
        grapeVarieties: ['Nebbiolo'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2018,
        description: 'Majestätiskt Barolo med stor åldrningspotential.'
      }
    ]
  },
  {
    id: '23',
    name: 'Handpicked Wines Sweden AB',
    website: 'https://www.handpicked.se',
    description: 'Stockholmsbaserad importör med handplockade viner från små och medelstora producenter.',
    contactEmail: 'info@handpicked.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Handplockade viner', 'Små producenter', 'Kvalitetsfokus'],
    portfolio: [
      {
        id: 'w67',
        name: 'Barbaresco',
        country: 'Italien',
        region: 'Piemonte',
        grapeVarieties: ['Nebbiolo'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2019,
        description: 'Elegant och komplex nebbiolo från Piemonte.'
      },
      {
        id: 'w68',
        name: 'Gavi di Gavi',
        country: 'Italien',
        region: 'Piemonte',
        grapeVarieties: ['Cortese'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Fräscht och mineraliskt vitt vin.'
      },
      {
        id: 'w69',
        name: 'Dolcetto d\'Alba',
        country: 'Italien',
        region: 'Piemonte',
        grapeVarieties: ['Dolcetto'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Fruktig och lättdrucket piemontesisk klassiker.'
      }
    ]
  },
  {
    id: '24',
    name: 'Gastrodev Vin & Sprit AB',
    website: 'https://www.gastrodev.se',
    description: 'En av Sveriges större vinimportörer med omfattande sortiment för restaurangbranschen.',
    contactEmail: 'info@gastrodev.se',
    sellsToRestaurants: true,
    sellsToPrivate: false,
    specialties: ['Restaurangfokus', 'Stort sortiment', 'Professionell service'],
    portfolio: [
      {
        id: 'w70',
        name: 'Amarone Classico',
        country: 'Italien',
        region: 'Veneto',
        grapeVarieties: ['Corvina', 'Rondinella', 'Molinara'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2017,
        description: 'Kraftfullt vin från torkade druvor med russin och choklad.'
      },
      {
        id: 'w71',
        name: 'Hermitage',
        country: 'Frankrike',
        region: 'Rhône',
        grapeVarieties: ['Syrah'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2018,
        description: 'Kraftfullt och åldringsdugligt syrah från Rhône.'
      },
      {
        id: 'w72',
        name: 'Meursault',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Chardonnay'],
        type: 'Vitt',
        priceRange: 'Över 400kr',
        year: 2020,
        description: 'Klassisk burgundisk chardonnay med nötter och smör.'
      }
    ]
  },
  {
    id: '25',
    name: 'C & E Gastro Import AB',
    website: 'https://www.gastro-import.se',
    description: 'Helsingborgsbaserad importör specialiserad på gastronomiska produkter och viner.',
    contactEmail: 'info@gastro-import.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Franska viner', 'Spanska viner', 'Gastronomi'],
    portfolio: [
      {
        id: 'w73',
        name: 'Pauillac Cru Bourgeois',
        country: 'Frankrike',
        region: 'Bordeaux',
        grapeVarieties: ['Cabernet Sauvignon', 'Merlot'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2019,
        description: 'Strukturerat Bordeaux med cassis och ceder.'
      },
      {
        id: 'w74',
        name: 'Toro Tempranillo',
        country: 'Spanien',
        region: 'Toro',
        grapeVarieties: ['Tempranillo'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2020,
        description: 'Kraftfullt spanskt rödvin med mörka bär.'
      },
      {
        id: 'w75',
        name: 'Entre-Deux-Mers',
        country: 'Frankrike',
        region: 'Bordeaux',
        grapeVarieties: ['Sauvignon Blanc', 'Sémillon'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Fräscht Bordeaux-vitt med citrus och gröna äpplen.'
      }
    ]
  },
  {
    id: '26',
    name: 'Vänersborgs Vinagentur',
    website: 'https://www.vinagent.se',
    description: 'Västsvensk importör med fokus på portugisiska och spanska kvalitetsviner.',
    contactEmail: 'info@vinagent.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Portugisiska viner', 'Alentejo', 'Spanska viner'],
    portfolio: [
      {
        id: 'w76',
        name: 'Alentejo Reserva Premium',
        country: 'Portugal',
        region: 'Alentejo',
        grapeVarieties: ['Aragonez', 'Trincadeira', 'Alicante Bouschet'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2019,
        description: 'Koncentrerat portugisiskt rödvin med kryddor.'
      },
      {
        id: 'w77',
        name: 'Douro Superior',
        country: 'Portugal',
        region: 'Douro',
        grapeVarieties: ['Touriga Nacional', 'Touriga Franca'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2020,
        description: 'Strukturerat vin från Dourodalen.'
      },
      {
        id: 'w78',
        name: 'Vinho Branco Douro',
        country: 'Portugal',
        region: 'Douro',
        grapeVarieties: ['Rabigato', 'Viosinho'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Aromatiskt vitt vin med persika och blommor.'
      }
    ]
  },
  {
    id: '27',
    name: 'Wine Trade Sweden AB',
    website: 'https://www.winetrade.se',
    description: 'Importerar och distribuerar viner från utvalda producenter världen över.',
    contactEmail: 'info@winetrade.se',
    sellsToRestaurants: true,
    sellsToPrivate: false,
    specialties: ['Distribution', 'Internationella viner', 'Restaurangservice'],
    portfolio: [
      {
        id: 'w79',
        name: 'McLaren Vale Shiraz',
        country: 'Australien',
        region: 'McLaren Vale',
        grapeVarieties: ['Shiraz'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Kraftfull australisk shiraz med choklad och kryddor.'
      },
      {
        id: 'w80',
        name: 'Central Otago Pinot Noir',
        country: 'Nya Zeeland',
        region: 'Central Otago',
        grapeVarieties: ['Pinot Noir'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Elegant nyzeeländsk pinot med körsbär och kryddor.'
      },
      {
        id: 'w81',
        name: 'Hawke\'s Bay Chardonnay',
        country: 'Nya Zeeland',
        region: 'Hawke\'s Bay',
        grapeVarieties: ['Chardonnay'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Fruktig chardonnay med tropiska toner.'
      }
    ]
  },
  {
    id: '28',
    name: 'Budbreak',
    website: 'https://www.budbreak.se',
    description: 'Svensk vinimportör med fokus på hantverksmässiga och naturliga viner från intressanta producenter.',
    contactEmail: 'info@budbreak.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Naturviner', 'Hantverksviner', 'Små producenter'],
    portfolio: [
      {
        id: 'w82',
        name: 'Morgon Beaujolais - Domaine Thillardon',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Gamay'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2022,
        description: 'Elegant beaujolais från Morgon med körsbär och mineralitet. Biodynamiskt odlad.'
      },
      {
        id: 'w82b',
        name: 'Fleurie - Domaine de Fa',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Gamay'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2022,
        description: 'Blommig och elegant Fleurie med violer och röda bär.'
      },
      {
        id: 'w82c',
        name: 'Moulin-à-Vent Vieilles Vignes',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Gamay'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Kraftfull beaujolais från gamla vinstockar med struktur.'
      },
      {
        id: 'w83',
        name: 'Anjou Chenin Blanc - Domaine de Bellivière',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Chenin Blanc'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2022,
        description: 'Fräscht och mineraliskt Loire-vin med äpple och honung. Naturvin.'
      },
      {
        id: 'w83b',
        name: 'Vouvray Sec Naturel',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Chenin Blanc'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Torrt Vouvray med citrus och mineralitet.'
      },
      {
        id: 'w83c',
        name: 'Saumur Blanc',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Chenin Blanc'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2023,
        description: 'Ungt och fräscht Loire-vin med gröna äpplen.'
      },
      {
        id: 'w84',
        name: 'Côtes du Jura Trousseau',
        country: 'Frankrike',
        region: 'Jura',
        grapeVarieties: ['Trousseau'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Lätt och kryddigt rödvin från Jura med röda bär.'
      },
      {
        id: 'w84b',
        name: 'Arbois Chardonnay Ouillé',
        country: 'Frankrike',
        region: 'Jura',
        grapeVarieties: ['Chardonnay'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Jura-chardonnay utan oxidativ lagring, fräsch stil.'
      },
      {
        id: 'w84c',
        name: 'Arbois Poulsard',
        country: 'Frankrike',
        region: 'Jura',
        grapeVarieties: ['Poulsard'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Lätt och genomskinligt rödvin med röda bär.'
      },
      {
        id: 'w84d',
        name: 'Macvin du Jura',
        country: 'Frankrike',
        region: 'Jura',
        grapeVarieties: ['Chardonnay'],
        type: 'Dessert',
        priceRange: '200-400kr',
        year: 2018,
        description: 'Traditionellt Jura dessertvin med nötter och honung.'
      },
      {
        id: 'w84e',
        name: 'Côtes du Jura Savagnin',
        country: 'Frankrike',
        region: 'Jura',
        grapeVarieties: ['Savagnin'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2019,
        description: 'Oxidativt Jura-vin med curry och nötter.'
      },
      {
        id: 'w84f',
        name: 'Pet Nat Rosé',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Grolleau'],
        type: 'Mousserande',
        priceRange: '100-200kr',
        year: 2023,
        description: 'Naturligt mousserande rosé med jordgubbe.'
      },
      {
        id: 'w84g',
        name: 'Vin de France Rouge - Le Temps des Cerises',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Cabernet Franc'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Naturvin från Loire med körsbär och violer.'
      },
      {
        id: 'w84h',
        name: 'Muscadet Sèvre et Maine sur Lie',
        country: 'Frankrike',
        region: 'Loire',
        grapeVarieties: ['Melon de Bourgogne'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2023,
        description: 'Mineraliskt och skaldjursvänligt från Loire.'
      },
      {
        id: 'w84i',
        name: 'Etna Bianco',
        country: 'Italien',
        region: 'Sicilien',
        grapeVarieties: ['Carricante'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2022,
        description: 'Vulkaniskt vitt vin med mineralitet och citrus.'
      },
      {
        id: 'w84j',
        name: 'Frappato Vittoria',
        country: 'Italien',
        region: 'Sicilien',
        grapeVarieties: ['Frappato'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2022,
        description: 'Lätt sicilianskt rödvin med röda bär och blommor.'
      }
    ]
  },
  {
    id: '29',
    name: 'Oenoforos Group',
    website: 'https://www.oenoforos.se',
    description: 'En av Sveriges största vinimportörer som representerar flera vinproducenter från olika delar av världen.',
    contactEmail: 'info@oenoforos.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Brett sortiment', 'Internationella viner', 'Stor aktör'],
    portfolio: [
      {
        id: 'w85',
        name: 'Valpolicella Superiore',
        country: 'Italien',
        region: 'Veneto',
        grapeVarieties: ['Corvina', 'Rondinella'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2020,
        description: 'Elegant Valpolicella med körsbär och kryddighet.'
      },
      {
        id: 'w86',
        name: 'Côtes du Rhône Villages',
        country: 'Frankrike',
        region: 'Rhône',
        grapeVarieties: ['Grenache', 'Syrah'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Kraftfullt Rhône-vin med mörka bär och kryddor.'
      },
      {
        id: 'w87',
        name: 'Marlborough Sauvignon Blanc',
        country: 'Nya Zeeland',
        region: 'Marlborough',
        grapeVarieties: ['Sauvignon Blanc'],
        type: 'Vitt',
        priceRange: '100-200kr',
        year: 2023,
        description: 'Aromatiskt vitt vin med krusbär och passion.'
      }
    ]
  },
  {
    id: '30',
    name: 'WinePartners Nordic AB',
    website: 'https://www.winepartners.se',
    description: 'Brett sortiment med fokus på kvalitet. Samarbetar med framstående producenter från flera vinländer.',
    contactEmail: 'info@winepartners.se',
    sellsToRestaurants: true,
    sellsToPrivate: false,
    specialties: ['Kvalitetsviner', 'Internationellt', 'Restaurangfokus'],
    portfolio: [
      {
        id: 'w88',
        name: 'Margaux Cru Bourgeois',
        country: 'Frankrike',
        region: 'Bordeaux',
        grapeVarieties: ['Cabernet Sauvignon', 'Merlot'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2019,
        description: 'Elegant Bordeaux med cassis och ceder.'
      },
      {
        id: 'w89',
        name: 'Puligny-Montrachet',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Chardonnay'],
        type: 'Vitt',
        priceRange: 'Över 400kr',
        year: 2021,
        description: 'Prestigefylld burgundisk chardonnay med mineralitet.'
      },
      {
        id: 'w90',
        name: 'Chianti Classico Riserva',
        country: 'Italien',
        region: 'Toscana',
        grapeVarieties: ['Sangiovese'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2019,
        description: 'Vällagrat Chianti med körsbär och läder.'
      }
    ]
  },
  {
    id: '31',
    name: 'The WineAgency',
    website: 'https://www.thewineagency.se',
    description: 'Passion för kvalitetsviner och representerar brett spektrum från stora kända namn till boutique-vinerier.',
    contactEmail: 'info@thewineagency.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Kvalitetsviner', 'Boutique', 'Kuraterat urval'],
    portfolio: [
      {
        id: 'w91',
        name: 'Napa Valley Cabernet',
        country: 'USA',
        region: 'Kalifornien',
        grapeVarieties: ['Cabernet Sauvignon'],
        type: 'Rött',
        priceRange: 'Över 400kr',
        year: 2019,
        description: 'Kraftfullt kaliforniskt rödvin med mörka bär.'
      },
      {
        id: 'w92',
        name: 'Willamette Valley Pinot Noir',
        country: 'USA',
        region: 'Oregon',
        grapeVarieties: ['Pinot Noir'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Elegant Oregon pinot med röda bär och kryddor.'
      },
      {
        id: 'w93',
        name: 'Sonoma Coast Chardonnay',
        country: 'USA',
        region: 'Kalifornien',
        grapeVarieties: ['Chardonnay'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Elegant kalifornisk chardonnay med citrus och ek.'
      }
    ]
  },
  {
    id: '32',
    name: 'WineWorld',
    website: 'https://www.wineworld.se',
    description: 'Framstående aktör som erbjuder viner från både gamla och nya världen.',
    contactEmail: 'info@wineworld.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Gamla världen', 'Nya världen', 'Brett sortiment'],
    portfolio: [
      {
        id: 'w94',
        name: 'Stellenbosch Cabernet',
        country: 'Sydafrika',
        region: 'Stellenbosch',
        grapeVarieties: ['Cabernet Sauvignon'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2020,
        description: 'Sydafrikanskt rödvin med mörka bär och läder.'
      },
      {
        id: 'w95',
        name: 'Chenin Blanc Coastal',
        country: 'Sydafrika',
        region: 'Western Cape',
        grapeVarieties: ['Chenin Blanc'],
        type: 'Vitt',
        priceRange: 'Under 100kr',
        year: 2022,
        description: 'Fräscht sydafrikanskt vitt med tropisk frukt.'
      },
      {
        id: 'w96',
        name: 'Pinotage Reserve',
        country: 'Sydafrika',
        region: 'Stellenbosch',
        grapeVarieties: ['Pinotage'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2020,
        description: 'Unik sydafrikansk druva med mörka bär och rök.'
      }
    ]
  },
  {
    id: '33',
    name: 'Divine Wines',
    website: 'https://www.divinewines.se',
    description: 'Fokuserar på ekologiska, biodynamiska och naturviner enligt den växande trenden mot hållbara vinalternativ.',
    contactEmail: 'info@divinewines.se',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Ekologiska viner', 'Biodynamiska viner', 'Naturviner'],
    portfolio: [
      {
        id: 'w97',
        name: 'Biodynamic Pinot Noir',
        country: 'Frankrike',
        region: 'Bourgogne',
        grapeVarieties: ['Pinot Noir'],
        type: 'Rött',
        priceRange: '200-400kr',
        year: 2020,
        description: 'Biodynamiskt burgundiskt rödvin med fin elegans.'
      },
      {
        id: 'w98',
        name: 'Natural Orange Wine',
        country: 'Italien',
        region: 'Friaul',
        grapeVarieties: ['Ribolla Gialla'],
        type: 'Vitt',
        priceRange: '200-400kr',
        year: 2021,
        description: 'Naturligt orange wine med tanniner och aprikoston.'
      },
      {
        id: 'w99',
        name: 'Organic Côtes du Rhône',
        country: 'Frankrike',
        region: 'Rhône',
        grapeVarieties: ['Grenache', 'Syrah'],
        type: 'Rött',
        priceRange: '100-200kr',
        year: 2021,
        description: 'Ekologiskt Rhône-vin med kryddor och mörka bär.'
      }
    ]
  }
];

export const getAllCountries = (): string[] => {
  const countries = new Set<string>();
  importers.forEach(importer => {
    importer.portfolio.forEach(wine => countries.add(wine.country));
  });
  return Array.from(countries).sort();
};

export const getAllRegions = (): string[] => {
  const regions = new Set<string>();
  importers.forEach(importer => {
    importer.portfolio.forEach(wine => regions.add(wine.region));
  });
  return Array.from(regions).sort();
};

export const getAllGrapeVarieties = (): string[] => {
  const varieties = new Set<string>();
  importers.forEach(importer => {
    importer.portfolio.forEach(wine => {
      wine.grapeVarieties.forEach(variety => varieties.add(variety));
    });
  });
  return Array.from(varieties).sort();
};

export const getAllWineTypes = (): string[] => {
  return ['Rött', 'Vitt', 'Rosé', 'Mousserande', 'Dessert', 'Starkvin'];
};

export const getAllPriceRanges = (): string[] => {
  return ['Under 100kr', '100-200kr', '200-400kr', 'Över 400kr'];
};

