'use client';

import { useState, useEffect } from 'react';

interface SearchResult {
  importers: any[];
  total: number;
  page: number;
  totalPages: number;
  filterOptions: {
    countries: string[];
    regions: string[];
    types: string[];
    priceRanges: string[];
    grapeVarieties: string[];
  };
}

// Mock data för demo
const mockImporters = [
  {
    id: '1',
    name: 'Vinoliv Import',
    website: 'https://www.vinoliv.se',
    description: 'Specialiserar sig på högkvalitativa italienska viner och levererar till både Systembolaget och restauranger.',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Italienska viner', 'Kvalitetsviner', 'Systembolaget'],
    wines: [
      { id: 'w1', name: 'Barolo DOCG', country: 'Italien', region: 'Piemonte', type: 'Rött', priceRange: 'Över 400kr', grapeVarieties: ['Nebbiolo'] },
      { id: 'w2', name: 'Chianti Classico', country: 'Italien', region: 'Toscana', type: 'Rött', priceRange: '100-200kr', grapeVarieties: ['Sangiovese'] }
    ]
  },
  {
    id: '2',
    name: 'Jordmånen',
    website: 'https://www.jordmanen.com',
    description: 'Stockholmsbaserad importör med fokus på naturviner utan tillsatser.',
    sellsToRestaurants: true,
    sellsToPrivate: true,
    specialties: ['Naturviner', 'Ekologiska viner', 'Biodynamiska viner'],
    wines: [
      { id: 'w3', name: 'Gamay Nature', country: 'Frankrike', region: 'Jura', type: 'Rött', priceRange: '100-200kr', grapeVarieties: ['Gamay'] },
      { id: 'w4', name: 'Chardonnay Orange', country: 'Frankrike', region: 'Loire', type: 'Vitt', priceRange: '200-400kr', grapeVarieties: ['Chardonnay'] }
    ]
  }
];

export default function DemoSimplePage() {
  const [results, setResults] = useState<SearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    searchTerm: '',
    country: '',
    region: '',
    type: '',
    priceRange: '',
    grapeVariety: '',
    sellsToRestaurants: undefined as boolean | undefined,
    sellsToPrivate: undefined as boolean | undefined
  });

  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    searchImporters();
  }, [filters, currentPage]); // eslint-disable-line react-hooks/exhaustive-deps

  const searchImporters = async () => {
    setLoading(true);
    
    // Simulera API-anrop
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Filtrera mock data
    let filtered = [...mockImporters];
    
    // Sökterm
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      filtered = filtered.filter(importer => 
        importer.name.toLowerCase().includes(term) ||
        importer.description.toLowerCase().includes(term) ||
        importer.specialties.some((s: string) => s.toLowerCase().includes(term))
      );
    }
    
    // Försäljningskanaler
    if (filters.sellsToRestaurants !== undefined) {
      filtered = filtered.filter(importer => importer.sellsToRestaurants === filters.sellsToRestaurants);
    }
    if (filters.sellsToPrivate !== undefined) {
      filtered = filtered.filter(importer => importer.sellsToPrivate === filters.sellsToPrivate);
    }
    
    // Vin-filter
    if (filters.country || filters.region || filters.type || filters.priceRange || filters.grapeVariety) {
      filtered = filtered.filter(importer => 
        importer.wines.some((wine: any) => {
          if (filters.country && wine.country !== filters.country) return false;
          if (filters.region && wine.region !== filters.region) return false;
          if (filters.type && wine.type !== filters.type) return false;
          if (filters.priceRange && wine.priceRange !== filters.priceRange) return false;
          if (filters.grapeVariety && !wine.grapeVarieties.includes(filters.grapeVariety)) return false;
          return true;
        })
      );
    }
    
    // Paginering
    const limit = 10;
    const startIndex = (currentPage - 1) * limit;
    const paginatedResults = filtered.slice(startIndex, startIndex + limit);
    
    // Hämta filter-alternativ
    const allWines = mockImporters.flatMap(imp => imp.wines);
    const filterOptions = {
      countries: [...new Set(allWines.map(w => w.country))].sort(),
      regions: [...new Set(allWines.map(w => w.region))].sort(),
      types: [...new Set(allWines.map(w => w.type))].sort(),
      priceRanges: [...new Set(allWines.map(w => w.priceRange))].sort(),
      grapeVarieties: [...new Set(allWines.flatMap(w => w.grapeVarieties))].sort()
    };
    
    setResults({
      importers: paginatedResults,
      total: filtered.length,
      page: currentPage,
      totalPages: Math.ceil(filtered.length / limit),
      filterOptions
    });
    
    setLoading(false);
  };

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const clearFilters = () => {
    setFilters({
      searchTerm: '',
      country: '',
      region: '',
      type: '',
      priceRange: '',
      grapeVariety: '',
      sellsToRestaurants: undefined,
      sellsToPrivate: undefined
    });
    setCurrentPage(1);
  };

  return (
    <div className="demo-container">
      <header className="demo-header">
        <h1>🚀 Wine Azone - Skalbar Demo</h1>
        <p>Mock-demo av den nya API-drivna versionen med smart filtrering!</p>
        <div className="demo-links">
          <a href="/" className="demo-link">← Tillbaka till ursprunglig app</a>
          <a href="/search" className="demo-link">🔍 Ursprunglig sökning</a>
        </div>
      </header>

      <div className="demo-content">
        <div className="demo-filters">
          <h2>🔍 Smart filtrering (Mock API)</h2>
          
          <div className="filter-row">
            <input
              type="text"
              placeholder="Sök efter importör, specialitet..."
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
              className="demo-input"
            />
          </div>

          <div className="filter-grid">
            <select
              value={filters.country}
              onChange={(e) => handleFilterChange('country', e.target.value)}
              className="demo-select"
            >
              <option value="">Alla länder ({results?.filterOptions.countries.length || 0})</option>
              {results?.filterOptions.countries.map(country => (
                <option key={country} value={country}>{country}</option>
              ))}
            </select>

            <select
              value={filters.region}
              onChange={(e) => handleFilterChange('region', e.target.value)}
              className="demo-select"
            >
              <option value="">Alla regioner ({results?.filterOptions.regions.length || 0})</option>
              {results?.filterOptions.regions.map(region => (
                <option key={region} value={region}>{region}</option>
              ))}
            </select>

            <select
              value={filters.type}
              onChange={(e) => handleFilterChange('type', e.target.value)}
              className="demo-select"
            >
              <option value="">Alla typer ({results?.filterOptions.types.length || 0})</option>
              {results?.filterOptions.types.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>

            <select
              value={filters.priceRange}
              onChange={(e) => handleFilterChange('priceRange', e.target.value)}
              className="demo-select"
            >
              <option value="">Alla priser ({results?.filterOptions.priceRanges.length || 0})</option>
              {results?.filterOptions.priceRanges.map(range => (
                <option key={range} value={range}>{range}</option>
              ))}
            </select>

            <select
              value={filters.grapeVariety}
              onChange={(e) => handleFilterChange('grapeVariety', e.target.value)}
              className="demo-select"
            >
              <option value="">Alla druvor ({results?.filterOptions.grapeVarieties.length || 0})</option>
              {results?.filterOptions.grapeVarieties.map(grape => (
                <option key={grape} value={grape}>{grape}</option>
              ))}
            </select>
          </div>

          <div className="checkbox-row">
            <label className="demo-checkbox">
              <input
                type="checkbox"
                checked={filters.sellsToRestaurants === true}
                onChange={(e) => handleFilterChange('sellsToRestaurants', e.target.checked ? true : undefined)}
              />
              Säljer till restauranger
            </label>
            <label className="demo-checkbox">
              <input
                type="checkbox"
                checked={filters.sellsToPrivate === true}
                onChange={(e) => handleFilterChange('sellsToPrivate', e.target.checked ? true : undefined)}
              />
              Säljer till privatpersoner
            </label>
          </div>

          <button onClick={clearFilters} className="clear-btn">
            🗑️ Rensa alla filter
          </button>
        </div>

        <div className="demo-results">
          {loading ? (
            <div className="loading">Laddar resultat...</div>
          ) : results ? (
            <>
              <div className="results-header">
                <h3>Hittade {results.total} importörer</h3>
                <p>Sida {results.page} av {results.totalPages}</p>
              </div>

              <div className="results-grid">
                {results.importers.map((importer: any) => (
                  <div key={importer.id} className="importer-card">
                    <div className="importer-header">
                      <h4>{importer.name}</h4>
                    </div>
                    <p className="importer-description">{importer.description}</p>
                    
                    <div className="importer-badges">
                      {importer.sellsToRestaurants && (
                        <span className="badge restaurant">🍽️ Restauranger</span>
                      )}
                      {importer.sellsToPrivate && (
                        <span className="badge private">👤 Privatpersoner</span>
                      )}
                    </div>

                    <div className="portfolio-info">
                      <p>📦 {importer.wines?.length || 0} viner i portföljen</p>
                    </div>

                    <div className="specialties">
                      <strong>Specialiteter:</strong>
                      <div className="specialty-tags">
                        {importer.specialties?.map((specialty: string, index: number) => (
                          <span key={index} className="specialty-tag">{specialty}</span>
                        ))}
                      </div>
                    </div>

                    <a href={importer.website} target="_blank" rel="noopener noreferrer" className="visit-website">
                      Besök hemsida →
                    </a>
                  </div>
                ))}
              </div>

              {results.totalPages > 1 && (
                <div className="pagination">
                  <button 
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                    className="page-btn"
                  >
                    ← Föregående
                  </button>
                  
                  <span className="page-info">
                    Sida {currentPage} av {results.totalPages}
                  </span>
                  
                  <button 
                    onClick={() => setCurrentPage(prev => Math.min(results.totalPages, prev + 1))}
                    disabled={currentPage === results.totalPages}
                    className="page-btn"
                  >
                    Nästa →
                  </button>
                </div>
              )}
            </>
          ) : (
            <div className="no-results">
              <p>Inga resultat att visa</p>
            </div>
          )}
        </div>
      </div>

      <div className="demo-features">
        <h2>✨ Demo-funktioner</h2>
        <div className="features-grid">
          <div className="feature-card">
            <h3>🗄️ Databas (Mock)</h3>
            <p>PostgreSQL schema med Prisma ORM (redan implementerat)</p>
          </div>
          <div className="feature-card">
            <h3>⚡ Caching (Mock)</h3>
            <p>Redis-caching för snabba API-svar (redan implementerat)</p>
          </div>
          <div className="feature-card">
            <h3>🔍 Smart filtrering</h3>
            <p>Dynamiska filter som uppdateras baserat på data</p>
          </div>
          <div className="feature-card">
            <h3>📄 Paginering</h3>
            <p>Effektiv hantering av stora dataset</p>
          </div>
        </div>
        
        <div className="demo-instructions">
          <h3>🛠️ Så här aktiverar du den fullständiga versionen:</h3>
          <ol>
            <li><strong>Sätt upp PostgreSQL:</strong> <code>createdb wineazone</code></li>
            <li><strong>Konfigurera .env:</strong> Lägg till DATABASE_URL</li>
            <li><strong>Generera Prisma client:</strong> <code>npm run db:generate</code></li>
            <li><strong>Push schema:</strong> <code>npm run db:push</code></li>
            <li><strong>Seed data:</strong> <code>npm run db:seed</code></li>
            <li><strong>Besök:</strong> <a href="/demo">/demo</a> och <a href="/admin">/admin</a></li>
          </ol>
        </div>
      </div>
    </div>
  );
}
