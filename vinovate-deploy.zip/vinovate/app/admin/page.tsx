'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface Stats {
  totalImporters: number;
  totalWines: number;
  activeImporters: number;
  lastUpdated: string;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="admin-container">
        <div className="loading">Laddar admin-panel...</div>
      </div>
    );
  }

  return (
    <div className="admin-container">
      <header className="admin-header">
        <h1>🍷 Wine Azone Admin</h1>
        <Link href="/" className="back-link">← Tillbaka till appen</Link>
      </header>

      <div className="admin-grid">
        <div className="admin-card">
          <h2>📊 Statistik</h2>
          {stats ? (
            <div className="stats-grid">
              <div className="stat-item">
                <div className="stat-number">{stats.totalImporters}</div>
                <div className="stat-label">Totala importörer</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">{stats.activeImporters}</div>
                <div className="stat-label">Aktiva importörer</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">{stats.totalWines}</div>
                <div className="stat-label">Totala viner</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">
                  {new Date(stats.lastUpdated).toLocaleDateString('sv-SE')}
                </div>
                <div className="stat-label">Senast uppdaterad</div>
              </div>
            </div>
          ) : (
            <div className="error">Kunde inte ladda statistik</div>
          )}
          <button onClick={fetchStats} className="refresh-btn">
            🔄 Uppdatera
          </button>
        </div>

        <div className="admin-card">
          <h2>🗄️ Databashantering</h2>
          <div className="admin-actions">
            <button 
              className="action-btn primary"
              onClick={() => window.open('/api/importers', '_blank')}
            >
              📡 Testa API
            </button>
            <button 
              className="action-btn"
              onClick={() => window.open('/api/stats', '_blank')}
            >
              📊 Visa stats API
            </button>
          </div>
          <div className="info-box">
            <h3>💡 Demo-funktioner:</h3>
            <ul>
              <li>✅ Databas med Prisma ORM</li>
              <li>✅ RESTful API endpoints</li>
              <li>✅ Caching med Redis (mock)</li>
              <li>✅ Smart filtrering</li>
              <li>✅ Paginering</li>
              <li>⏳ Admin-panel (under utveckling)</li>
              <li>⏳ Bulk import (planerad)</li>
            </ul>
          </div>
        </div>

        <div className="admin-card">
          <h2>🚀 Skalningsdemo</h2>
          <div className="demo-features">
            <div className="feature">
              <h3>📈 Prestanda</h3>
              <p>API:er med caching och optimerade queries</p>
            </div>
            <div className="feature">
              <h3>🔍 Smart sökning</h3>
              <p>Dynamiska filter som uppdateras baserat på tillgänglig data</p>
            </div>
            <div className="feature">
              <h3>📱 Responsiv design</h3>
              <p>Fungerar på alla enheter med optimerad prestanda</p>
            </div>
          </div>
        </div>

        <div className="admin-card">
          <h2>🛠️ Teknisk stack</h2>
          <div className="tech-stack">
            <div className="tech-item">
              <strong>Backend:</strong> Next.js API Routes + Prisma
            </div>
            <div className="tech-item">
              <strong>Databas:</strong> PostgreSQL (schema klar)
            </div>
            <div className="tech-item">
              <strong>Caching:</strong> Redis (mock implementation)
            </div>
            <div className="tech-item">
              <strong>Frontend:</strong> React + TypeScript
            </div>
            <div className="tech-item">
              <strong>Deployment:</strong> Vercel-ready
            </div>
          </div>
        </div>
      </div>

      <div className="admin-footer">
        <p>
          🎯 <strong>Nästa steg för fullständig skalning:</strong><br/>
          1. Sätt upp PostgreSQL databas<br/>
          2. Kör seed script för att fylla databasen<br/>
          3. Implementera admin CRUD-funktioner<br/>
          4. Lägg till bulk import från CSV/API
        </p>
      </div>
    </div>
  );
}
