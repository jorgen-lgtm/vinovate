'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { importers } from '@/data/importers';

export default function Home() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchTerm)}`);
    } else {
      router.push('/search');
    }
  };

  // Hämta de 3 senaste importörerna (simulerar nya tillskott)
  const latestImporters = importers.slice(-3).reverse();

  // Beräkna totalt antal viner
  const totalWines = importers.reduce((sum, imp) => sum + imp.portfolio.length, 0);

  return (
    <div className="landing-page">
      <header className="hero-header">
        <div className="container">
          <h1 className="hero-title">🍷 Vinovate</h1>
          <p className="hero-subtitle">
            Sveriges största databas för vinimportörer
          </p>
          <p className="hero-description">
            Hitta rätt importör för dina vinbehov - sök bland {importers.length} importörer 
            med över {totalWines} olika viner
          </p>
        </div>
      </header>

      <main className="container">
        {/* Söksektion */}
        <section className="home-search-section">
          <h2>Sök vinimportörer</h2>
          <form onSubmit={handleSearch} className="home-search-form">
            <input
              type="text"
              className="home-search-input"
              placeholder="Sök efter land, druva, importör eller vintyp..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button type="submit" className="home-search-button">
              Sök
            </button>
          </form>
          <button 
            onClick={() => router.push('/search')}
            className="advanced-search-link"
          >
            Avancerad sökning med filter →
          </button>
        </section>

        {/* Om appen */}
        <section className="about-section">
          <h2>Om Wine Azone</h2>
          <div className="about-grid">
            <div className="about-card">
              <div className="about-icon">🔍</div>
              <h3>Sök & Filtrera</h3>
              <p>
                Filtrera på land, region, druva, vintyp, prisintervall och mer. 
                Hitta exakt den importör som matchar dina behov.
              </p>
            </div>
            <div className="about-card">
              <div className="about-icon">🍇</div>
              <h3>Omfattande Databas</h3>
              <p>
                {importers.length} svenska vinimportörer med över {totalWines} olika viner. 
                Från stora aktörer till nischade naturvinsimportörer.
              </p>
            </div>
            <div className="about-card">
              <div className="about-icon">🔗</div>
              <h3>Direktlänkar</h3>
              <p>
                Alla importörer har länkar till sina hemsidor där du kan 
                utforska sortiment och genomföra beställningar.
              </p>
            </div>
            <div className="about-card">
              <div className="about-icon">🏪</div>
              <h3>För Alla</h3>
              <p>
                Oavsett om du driver restaurang eller är privatperson kan du 
                filtrera på vem som säljer till dig.
              </p>
            </div>
          </div>
        </section>

        {/* Nya importörer */}
        <section className="new-importers-section">
          <h2>Senaste tillskotten</h2>
          <p className="section-subtitle">
            Nyligen tillagda vinimportörer i vår databas
          </p>
          <div className="new-importers-grid">
            {latestImporters.map((importer) => (
              <div key={importer.id} className="new-importer-card">
                <h3>{importer.name}</h3>
                <p>{importer.description}</p>
                <div className="importer-meta">
                  <span className="wine-count">
                    {importer.portfolio.length} viner
                  </span>
                  {importer.specialties.slice(0, 2).map((specialty, idx) => (
                    <span key={idx} className="specialty-badge">
                      {specialty}
                    </span>
                  ))}
                </div>
                <a 
                  href={importer.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="importer-link"
                >
                  Besök hemsida →
                </a>
              </div>
            ))}
          </div>
        </section>

        {/* Statistik */}
        <section className="stats-section">
          <h2>Databas i siffror</h2>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-number">{importers.length}</div>
              <div className="stat-label">Vinimportörer</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{totalWines}</div>
              <div className="stat-label">Olika viner</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">
                {importers.filter(i => i.sellsToRestaurants && i.sellsToPrivate).length}
              </div>
              <div className="stat-label">Säljer till både restaurang & privat</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">
                {new Set(importers.flatMap(i => i.portfolio.flatMap(w => w.grapeVarieties))).size}
              </div>
              <div className="stat-label">Olika druvor</div>
            </div>
          </div>
        </section>

        {/* Call to action */}
        <section className="cta-section">
          <h2>Redo att hitta din nästa vinimportör?</h2>
          <div className="cta-buttons">
            <button 
              onClick={() => router.push('/search')}
              className="cta-button"
            >
              🍷 Börja söka viner
            </button>
            <button 
              onClick={() => router.push('/demo-clean')}
              className="cta-button secondary"
            >
              🚀 Se skalbar demo
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}
