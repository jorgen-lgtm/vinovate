export default function DemoPage() {
  return (
    <div style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
      <header style={{ textAlign: 'center', marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '3rem', color: '#667eea', marginBottom: '1rem' }}>
          🚀 Wine Azone - Skalbar Demo
        </h1>
        <p style={{ fontSize: '1.2rem', color: '#666' }}>
          En demonstration av den nya API-drivna versionen med databas och caching!
        </p>
        <div style={{ marginTop: '2rem' }}>
          <a href="/" style={{ 
            display: 'inline-block', 
            margin: '0 1rem',
            padding: '0.8rem 1.5rem', 
            background: '#667eea', 
            color: 'white', 
            textDecoration: 'none', 
            borderRadius: '8px',
            fontWeight: '600'
          }}>
            ← Tillbaka till ursprunglig app
          </a>
          <a href="/search" style={{ 
            display: 'inline-block', 
            margin: '0 1rem',
            padding: '0.8rem 1.5rem', 
            background: '#48c6ef', 
            color: 'white', 
            textDecoration: 'none', 
            borderRadius: '8px',
            fontWeight: '600'
          }}>
            🔍 Ursprunglig sökning
          </a>
        </div>
      </header>

      <div style={{ 
        background: 'white', 
        padding: '2rem', 
        borderRadius: '20px', 
        boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
        marginBottom: '2rem'
      }}>
        <h2 style={{ color: '#333', marginBottom: '1.5rem' }}>✨ Implementerade funktioner</h2>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
          <div style={{ 
            padding: '1.5rem', 
            background: '#f8f9fa', 
            borderRadius: '12px', 
            borderLeft: '4px solid #667eea' 
          }}>
            <h3 style={{ color: '#333', marginBottom: '1rem' }}>🗄️ Databas & API</h3>
            <ul style={{ color: '#666', lineHeight: '1.6' }}>
              <li>✅ PostgreSQL schema med Prisma ORM</li>
              <li>✅ RESTful API endpoints</li>
              <li>✅ Smart filtrering och sökning</li>
              <li>✅ Paginering för stora dataset</li>
            </ul>
          </div>

          <div style={{ 
            padding: '1.5rem', 
            background: '#f8f9fa', 
            borderRadius: '12px', 
            borderLeft: '4px solid #48c6ef' 
          }}>
            <h3 style={{ color: '#333', marginBottom: '1rem' }}>⚡ Prestanda</h3>
            <ul style={{ color: '#666', lineHeight: '1.6' }}>
              <li>✅ Redis-caching (mock implementation)</li>
              <li>✅ Optimized database queries</li>
              <li>✅ Smart filter dependencies</li>
              <li>✅ Responsive design</li>
            </ul>
          </div>

          <div style={{ 
            padding: '1.5rem', 
            background: '#f8f9fa', 
            borderRadius: '12px', 
            borderLeft: '4px solid #e74c3c' 
          }}>
            <h3 style={{ color: '#333', marginBottom: '1rem' }}>🎨 Admin & UX</h3>
            <ul style={{ color: '#666', lineHeight: '1.6' }}>
              <li>✅ Admin dashboard med statistik</li>
              <li>✅ Modern UI med gradients</li>
              <li>✅ Interactive filter system</li>
              <li>✅ Mobile-responsive design</li>
            </ul>
          </div>
        </div>

        <div style={{ 
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
          color: 'white', 
          padding: '2rem', 
          borderRadius: '12px',
          marginBottom: '2rem'
        }}>
          <h3 style={{ marginBottom: '1rem' }}>🚀 Så här aktiverar du den fullständiga versionen:</h3>
          <ol style={{ lineHeight: '1.8' }}>
            <li><strong>Sätt upp PostgreSQL:</strong> <code style={{ background: 'rgba(255,255,255,0.2)', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>createdb wineazone</code></li>
            <li><strong>Konfigurera .env:</strong> Lägg till DATABASE_URL</li>
            <li><strong>Generera Prisma client:</strong> <code style={{ background: 'rgba(255,255,255,0.2)', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>npm run db:generate</code></li>
            <li><strong>Push schema:</strong> <code style={{ background: 'rgba(255,255,255,0.2)', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>npm run db:push</code></li>
            <li><strong>Seed data:</strong> <code style={{ background: 'rgba(255,255,255,0.2)', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>npm run db:seed</code></li>
            <li><strong>Besök:</strong> <a href="/demo" style={{ color: '#48c6ef' }}>/demo</a> och <a href="/admin" style={{ color: '#48c6ef' }}>/admin</a></li>
          </ol>
        </div>

        <div style={{ 
          background: '#f8f9fa', 
          padding: '1.5rem', 
          borderRadius: '12px', 
          borderLeft: '4px solid #28a745' 
        }}>
          <h3 style={{ color: '#333', marginBottom: '1rem' }}>📊 Skalningspotential</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2rem', fontWeight: '700', color: '#667eea' }}>500+</div>
              <div style={{ color: '#666' }}>Importörer</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2rem', fontWeight: '700', color: '#667eea' }}>50,000+</div>
              <div style={{ color: '#666' }}>Viner</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2rem', fontWeight: '700', color: '#667eea' }}>1M+</div>
              <div style={{ color: '#666' }}>Requests/dag</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2rem', fontWeight: '700', color: '#667eea' }}>&lt;100ms</div>
              <div style={{ color: '#666' }}>Svarstid</div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ 
        background: 'white', 
        padding: '2rem', 
        borderRadius: '20px', 
        boxShadow: '0 10px 30px rgba(0,0,0,0.1)' 
      }}>
        <h2 style={{ color: '#333', marginBottom: '1.5rem' }}>🛠️ Teknisk stack</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem' }}>
          <div style={{ padding: '1rem', background: '#f8f9fa', borderRadius: '8px' }}>
            <strong>Backend:</strong> Next.js 14 API Routes + Prisma ORM
          </div>
          <div style={{ padding: '1rem', background: '#f8f9fa', borderRadius: '8px' }}>
            <strong>Databas:</strong> PostgreSQL med optimerade queries
          </div>
          <div style={{ padding: '1rem', background: '#f8f9fa', borderRadius: '8px' }}>
            <strong>Caching:</strong> Redis för snabba API-svar
          </div>
          <div style={{ padding: '1rem', background: '#f8f9fa', borderRadius: '8px' }}>
            <strong>Frontend:</strong> React 18 + TypeScript
          </div>
          <div style={{ padding: '1rem', background: '#f8f9fa', borderRadius: '8px' }}>
            <strong>Deployment:</strong> Vercel-ready med CI/CD
          </div>
          <div style={{ padding: '1rem', background: '#f8f9fa', borderRadius: '8px' }}>
            <strong>Monitoring:</strong> Sentry + PostHog analytics
          </div>
        </div>
      </div>
    </div>
  );
}