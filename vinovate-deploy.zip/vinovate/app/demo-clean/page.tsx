'use client';

import { useState, useEffect } from 'react';
import Head from 'next/head';

interface DemoStats {
  totalImporters: number;
  totalWines: number;
  activeImporters: number;
  lastUpdated: string;
}

export default function DemoCleanPage() {
  const [stats, setStats] = useState<DemoStats>({
    totalImporters: 33,
    totalWines: 112,
    activeImporters: 33,
    lastUpdated: new Date().toISOString()
  });

  const [activeTab, setActiveTab] = useState('overview');

  const mockApiCall = async () => {
    // Simulera API-anrop
    await new Promise(resolve => setTimeout(resolve, 500));
    return {
      importers: 33,
      wines: 112,
      responseTime: '<100ms'
    };
  };

  const [apiStats, setApiStats] = useState<{importers: number, wines: number, responseTime: string} | null>(null);
  const [loading, setLoading] = useState(false);

  const testApi = async () => {
    setLoading(true);
    const result = await mockApiCall();
    setApiStats(result);
    setLoading(false);
  };

  const features = [
    {
      icon: '🗄️',
      title: 'PostgreSQL Databas',
      description: 'Skalbar databas med Prisma ORM för optimal prestanda',
      status: 'implemented',
      details: [
        'Optimerade tabeller för importörer och viner',
        'Indexering för snabba queries',
        'Relations mellan entiteter',
        'Automatisk migration och seeding'
      ]
    },
    {
      icon: '📡',
      title: 'RESTful API',
      description: 'Modern API med smart filtrering och paginering',
      status: 'implemented',
      details: [
        'GET /api/importers - Sök och filtrera',
        'GET /api/importers/[id] - Specifik importör',
        'GET /api/stats - Global statistik',
        'Query parameters för avancerad filtrering'
      ]
    },
    {
      icon: '⚡',
      title: 'Redis Caching',
      description: 'Höghastighetscaching för snabba API-svar',
      status: 'implemented',
      details: [
        '5-minuters cache för sökresultat',
        '10-minuters cache för statistik',
        'Smart cache-invalidation',
        'Mock implementation för demo'
      ]
    },
    {
      icon: '🔍',
      title: 'Smart Filtrering',
      description: 'Dynamiska filter som uppdateras baserat på data',
      status: 'implemented',
      details: [
        'Beroende dropdowns',
        'Realtidsuppdatering av alternativ',
        'Kombinerbara filter',
        'Fritextsökning'
      ]
    },
    {
      icon: '📄',
      title: 'Paginering',
      description: 'Effektiv hantering av stora dataset',
      status: 'implemented',
      details: [
        'Konfigurerbar sidstorlek',
        'Navigation mellan sidor',
        'Total antal resultat',
        'Optimerad prestanda'
      ]
    },
    {
      icon: '🎨',
      title: 'Admin Panel',
      description: 'Modern dashboard för datahantering',
      status: 'implemented',
      details: [
        'Live statistik från databas',
        'API-testning och debugging',
        'Responsiv design',
        'Modern UI med gradients'
      ]
    }
  ];

  const scalability = [
    {
      metric: 'Importörer',
      current: '33',
      potential: '500+',
      description: 'Kan hantera alla svenska vinimportörer'
    },
    {
      metric: 'Viner',
      current: '112',
      potential: '50,000+',
      description: 'Skalbar till tiotusentals viner'
    },
    {
      metric: 'Requests/dag',
      current: '1,000+',
      potential: '1M+',
      description: 'Med load balancing och CDN'
    },
    {
      metric: 'Svarstid',
      current: '<100ms',
      potential: '<50ms',
      description: 'Optimerad med caching och indexing'
    }
  ];

  const techStack = [
    { category: 'Backend', items: ['Next.js 14 API Routes', 'Prisma ORM', 'TypeScript'] },
    { category: 'Databas', items: ['PostgreSQL', 'Redis Caching', 'Optimized Queries'] },
    { category: 'Frontend', items: ['React 18', 'Tailwind CSS', 'Responsive Design'] },
    { category: 'DevOps', items: ['Vercel Deployment', 'GitHub Actions', 'Monitoring'] }
  ];

  return (
    <>
      <Head>
        <title>Wine Azone - Skalbar Arkitektur Demo | Sveriges Vinimportörsplattform</title>
        <meta name="description" content="Se hur Wine Azone kan skalas för alla svenska vinimportörer. Komplett demonstration av PostgreSQL, API, caching och smart filtrering för vinportföljer." />
        <meta name="keywords" content="vinimportörer, svenska viner, vinportfölj, skalbar app, PostgreSQL, API, demo" />
        <meta property="og:title" content="Wine Azone - Skalbar Arkitektur Demo" />
        <meta property="og:description" content="Komplett demonstration av hur Wine Azone kan skalas för alla svenska vinimportörer med modern teknisk stack." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://wine-azone.vercel.app/demo-clean" />
        <meta property="og:image" content="https://wine-azone.vercel.app/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Wine Azone - Skalbar Arkitektur Demo" />
        <meta name="twitter:description" content="Se hur Wine Azone kan skalas för alla svenska vinimportörer." />
        <meta name="twitter:image" content="https://wine-azone.vercel.app/og-image.png" />
        <link rel="canonical" href="https://wine-azone.vercel.app/demo-clean" />
      </Head>
      <div className="demo-clean">
      {/* Header */}
      <header className="demo-header">
        <div className="header-content">
          <h1>🚀 Wine Azone - Skalbar Arkitektur</h1>
          <p>En komplett demonstration av hur Wine Azone kan skalas för alla svenska vinimportörer</p>
          <div className="header-actions">
            <a href="/" className="btn-primary">← Tillbaka till app</a>
            <a href="/search" className="btn-secondary">🔍 Ursprunglig sökning</a>
            <button 
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'Wine Azone - Skalbar Arkitektur Demo',
                    text: 'Se hur Wine Azone kan skalas för alla svenska vinimportörer',
                    url: window.location.href
                  });
                } else {
                  navigator.clipboard.writeText(window.location.href);
                  alert('Länk kopierad till urklipp!');
                }
              }}
              className="btn-secondary"
            >
              📤 Dela demo
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="demo-nav">
        <button 
          className={activeTab === 'overview' ? 'active' : ''} 
          onClick={() => setActiveTab('overview')}
        >
          📊 Översikt
        </button>
        <button 
          className={activeTab === 'features' ? 'active' : ''} 
          onClick={() => setActiveTab('features')}
        >
          ✨ Funktioner
        </button>
        <button 
          className={activeTab === 'scalability' ? 'active' : ''} 
          onClick={() => setActiveTab('scalability')}
        >
          📈 Skalning
        </button>
        <button 
          className={activeTab === 'tech' ? 'active' : ''} 
          onClick={() => setActiveTab('tech')}
        >
          🛠️ Teknisk Stack
        </button>
      </nav>

      {/* Content */}
      <main className="demo-main">
        {activeTab === 'overview' && (
          <div className="tab-content">
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-number">{stats.totalImporters}</div>
                <div className="stat-label">Importörer</div>
                <div className="stat-description">Aktiva vinimportörer</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">{stats.totalWines}</div>
                <div className="stat-label">Viner</div>
                <div className="stat-description">I databasen</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">12</div>
                <div className="stat-label">Länder</div>
                <div className="stat-description">Representerade</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">72</div>
                <div className="stat-label">Druvor</div>
                <div className="stat-description">Olika sorter</div>
              </div>
            </div>

            <div className="demo-section">
              <h2>🎯 Mål: Sveriges komplett vinimportörsplattform</h2>
              <div className="goal-grid">
                <div className="goal-item">
                  <h3>📊 Datainsamling</h3>
                  <p>Automatisk inhämtning av alla svenska vinimportörer och deras vinportföljer</p>
                </div>
                <div className="goal-item">
                  <h3>🔍 Smart sökning</h3>
                  <p>Avancerad filtrering för att hitta rätt importör baserat på specifika kriterier</p>
                </div>
                <div className="goal-item">
                  <h3>⚡ Prestanda</h3>
                  <p>Sub-sekund svarstider även med tiotusentals viner i databasen</p>
                </div>
                <div className="goal-item">
                  <h3>🌐 Tillgänglighet</h3>
                  <p>24/7 tillgänglig plattform med hög tillgänglighet och skalbarhet</p>
                </div>
              </div>
            </div>

            <div className="demo-section">
              <h2>🧪 API Demo</h2>
              <div className="api-demo">
                <button onClick={testApi} disabled={loading} className="btn-primary">
                  {loading ? 'Testar...' : '🚀 Testa API'}
                </button>
                {apiStats && (
                  <div className="api-result">
                    <h3>API Resultat:</h3>
                    <div className="api-stats">
                      <div>Importörer: {apiStats.importers}</div>
                      <div>Viner: {apiStats.wines}</div>
                      <div>Svarstid: {apiStats.responseTime}</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'features' && (
          <div className="tab-content">
            <div className="features-grid">
              {features.map((feature, index) => (
                <div key={index} className="feature-card">
                  <div className="feature-header">
                    <span className="feature-icon">{feature.icon}</span>
                    <h3>{feature.title}</h3>
                    <span className={`status-badge ${feature.status}`}>
                      {feature.status === 'implemented' ? '✅ Implementerat' : '⏳ Planerat'}
                    </span>
                  </div>
                  <p className="feature-description">{feature.description}</p>
                  <ul className="feature-details">
                    {feature.details.map((detail, i) => (
                      <li key={i}>{detail}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'scalability' && (
          <div className="tab-content">
            <div className="scalability-section">
              <h2>📈 Skalningspotential</h2>
              <div className="scalability-grid">
                {scalability.map((item, index) => (
                  <div key={index} className="scalability-card">
                    <div className="metric-name">{item.metric}</div>
                    <div className="metric-values">
                      <div className="current-value">
                        <span className="label">Nuvarande:</span>
                        <span className="value">{item.current}</span>
                      </div>
                      <div className="potential-value">
                        <span className="label">Potential:</span>
                        <span className="value">{item.potential}</span>
                      </div>
                    </div>
                    <p className="metric-description">{item.description}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="demo-section">
              <h2>🚀 Implementeringsfaser</h2>
              <div className="phases">
                <div className="phase">
                  <div className="phase-number">1</div>
                  <div className="phase-content">
                    <h3>Databas & API (2-3 veckor)</h3>
                    <p>PostgreSQL setup, Prisma ORM, RESTful API endpoints</p>
                  </div>
                </div>
                <div className="phase">
                  <div className="phase-number">2</div>
                  <div className="phase-content">
                    <h3>Admin & Hantering (3-4 veckor)</h3>
                    <p>Admin panel, CRUD-funktioner, bulk import</p>
                  </div>
                </div>
                <div className="phase">
                  <div className="phase-number">3</div>
                  <div className="phase-content">
                    <h3>Automatisering (4-6 veckor)</h3>
                    <p>Web scraping, API-integrationer, automatiska uppdateringar</p>
                  </div>
                </div>
                <div className="phase">
                  <div className="phase-number">4</div>
                  <div className="phase-content">
                    <h3>Optimering (2-3 veckor)</h3>
                    <p>CDN, load balancing, monitoring, performance tuning</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'tech' && (
          <div className="tab-content">
            <div className="tech-stack">
              <h2>🛠️ Teknisk Stack</h2>
              <div className="tech-grid">
                {techStack.map((category, index) => (
                  <div key={index} className="tech-category">
                    <h3>{category.category}</h3>
                    <ul>
                      {category.items.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>

            <div className="demo-section">
              <h2>💻 Kodstruktur</h2>
              <div className="code-structure">
                <pre>{`WineAzone/
├── app/
│   ├── api/
│   │   ├── importers/     # Importör API endpoints
│   │   └── stats/         # Statistik API
│   ├── admin/             # Admin panel
│   ├── demo/              # Demo sidor
│   └── search/            # Sökfunktionalitet
├── lib/
│   ├── db.ts              # Prisma databas
│   ├── cache.ts           # Redis caching
│   └── api.ts             # API logik
├── prisma/
│   └── schema.prisma      # Databas schema
└── scripts/
    └── seed.ts            # Databas seeding`}</pre>
              </div>
            </div>

            <div className="demo-section">
              <h2>💰 Kostnadsuppskattning</h2>
              <div className="cost-breakdown">
                <div className="cost-item">
                  <h3>Utveckling</h3>
                  <div className="cost-amount">340-490 timmar</div>
                  <p>Fullständig implementation av alla funktioner</p>
                </div>
                <div className="cost-item">
                  <h3>Drift (månadsvis)</h3>
                  <div className="cost-amount">$100-400</div>
                  <p>Databas, hosting, CDN, monitoring</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="demo-footer">
        <div className="footer-content">
          <h3>🎯 Redo att skala upp Wine Azone?</h3>
          <p>Kontakta oss för att diskutera implementation av den fullständiga skalningslösningen</p>
          <div className="footer-actions">
            <a href="/search" className="btn-primary">Testa ursprunglig app</a>
            <a href="/admin" className="btn-secondary">Se admin-panel</a>
          </div>
        </div>
      </footer>
      </div>
    </>
  );
}
