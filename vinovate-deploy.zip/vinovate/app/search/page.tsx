'use client';

import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { SearchFilters, Wine, Importer } from '@/types';
import { 
  importers, 
  getAllCountries, 
  getAllRegions, 
  getAllGrapeVarieties,
  getAllWineTypes,
  getAllPriceRanges
} from '@/data/importers';
import { searchImporters, getMatchingWinesCount } from '@/utils/search';
import { getMatchingWines } from '@/utils/wineFilter';
import { 
  getAvailableCountries, 
  getAvailableRegions, 
  getAvailableGrapeVarieties,
  getAvailableTypes,
  getAvailablePriceRanges
} from '@/utils/smartFilters';
import WineModal from '@/components/WineModal';

export default function SearchPage() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  
  const [filters, setFilters] = useState<SearchFilters>({
    searchTerm: initialQuery
  });
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedImporter, setSelectedImporter] = useState<Importer | null>(null);

  const openWineModal = (importer: Importer) => {
    setSelectedImporter(importer);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setSelectedImporter(null);
  };

  // Smart filtering - uppdaterar tillgängliga alternativ baserat på valda filter
  const availableCountries = useMemo(() => getAvailableCountries(importers, filters), [filters]);
  const availableRegions = useMemo(() => getAvailableRegions(importers, filters), [filters]);
  const availableGrapeVarieties = useMemo(() => getAvailableGrapeVarieties(importers, filters), [filters]);
  const availableTypes = useMemo(() => getAvailableTypes(importers, filters), [filters]);
  const availablePriceRanges = useMemo(() => getAvailablePriceRanges(importers, filters), [filters]);

  const filteredImporters = useMemo(() => {
    return searchImporters(importers, filters);
  }, [filters]);

  useEffect(() => {
    if (initialQuery) {
      setFilters(prev => ({ ...prev, searchTerm: initialQuery }));
    }
  }, [initialQuery]);

  const handleFilterChange = (key: keyof SearchFilters, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value || undefined
    }));
  };

  const handleCheckboxChange = (key: 'sellsToRestaurants' | 'sellsToPrivate', checked: boolean) => {
    setFilters(prev => ({
      ...prev,
      [key]: checked ? true : undefined
    }));
  };

  const clearFilters = () => {
    setFilters({});
  };

  const hasActiveFilters = Object.keys(filters).some(key => 
    filters[key as keyof SearchFilters] !== undefined
  );

  return (
    <>
      <header className="search-header">
        <div className="container">
          <h1>
            <a href="/" style={{ textDecoration: 'none', color: 'inherit' }}>
              🍷 Wine Azone
            </a>
          </h1>
          <p>Sök bland {importers.length} vinimportörer</p>
        </div>
      </header>

      <main className="container">
        <section className="search-section">
          <h2>Filtrera vinimportörer</h2>
          
          <input
            type="text"
            className="search-input"
            placeholder="Sök efter importör, specialitet eller beskrivning..."
            value={filters.searchTerm || ''}
            onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
          />

          <div className="filters-grid">
            <div className="filter-group">
              <label htmlFor="country">Land</label>
              <select
                id="country"
                value={filters.country || ''}
                onChange={(e) => handleFilterChange('country', e.target.value)}
              >
                <option value="">Alla länder ({availableCountries.length})</option>
                {availableCountries.map(country => (
                  <option key={country} value={country}>{country}</option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label htmlFor="region">Region</label>
              <select
                id="region"
                value={filters.region || ''}
                onChange={(e) => handleFilterChange('region', e.target.value)}
              >
                <option value="">Alla regioner ({availableRegions.length})</option>
                {availableRegions.map(region => (
                  <option key={region} value={region}>{region}</option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label htmlFor="type">Vintyp</label>
              <select
                id="type"
                value={filters.type || ''}
                onChange={(e) => handleFilterChange('type', e.target.value)}
              >
                <option value="">Alla typer ({availableTypes.length})</option>
                {availableTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label htmlFor="grape">Druva</label>
              <select
                id="grape"
                value={filters.grapeVariety || ''}
                onChange={(e) => handleFilterChange('grapeVariety', e.target.value)}
              >
                <option value="">Alla druvor ({availableGrapeVarieties.length})</option>
                {availableGrapeVarieties.map(grape => (
                  <option key={grape} value={grape}>{grape}</option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label htmlFor="price">Prisintervall</label>
              <select
                id="price"
                value={filters.priceRange || ''}
                onChange={(e) => handleFilterChange('priceRange', e.target.value)}
              >
                <option value="">Alla priser ({availablePriceRanges.length})</option>
                {availablePriceRanges.map(range => (
                  <option key={range} value={range}>{range}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="checkbox-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={filters.sellsToRestaurants || false}
                onChange={(e) => handleCheckboxChange('sellsToRestaurants', e.target.checked)}
              />
              Säljer till restauranger
            </label>

            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={filters.sellsToPrivate || false}
                onChange={(e) => handleCheckboxChange('sellsToPrivate', e.target.checked)}
              />
              Säljer till privatpersoner
            </label>

            {hasActiveFilters && (
              <button className="clear-button" onClick={clearFilters}>
                Rensa filter
              </button>
            )}
          </div>
        </section>

        <div className="results-header">
          <h3>
            {filteredImporters.length === 0 
              ? 'Inga importörer hittades' 
              : `Hittade ${filteredImporters.length} importör${filteredImporters.length !== 1 ? 'er' : ''}`
            }
          </h3>
        </div>

        {filteredImporters.length > 0 ? (
          <div className="results-grid">
            {filteredImporters.map(importer => {
              const matchingWinesCount = hasActiveFilters 
                ? getMatchingWinesCount(importer, filters)
                : importer.portfolio.length;

              return (
                <div key={importer.id} className="importer-card">
                  <div className="importer-header">
                    <h3 className="importer-name">{importer.name}</h3>
                  </div>

                  <p className="importer-description">{importer.description}</p>

                  <div className="importer-badges">
                    {importer.sellsToRestaurants && (
                      <span className="badge restaurant">🍽️ Restauranger</span>
                    )}
                    {importer.sellsToPrivate && (
                      <span className="badge private">👤 Privatpersoner</span>
                    )}
                  </div>

                  {importer.specialties.length > 0 && (
                    <div className="specialties">
                      <h4>Specialiteter:</h4>
                      <div className="specialty-tags">
                        {importer.specialties.map((specialty, index) => (
                          <span key={index} className="specialty-tag">
                            {specialty}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div 
                    className="portfolio-info clickable"
                    onClick={() => openWineModal(importer)}
                  >
                    <p>
                      📦 {matchingWinesCount} matchande vin av {importer.portfolio.length} totalt i portföljen
                      <span className="expand-indicator"> 🔍 Visa viner</span>
                    </p>
                  </div>

                  {(importer.contactEmail || importer.contactPhone) && (
                    <div className="contact-info">
                      {importer.contactEmail && (
                        <p>📧 {importer.contactEmail}</p>
                      )}
                      {importer.contactPhone && (
                        <p>📞 {importer.contactPhone}</p>
                      )}
                    </div>
                  )}

                  <a 
                    href={importer.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="visit-website"
                  >
                    Besök hemsida →
                  </a>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="no-results">
            <h3>Inga importörer hittades</h3>
            <p>Prova att ändra dina sökkriterier eller rensa filtren</p>
          </div>
        )}

        {selectedImporter && (
          <WineModal
            isOpen={modalOpen}
            onClose={closeModal}
            wines={getMatchingWines(selectedImporter.portfolio, filters)}
            importerName={selectedImporter.name}
            totalWines={selectedImporter.portfolio.length}
          />
        )}
      </main>
    </>
  );
}

