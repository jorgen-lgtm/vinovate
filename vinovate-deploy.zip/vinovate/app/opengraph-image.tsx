import { ImageResponse } from 'next/og'

export const runtime = 'edge'

export const alt = 'Wine Azone - Sveriges Vinimportörsplattform'
export const size = {
  width: 1200,
  height: 630,
}
export const contentType = 'image/png'

export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'column',
          color: 'white',
          fontFamily: 'system-ui, sans-serif',
        }}
      >
        <div
          style={{
            fontSize: 120,
            marginBottom: 20,
          }}
        >
          🍷
        </div>
        <div
          style={{
            fontSize: 72,
            fontWeight: 'bold',
            textAlign: 'center',
            marginBottom: 20,
          }}
        >
          Wine Azone
        </div>
        <div
          style={{
            fontSize: 36,
            textAlign: 'center',
            opacity: 0.9,
            maxWidth: 800,
            lineHeight: 1.2,
          }}
        >
          Sveriges Vinimportörsplattform
        </div>
        <div
          style={{
            fontSize: 24,
            textAlign: 'center',
            opacity: 0.8,
            marginTop: 20,
          }}
        >
          33+ Importörer • 112+ Viner • Smart Sökning
        </div>
      </div>
    ),
    {
      ...size,
    }
  )
}
