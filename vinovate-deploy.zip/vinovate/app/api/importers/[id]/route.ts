import { NextRequest, NextResponse } from 'next/server';
import { getImporterById } from '@/lib/api';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const importer = await getImporterById(params.id);
    
    if (!importer) {
      return NextResponse.json(
        { error: 'Importer not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(importer);
  } catch (error) {
    console.error('Error fetching importer:', error);
    return NextResponse.json(
      { error: 'Failed to fetch importer' },
      { status: 500 }
    );
  }
}
