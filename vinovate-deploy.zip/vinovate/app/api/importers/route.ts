import { NextRequest, NextResponse } from 'next/server';
import { searchImporters, getAvailableFilterOptions } from '@/lib/api';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    const filters = {
      country: searchParams.get('country') || undefined,
      region: searchParams.get('region') || undefined,
      grapeVariety: searchParams.get('grapeVariety') || undefined,
      type: searchParams.get('type') || undefined,
      priceRange: searchParams.get('priceRange') || undefined,
      sellsToRestaurants: searchParams.get('sellsToRestaurants') === 'true' ? true : 
                         searchParams.get('sellsToRestaurants') === 'false' ? false : undefined,
      sellsToPrivate: searchParams.get('sellsToPrivate') === 'true' ? true : 
                     searchParams.get('sellsToPrivate') === 'false' ? false : undefined,
      searchTerm: searchParams.get('searchTerm') || undefined,
      page: parseInt(searchParams.get('page') || '1'),
      limit: parseInt(searchParams.get('limit') || '20')
    };

    const [results, filterOptions] = await Promise.all([
      searchImporters(filters),
      getAvailableFilterOptions(filters)
    ]);

    return NextResponse.json({
      ...results,
      filterOptions
    });
  } catch (error) {
    console.error('Error fetching importers:', error);
    return NextResponse.json(
      { error: 'Failed to fetch importers' },
      { status: 500 }
    );
  }
}
