import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'Vinovate - Hitta Sveriges Vinimportörer',
    template: '%s | Vinovate'
  },
  description: 'Sök och hitta vinimportörer i Sverige baserat på land, druva, pris och mer. Över 33 importörer med 112+ viner.',
  keywords: ['vinimportörer', 'svenska viner', 'vinportfölj', 'vinhandel', 'restaurang', 'naturvin'],
  authors: [{ name: 'Vinovate' }],
  creator: 'Vinovate',
  publisher: 'Vinovate',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL('https://wine-azone.vercel.app'),
  alternates: {
    canonical: '/',
  },
  openGraph: {
    type: 'website',
    locale: 'sv_SE',
    url: 'https://wine-azone.vercel.app',
    title: 'Wine Azone - Hitta Sveriges Vinimportörer',
    description: 'Sök och hitta vinimportörer i Sverige baserat på land, druva, pris och mer.',
    siteName: 'Wine Azone',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Wine Azone - Hitta Sveriges Vinimportörer',
    description: 'Sök och hitta vinimportörer i Sverige baserat på land, druva, pris och mer.',
    creator: '@wineazone',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="sv">
      <body>{children}</body>
    </html>
  );
}

