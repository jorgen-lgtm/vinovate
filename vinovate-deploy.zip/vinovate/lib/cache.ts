// Mock Redis cache för demo
class MockRedis {
  private cache = new Map<string, { value: any; expires: number }>();

  async get(key: string): Promise<string | null> {
    const item = this.cache.get(key);
    if (!item) return null;
    
    if (Date.now() > item.expires) {
      this.cache.delete(key);
      return null;
    }
    
    return JSON.stringify(item.value);
  }

  async setex(key: string, seconds: number, value: string): Promise<void> {
    this.cache.set(key, {
      value: JSON.parse(value),
      expires: Date.now() + (seconds * 1000)
    });
  }

  async del(key: string): Promise<void> {
    this.cache.delete(key);
  }

  async flushall(): Promise<void> {
    this.cache.clear();
  }
}

export const redis = new MockRedis();

// Cache keys
export const CACHE_KEYS = {
  importers: (filters: any) => `importers:${JSON.stringify(filters)}`,
  importer: (id: string) => `importer:${id}`,
  wines: (filters: any) => `wines:${JSON.stringify(filters)}`,
  stats: () => 'stats:global'
} as const;
