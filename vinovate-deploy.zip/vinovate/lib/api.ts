import { db } from './db';
import { redis, CACHE_KEYS } from './cache';

export interface SearchFilters {
  country?: string;
  region?: string;
  grapeVariety?: string;
  type?: string;
  priceRange?: string;
  sellsToRestaurants?: boolean;
  sellsToPrivate?: boolean;
  searchTerm?: string;
  page?: number;
  limit?: number;
}

export interface SearchResult {
  importers: any[];
  total: number;
  page: number;
  totalPages: number;
}

export async function searchImporters(filters: SearchFilters): Promise<SearchResult> {
  const cacheKey = CACHE_KEYS.importers(filters);
  
  // Try cache first
  const cached = await redis.get(cacheKey);
  if (cached) {
    return JSON.parse(cached);
  }

  const page = filters.page || 1;
  const limit = filters.limit || 20;
  const skip = (page - 1) * limit;

  // Build where clause
  const where: any = {
    isActive: true,
    wines: {
      some: {}
    }
  };

  // Filter by search term
  if (filters.searchTerm) {
    const searchTerm = filters.searchTerm.toLowerCase();
    where.OR = [
      { name: { contains: searchTerm, mode: 'insensitive' } },
      { description: { contains: searchTerm, mode: 'insensitive' } },
      { specialties: { hasSome: [searchTerm] } }
    ];
  }

  // Filter by sales channels
  if (filters.sellsToRestaurants !== undefined) {
    where.sellsToRestaurants = filters.sellsToRestaurants;
  }
  if (filters.sellsToPrivate !== undefined) {
    where.sellsToPrivate = filters.sellsToPrivate;
  }

  // Filter by wine properties
  if (filters.country || filters.region || filters.type || filters.priceRange || filters.grapeVariety) {
    where.wines = {
      some: {
        ...(filters.country && { country: filters.country }),
        ...(filters.region && { region: filters.region }),
        ...(filters.type && { type: filters.type }),
        ...(filters.priceRange && { priceRange: filters.priceRange }),
        ...(filters.grapeVariety && { grapeVarieties: { has: filters.grapeVariety } })
      }
    };
  }

  // Execute query
  const [importers, total] = await Promise.all([
    db.importer.findMany({
      where,
      include: {
        wines: {
          where: {
            ...(filters.country && { country: filters.country }),
            ...(filters.region && { region: filters.region }),
            ...(filters.type && { type: filters.type }),
            ...(filters.priceRange && { priceRange: filters.priceRange }),
            ...(filters.grapeVariety && { grapeVarieties: { has: filters.grapeVariety } })
          }
        },
        _count: {
          select: { wines: true }
        }
      },
      skip,
      take: limit,
      orderBy: { name: 'asc' }
    }),
    db.importer.count({ where })
  ]);

  const result: SearchResult = {
    importers,
    total,
    page,
    totalPages: Math.ceil(total / limit)
  };

  // Cache for 5 minutes
  await redis.setex(cacheKey, 300, JSON.stringify(result));

  return result;
}

export async function getImporterById(id: string) {
  const cacheKey = CACHE_KEYS.importer(id);
  
  const cached = await redis.get(cacheKey);
  if (cached) {
    return JSON.parse(cached);
  }

  const importer = await db.importer.findUnique({
    where: { id },
    include: {
      wines: {
        orderBy: { name: 'asc' }
      },
      _count: {
        select: { wines: true }
      }
    }
  });

  if (importer) {
    await redis.setex(cacheKey, 300, JSON.stringify(importer));
  }

  return importer;
}

export async function getAvailableFilterOptions(filters: SearchFilters = {}) {
  const cacheKey = `filter_options:${JSON.stringify(filters)}`;
  
  const cached = await redis.get(cacheKey);
  if (cached) {
    return JSON.parse(cached);
  }

  // Base where clause for active importers with wines
  const baseWhere = {
    isActive: true,
    wines: { some: {} }
  };

  // Apply search term filter
  let where: any = baseWhere;
  if (filters.searchTerm) {
    const searchTerm = filters.searchTerm.toLowerCase();
    where = {
      ...baseWhere,
      OR: [
        { name: { contains: searchTerm, mode: 'insensitive' } },
        { description: { contains: searchTerm, mode: 'insensitive' } },
        { specialties: { hasSome: [searchTerm] } }
      ]
    };
  }

  // Apply sales channel filters
  if (filters.sellsToRestaurants !== undefined) {
    where.sellsToRestaurants = filters.sellsToRestaurants;
  }
  if (filters.sellsToPrivate !== undefined) {
    where.sellsToPrivate = filters.sellsToPrivate;
  }

  // Get unique values for each filter
  const [countries, regions, types, priceRanges, grapeVarieties] = await Promise.all([
    db.wine.findMany({
      where: {
        importer: where,
        ...(filters.region && { region: filters.region }),
        ...(filters.type && { type: filters.type }),
        ...(filters.priceRange && { priceRange: filters.priceRange }),
        ...(filters.grapeVariety && { grapeVarieties: { has: filters.grapeVariety } })
      },
      select: { country: true },
      distinct: ['country'],
      orderBy: { country: 'asc' }
    }),
    db.wine.findMany({
      where: {
        importer: where,
        ...(filters.country && { country: filters.country }),
        ...(filters.type && { type: filters.type }),
        ...(filters.priceRange && { priceRange: filters.priceRange }),
        ...(filters.grapeVariety && { grapeVarieties: { has: filters.grapeVariety } })
      },
      select: { region: true },
      distinct: ['region'],
      orderBy: { region: 'asc' }
    }),
    db.wine.findMany({
      where: {
        importer: where,
        ...(filters.country && { country: filters.country }),
        ...(filters.region && { region: filters.region }),
        ...(filters.priceRange && { priceRange: filters.priceRange }),
        ...(filters.grapeVariety && { grapeVarieties: { has: filters.grapeVariety } })
      },
      select: { type: true },
      distinct: ['type'],
      orderBy: { type: 'asc' }
    }),
    db.wine.findMany({
      where: {
        importer: where,
        ...(filters.country && { country: filters.country }),
        ...(filters.region && { region: filters.region }),
        ...(filters.type && { type: filters.type }),
        ...(filters.grapeVariety && { grapeVarieties: { has: filters.grapeVariety } })
      },
      select: { priceRange: true },
      distinct: ['priceRange'],
      orderBy: { priceRange: 'asc' }
    }),
    db.wine.findMany({
      where: {
        importer: where,
        ...(filters.country && { country: filters.country }),
        ...(filters.region && { region: filters.region }),
        ...(filters.type && { type: filters.type }),
        ...(filters.priceRange && { priceRange: filters.priceRange })
      },
      select: { grapeVarieties: true }
    })
  ]);

  // Extract unique grape varieties
  const uniqueGrapes = Array.from(
    new Set(
      grapeVarieties.flatMap(w => w.grapeVarieties)
    )
  ).sort();

  const result = {
    countries: countries.map(c => c.country),
    regions: regions.map(r => r.region),
    types: types.map(t => t.type),
    priceRanges: priceRanges.map(p => p.priceRange),
    grapeVarieties: uniqueGrapes
  };

  await redis.setex(cacheKey, 300, JSON.stringify(result));
  return result;
}

export async function getGlobalStats() {
  const cacheKey = CACHE_KEYS.stats();
  
  const cached = await redis.get(cacheKey);
  if (cached) {
    return JSON.parse(cached);
  }

  const [totalImporters, totalWines, activeImporters] = await Promise.all([
    db.importer.count(),
    db.wine.count(),
    db.importer.count({ where: { isActive: true } })
  ]);

  const stats = {
    totalImporters,
    totalWines,
    activeImporters,
    lastUpdated: new Date().toISOString()
  };

  await redis.setex(cacheKey, 600, JSON.stringify(stats)); // 10 min cache
  return stats;
}
