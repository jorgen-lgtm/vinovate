# 🚀 GitHub + Vercel Integration Guide

## Steg-för-steg guide för att deploya Wine Azone

### Steg 1: Skapa GitHub Repository

1. **Gå till GitHub:**
   - Öppna [github.com/new](https://github.com/new)
   - Logga in om du inte redan är inloggad

2. **Skapa nytt repository:**
   - Repository name: `wine-azone` (eller valfritt namn)
   - Description: `Swedish wine importer platform with smart search`
   - Välj: **Public** (eller Private om du föredrar)
   - **VIKTIGT:** Markera INTE "Initialize with README" (vi har redan kod)
   - Klicka "Create repository"

3. **Kopiera repository URL:**
   - Du får en URL som: `https://github.com/[ditt-användarnamn]/wine-azone.git`
   - Kopiera denna URL

### Steg 2: Koppla lokalt projekt till GitHub

Jag kommer att köra dessa kommandon åt dig när du ger mig din GitHub repository URL.

### Steg 3: Koppla till Vercel

1. **Gå till Vercel:**
   - Öppna [vercel.com/new](https://vercel.com/new)
   - Logga in

2. **Importera från GitHub:**
   - Klicka "Import Git Repository"
   - Välj ditt `wine-azone` repository
   - Klicka "Import"

3. **Konfigurera projekt:**
   - Project Name: `wine-azone` (eller valfritt)
   - Framework Preset: Next.js (upptäcks automatiskt)
   - Root Directory: `./`
   - Build Command: `npm run build` (standard)
   - Output Directory: `.next` (standard)
   - Klicka "Deploy"

### Steg 4: Vänta på deployment
- Tar 2-3 minuter
- Du får en live URL när det är klart!

---

## 🎯 Fördelar med GitHub-integration

✅ **Automatiska deployments** - Varje push till main = ny deployment
✅ **Preview deployments** - Varje branch får sin egen test-URL
✅ **Rollback** - Enkelt att återgå till tidigare versioner
✅ **Collaboration** - Enkelt att jobba i team
✅ **CI/CD** - Automatisk testing och deployment

---

## 📝 Nästa steg

**Ge mig din GitHub repository URL** så kopplar jag projektet och pushar koden! 

Format: `https://github.com/[användarnamn]/[repository-namn].git`

Eller säg bara när du har skapat repositoryt så hjälper jag dig vidare! 🚀
