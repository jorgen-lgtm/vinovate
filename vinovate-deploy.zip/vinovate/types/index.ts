export interface Wine {
  id: string;
  name: string;
  country: string;
  region: string;
  grapeVarieties: string[];
  type: 'Rött' | 'Vitt' | 'Rosé' | 'Mousserande' | 'Dessert' | 'Starkvin';
  priceRange: 'Under 100kr' | '100-200kr' | '200-400kr' | 'Över 400kr';
  year?: number;
  description?: string;
}

export interface Importer {
  id: string;
  name: string;
  website: string;
  description: string;
  contactEmail?: string;
  contactPhone?: string;
  sellsToRestaurants: boolean;
  sellsToPrivate: boolean;
  portfolio: Wine[];
  specialties: string[];
  logo?: string;
}

export interface SearchFilters {
  country?: string;
  region?: string;
  grapeVariety?: string;
  type?: string;
  priceRange?: string;
  sellsToRestaurants?: boolean;
  sellsToPrivate?: boolean;
  searchTerm?: string;
}

