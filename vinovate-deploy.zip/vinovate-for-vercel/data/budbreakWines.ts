import { Wine } from "@/types/wine";

// Budbreak.se prislista - Naturviner och biodynamiska viner
export const budbreakWines: Wine[] = [
  // ORANGE VINER
  {
    name: "Orange Wine",
    producer: "Radikon",
    type: "Orange vin",
    country: "Italien",
    region: "Friuli",
    year: "2020",
    price: 450,
    rating: 94,
    systembolagetNumber: "BB001",
    description: "Klassisk orange vin från Radikon med 7 månaders skalkontakt. Komplex och mineralisk med toner av aprikos, honung och kryddor.",
    foodPairing: ["Fisk", "Skaldjur", "Asiatisk mat", "Ost"],
    foodPairingDetails: [
      {
        dish: "Sashimi med ponzu",
        description: "Färsk fisk med japansk ponzu-sås.",
        why: "Orange vinets struktur och mineralitet kompletterar sashimins rena smaker perfekt.",
        recipe: "Ingredienser (4 portioner):\n- 200g färsk lax\n- 200g tonfisk\n- 4 msk ponzu\n- 1 lime\n- Wasabi\n\nInstruktioner:\n1. Skär fisken i tunna skivor.\n2. Lägg på tallrik.\n3. Servera med ponzu och wasabi.\n\nTillagningstid: 10 minuter\nPro-tips: Använd färsk fisk av hög kvalitet."
      }
    ],
    availability: "better",
    tastingNotes: "Aprikos, honung, mineralitet, kryddor. Komplex struktur.",
    servingTemperature: "12-14°C",
    bestDrinkingPeriod: "2023-2030",
    alcoholContent: "13%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 450,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  {
    name: "Ribolla Gialla",
    producer: "Gravner",
    type: "Orange vin",
    country: "Italien",
    region: "Friuli",
    year: "2018",
    price: 650,
    rating: 96,
    systembolagetNumber: "BB002",
    description: "Exklusiv orange vin från Gravner med 7 års lagring i amfora. Kraftfull och komplex med djupa mineraliska toner.",
    foodPairing: ["Vilt", "Truffel", "Hårda ostar"],
    foodPairingDetails: [
      {
        dish: "Vilt med svampsås",
        description: "Rostad hjort med svampsås och rotfrukter.",
        why: "Vinets kraft och komplexitet matchar vildköttets djupa smaker.",
        recipe: "Ingredienser (4 portioner):\n- 4 hjortfiléer\n- 200g svamp\n- 2 dl grädde\n- 1 dl rött vin\n- Rotfrukter\n\nInstruktioner:\n1. Rostar hjortfiléerna.\n2. Stek svamp och gör sås.\n3. Servera med rotfrukter.\n\nTillagningstid: 45 minuter\nPro-tips: Låt köttet vila innan servering."
      }
    ],
    availability: "better",
    tastingNotes: "Mineralitet, honung, aprikos, kryddor. Kraftfull struktur.",
    servingTemperature: "14-16°C",
    bestDrinkingPeriod: "2023-2035",
    alcoholContent: "14%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "Begränsat lager",
        price: 650,
        isPrivateImport: true,
        minimumOrder: "12 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },

  // NATURVINER - FRANKRIKE
  {
    name: "Le Clos du Tue-Boeuf",
    producer: "Puzelat",
    type: "Naturvin",
    country: "Frankrike",
    region: "Loire",
    year: "2021",
    price: 280,
    rating: 89,
    systembolagetNumber: "BB003",
    description: "Klassisk naturvin från Loire med Gamay och Pinot Noir. Fruktig och fräsch med levande syra.",
    foodPairing: ["Charkuterier", "Ost", "Lättare kött"],
    foodPairingDetails: [
      {
        dish: "Charcuterie-platta",
        description: "Uppläggning med olika charkuterier och ostar.",
        why: "Vinets syra och fruktighet balanserar charkuteriernas fett och salt.",
        recipe: "Ingredienser (4 portioner):\n- Olika charkuterier\n- Hårda och mjuka ostar\n- Nötter\n- Frukt\n\nInstruktioner:\n1. Lägg upp charkuterier.\n2. Tillsätt ostar.\n3. Garnera med nötter och frukt.\n\nTillagningstid: 15 minuter\nPro-tips: Servera rumstempererat."
      }
    ],
    availability: "quick",
    tastingNotes: "Röda bär, kryddor, mineralitet. Frisk syra.",
    servingTemperature: "12-14°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "12.5%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 280,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  {
    name: "La Soif du Mal",
    producer: "Domaine de la Sénéchalière",
    type: "Naturvin",
    country: "Frankrike",
    region: "Loire",
    year: "2020",
    price: 320,
    rating: 91,
    systembolagetNumber: "BB004",
    description: "Biodynamisk naturvin från Muscadet-regionen. Mineralisk och komplex med citrus och salt.",
    foodPairing: ["Skaldjur", "Fisk", "Ostron"],
    foodPairingDetails: [
      {
        dish: "Ostron med citron",
        description: "Färska ostron med citron och skaldjursvinaigrette.",
        why: "Vinets mineralitet och saltighet kompletterar ostronens smaker.",
        recipe: "Ingredienser (4 portioner):\n- 24 ostron\n- 2 citroner\n- Skaldjursvinaigrette\n- Färsk dill\n\nInstruktioner:\n1. Öppna ostronen.\n2. Servera med citron.\n3. Tillsätt vinaigrette och dill.\n\nTillagningstid: 20 minuter\nPro-tips: Servera direkt från havet."
      }
    ],
    availability: "better",
    tastingNotes: "Citrus, mineralitet, salt, aprikos. Komplex struktur.",
    servingTemperature: "8-10°C",
    bestDrinkingPeriod: "2023-2030",
    alcoholContent: "13%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 320,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },

  // PET NAT
  {
    name: "Pet Nat Rosé",
    producer: "La Garagista",
    type: "Mousserande naturvin",
    country: "USA",
    region: "Vermont",
    year: "2021",
    price: 380,
    rating: 88,
    systembolagetNumber: "BB005",
    description: "Naturlig mousserande rosé från Vermont. Fruktig och fräsch med fina bubblor.",
    foodPairing: ["Brunch", "Fisk", "Frukt"],
    foodPairingDetails: [
      {
        dish: "Brunch med räkor",
        description: "Klassisk brunch med kokta räkor och hollandaise.",
        why: "Vinets syra och bubblor kompletterar brunch-matens rika smaker.",
        recipe: "Ingredienser (4 portioner):\n- 400g kokta räkor\n- 4 ägg\n- Hollandaise\n- Toast\n\nInstruktioner:\n1. Koka äggen.\n2. Gör hollandaise.\n3. Servera med räkor och toast.\n\nTillagningstid: 20 minuter\nPro-tips: Servera med färsk dill."
      }
    ],
    availability: "quick",
    tastingNotes: "Röda bär, citrus, mineralitet. Fina bubblor.",
    servingTemperature: "6-8°C",
    bestDrinkingPeriod: "2023-2026",
    alcoholContent: "11.5%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 380,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },

  // BIODYNAMISKA VINER
  {
    name: "Biodynamic Chardonnay",
    producer: "Domaine de la Côte",
    type: "Biodynamiskt vin",
    country: "Frankrike",
    region: "Bourgogne",
    year: "2020",
    price: 420,
    rating: 92,
    systembolagetNumber: "BB006",
    description: "Biodynamisk Chardonnay från Bourgogne. Elegant och mineralisk med komplex struktur.",
    foodPairing: ["Fisk", "Kyckling", "Ost"],
    foodPairingDetails: [
      {
        dish: "Grillad kyckling med citron",
        description: "Hel kyckling grillad med citron och örter.",
        why: "Vinets syra och mineralitet balanserar kycklingens feta smaker.",
        recipe: "Ingredienser (4 portioner):\n- 1 hel kyckling\n- 2 citroner\n- Örter\n- Olivolja\n\nInstruktioner:\n1. Krydda kycklingen.\n2. Fyll med citron och örter.\n3. Grilla i 45 minuter.\n\nTillagningstid: 1 timme\nPro-tips: Låt vila 10 minuter innan servering."
      }
    ],
    availability: "better",
    tastingNotes: "Citrus, mineralitet, smör, nötter. Elegant struktur.",
    servingTemperature: "10-12°C",
    bestDrinkingPeriod: "2023-2030",
    alcoholContent: "13.5%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 420,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },

  // ITALIENSKA NATURVINER
  {
    name: "Naturale",
    producer: "Cantina Giardino",
    type: "Naturvin",
    country: "Italien",
    region: "Campania",
    year: "2021",
    price: 350,
    rating: 90,
    systembolagetNumber: "BB007",
    description: "Naturvin från Campania med Aglianico. Kraftfull och fruktig med italiensk karaktär.",
    foodPairing: ["Pasta", "Kött", "Ost"],
    foodPairingDetails: [
      {
        dish: "Pasta alla Norma",
        description: "Klassisk siciliansk pasta med aubergine och ricotta.",
        why: "Vinets struktur och fruktighet kompletterar pastans rika smaker.",
        recipe: "Ingredienser (4 portioner):\n- 400g pasta\n- 2 auberginer\n- 400g krossade tomater\n- Ricotta\n- Basilika\n\nInstruktioner:\n1. Stek aubergine.\n2. Gör tomatsås.\n3. Blanda med pasta.\n4. Toppa med ricotta.\n\nTillagningstid: 30 minuter\nPro-tips: Använd färsk basilika."
      }
    ],
    availability: "quick",
    tastingNotes: "Mörka bär, kryddor, mineralitet. Kraftfull struktur.",
    servingTemperature: "14-16°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "13%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 350,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },

  // SPANSKA NATURVINER
  {
    name: "Vino de Parcela",
    producer: "Comando G",
    type: "Naturvin",
    country: "Spanien",
    region: "Gredos",
    year: "2020",
    price: 480,
    rating: 93,
    systembolagetNumber: "BB008",
    description: "Naturvin från Gredos med Garnacha. Mineralisk och elegant med bergskaraktär.",
    foodPairing: ["Lamm", "Svamp", "Ost"],
    foodPairingDetails: [
      {
        dish: "Lammrack med svamp",
        description: "Grillad lammrack med svamp och rotfrukter.",
        why: "Vinets mineralitet och struktur matchar lammets smaker.",
        recipe: "Ingredienser (4 portioner):\n- 4 lammrack\n- 200g svamp\n- Rotfrukter\n- Rosmarin\n\nInstruktioner:\n1. Krydda lammracken.\n2. Grilla till önskad stekgrad.\n3. Stek svamp och rotfrukter.\n\nTillagningstid: 30 minuter\nPro-tips: Låt köttet vila innan servering."
      }
    ],
    availability: "better",
    tastingNotes: "Röda bär, mineralitet, kryddor. Elegant struktur.",
    servingTemperature: "14-16°C",
    bestDrinkingPeriod: "2023-2030",
    alcoholContent: "14%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "Begränsat lager",
        price: 480,
        isPrivateImport: true,
        minimumOrder: "12 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },

  // ÖSTERRIKISKA NATURVINER
  {
    name: "Naturwein",
    producer: "Sepp Muster",
    type: "Naturvin",
    country: "Österrike",
    region: "Steiermark",
    year: "2021",
    price: 320,
    rating: 89,
    systembolagetNumber: "BB009",
    description: "Naturvin från Steiermark med Sauvignon Blanc. Frisk och mineralisk med alpin karaktär.",
    foodPairing: ["Fisk", "Skaldjur", "Vegetariskt"],
    foodPairingDetails: [
      {
        dish: "Vegetarisk risotto",
        description: "Krämig risotto med grönsaker och parmesan.",
        why: "Vinets syra och mineralitet balanserar risottons krämighet.",
        recipe: "Ingredienser (4 portioner):\n- 300g risotto\n- Grönsaker\n- 1 liter buljong\n- Parmesan\n\nInstruktioner:\n1. Fräs riset.\n2. Tillsätt buljong lite i taget.\n3. Blanda med grönsaker.\n4. Rör ner parmesan.\n\nTillagningstid: 25 minuter\nPro-tips: Använd varm buljong."
      }
    ],
    availability: "quick",
    tastingNotes: "Citrus, mineralitet, örter. Frisk struktur.",
    servingTemperature: "8-10°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "12%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 320,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },

  // TYSKA NATURVINER
  {
    name: "Naturwein Riesling",
    producer: "Weingut Schmitt",
    type: "Naturvin",
    country: "Tyskland",
    region: "Rheinhessen",
    year: "2021",
    price: 280,
    rating: 87,
    systembolagetNumber: "BB010",
    description: "Naturvin från Rheinhessen med Riesling. Fruktig och mineralisk med tysk precision.",
    foodPairing: ["Asiatisk mat", "Fisk", "Kyckling"],
    foodPairingDetails: [
      {
        dish: "Thailändsk curry",
        description: "Kokoscurry med kyckling och grönsaker.",
        why: "Vinets syra och fruktighet balanserar curryns hetta och sötma.",
        recipe: "Ingredienser (4 portioner):\n- 400g kyckling\n- Kokosmjölk\n- Currypasta\n- Grönsaker\n\nInstruktioner:\n1. Stek kycklingen.\n2. Tillsätt currypasta.\n3. Häll i kokosmjölk.\n4. Låt sjuda med grönsaker.\n\nTillagningstid: 25 minuter\nPro-tips: Använd färsk koriander."
      }
    ],
    availability: "quick",
    tastingNotes: "Citrus, mineralitet, aprikos. Frisk syra.",
    servingTemperature: "8-10°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "11.5%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 280,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  // FLER ORANGE VINER
  {
    name: "Ribolla Gialla",
    producer: "Radikon",
    type: "Orange vin",
    country: "Italien",
    region: "Friuli",
    year: "2019",
    price: 480,
    rating: 95,
    systembolagetNumber: "BB031",
    description: "Orange vin från Ribolla Gialla med 6 månaders skalkontakt. Mineralisk och komplex med citrus och honung.",
    foodPairing: ["Fisk", "Skaldjur", "Asiatisk mat", "Ost"],
    foodPairingDetails: [
      {
        dish: "Ceviche med lime",
        description: "Färsk fisk marinerad i lime och chili.",
        why: "Orange vinets syra och mineralitet kompletterar cevichens friska smaker.",
        recipe: "Ingredienser (4 portioner):\n- 300g färsk fisk\n- 3 lime\n- 1 röd chili\n- Koriander\n- Lök\n\nInstruktioner:\n1. Skär fisken i tärningar.\n2. Marinera i limejuice.\n3. Tillsätt chili och koriander.\n\nTillagningstid: 30 minuter\nPro-tips: Låt marinera i kylen."
      }
    ],
    availability: "better",
    tastingNotes: "Citrus, honung, mineralitet, aprikos. Komplex struktur.",
    servingTemperature: "12-14°C",
    bestDrinkingPeriod: "2023-2032",
    alcoholContent: "13%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 480,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  {
    name: "Jakot",
    producer: "Radikon",
    type: "Orange vin",
    country: "Italien",
    region: "Friuli",
    year: "2020",
    price: 420,
    rating: 93,
    systembolagetNumber: "BB032",
    description: "Orange vin från Jakot med 4 månaders skalkontakt. Fruktig och mineralisk med toner av päron och honung.",
    foodPairing: ["Fisk", "Skaldjur", "Lättare kött", "Ost"],
    foodPairingDetails: [
      {
        dish: "Grillad torsk med citron",
        description: "Färsk torsk grillad med citron och örter.",
        why: "Orange vinets struktur och mineralitet kompletterar torsken perfekt.",
        recipe: "Ingredienser (4 portioner):\n- 4 torskskivor\n- 2 citroner\n- Örter\n- Olivolja\n\nInstruktioner:\n1. Krydda torsken.\n2. Grilla 4 min per sida.\n3. Servera med citron.\n\nTillagningstid: 15 minuter\nPro-tips: Låt inte övergrilla."
      }
    ],
    availability: "quick",
    tastingNotes: "Päron, honung, mineralitet, citrus. Fruktig struktur.",
    servingTemperature: "12-14°C",
    bestDrinkingPeriod: "2023-2030",
    alcoholContent: "12.5%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 420,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  // FLER NATURVINER
  {
    name: "Sauvignon Blanc",
    producer: "Puzelat",
    type: "Naturvin",
    country: "Frankrike",
    region: "Loire",
    year: "2021",
    price: 290,
    rating: 88,
    systembolagetNumber: "BB033",
    description: "Naturvin från Sauvignon Blanc med minimal intervention. Fruktig och fräsch med levande syra.",
    foodPairing: ["Fisk", "Skaldjur", "Getost", "Grönsaker"],
    foodPairingDetails: [
      {
        dish: "Grillad lax med dill",
        description: "Färsk lax grillad med dill och citron.",
        why: "Vinets syra och fruktighet balanserar laxens fett.",
        recipe: "Ingredienser (4 portioner):\n- 4 laxfiléer\n- Färsk dill\n- 2 citroner\n- Olivolja\n\nInstruktioner:\n1. Krydda laxen.\n2. Grilla 3 min per sida.\n3. Garnera med dill.\n\nTillagningstid: 10 minuter\nPro-tips: Låt inte övergrilla."
      }
    ],
    availability: "quick",
    tastingNotes: "Citrus, gräsfrukter, mineralitet. Frisk syra.",
    servingTemperature: "8-10°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "12%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 290,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  {
    name: "Gamay",
    producer: "Puzelat",
    type: "Naturvin",
    country: "Frankrike",
    region: "Loire",
    year: "2021",
    price: 280,
    rating: 87,
    systembolagetNumber: "BB034",
    description: "Naturvin från Gamay med kolsyra. Fruktig och fräsch med levande syra och bärsmaker.",
    foodPairing: ["Charkuterier", "Ost", "Lättare kött", "Vegetariskt"],
    foodPairingDetails: [
      {
        dish: "Charcuterie-platta",
        description: "Uppläggning med olika charkuterier och ostar.",
        why: "Vinets syra och fruktighet balanserar charkuteriernas fett.",
        recipe: "Ingredienser (4 portioner):\n- Olika charkuterier\n- Hårda och mjuka ostar\n- Nötter\n- Frukt\n\nInstruktioner:\n1. Lägg upp charkuterier.\n2. Tillsätt ostar.\n3. Garnera med nötter.\n\nTillagningstid: 15 minuter\nPro-tips: Servera rumstempererat."
      }
    ],
    availability: "quick",
    tastingNotes: "Röda bär, kryddor, mineralitet. Frisk syra.",
    servingTemperature: "12-14°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "12%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 280,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  // FLER BIODYNAMISKA VINER
  {
    name: "Chardonnay",
    producer: "Domaine de la Côte",
    type: "Biodynamiskt vin",
    country: "Frankrike",
    region: "Bourgogne",
    year: "2021",
    price: 380,
    rating: 91,
    systembolagetNumber: "BB035",
    description: "Biodynamisk Chardonnay från Bourgogne. Elegant och mineralisk med komplex struktur och smörtoner.",
    foodPairing: ["Fisk", "Kyckling", "Ost", "Svamp"],
    foodPairingDetails: [
      {
        dish: "Grillad kyckling med svamp",
        description: "Hel kyckling grillad med svamp och örter.",
        why: "Vinets struktur och mineralitet kompletterar kycklingens smaker.",
        recipe: "Ingredienser (4 portioner):\n- 1 hel kyckling\n- 200g svamp\n- Örter\n- Olivolja\n\nInstruktioner:\n1. Krydda kycklingen.\n2. Fyll med svamp och örter.\n3. Grilla i 45 minuter.\n\nTillagningstid: 1 timme\nPro-tips: Låt vila 10 minuter."
      }
    ],
    availability: "better",
    tastingNotes: "Citrus, smör, nötter, mineralitet. Elegant struktur.",
    servingTemperature: "10-12°C",
    bestDrinkingPeriod: "2023-2030",
    alcoholContent: "13%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 380,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  {
    name: "Pinot Noir",
    producer: "Domaine de la Côte",
    type: "Biodynamiskt vin",
    country: "Frankrike",
    region: "Bourgogne",
    year: "2020",
    price: 450,
    rating: 92,
    systembolagetNumber: "BB036",
    description: "Biodynamisk Pinot Noir från Bourgogne. Elegant och fruktig med komplex struktur och mineralitet.",
    foodPairing: ["Lamm", "Kyckling", "Svamp", "Ost"],
    foodPairingDetails: [
      {
        dish: "Lammrack med rosmarin",
        description: "Grillad lammrack med rosmarin och rotfrukter.",
        why: "Vinets struktur och fruktighet kompletterar lammets smaker.",
        recipe: "Ingredienser (4 portioner):\n- 4 lammrack\n- Rosmarin\n- Rotfrukter\n- Olivolja\n\nInstruktioner:\n1. Krydda lammracken.\n2. Grilla till önskad stekgrad.\n3. Servera med rotfrukter.\n\nTillagningstid: 30 minuter\nPro-tips: Låt köttet vila."
      }
    ],
    availability: "better",
    tastingNotes: "Röda bär, kryddor, mineralitet. Elegant struktur.",
    servingTemperature: "14-16°C",
    bestDrinkingPeriod: "2023-2030",
    alcoholContent: "13%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "Begränsat lager",
        price: 450,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  // FLER SPANSKA VINER
  {
    name: "Garnacha",
    producer: "Comando G",
    type: "Naturvin",
    country: "Spanien",
    region: "Gredos",
    year: "2021",
    price: 420,
    rating: 90,
    systembolagetNumber: "BB037",
    description: "Naturvin från Garnacha från Gredos. Mineralisk och elegant med bergskaraktär och fruktighet.",
    foodPairing: ["Lamm", "Svamp", "Ost", "Charkuterier"],
    foodPairingDetails: [
      {
        dish: "Lammgryta med svamp",
        description: "Långkokt lammgryta med svamp och rotfrukter.",
        why: "Vinets struktur och mineralitet kompletterar grytans rika smaker.",
        recipe: "Ingredienser (4 portioner):\n- 800g lamm\n- 300g svamp\n- Rotfrukter\n- Rött vin\n\nInstruktioner:\n1. Bryn köttet.\n2. Tillsätt svamp och rotfrukter.\n3. Koka långsamt 2 timmar.\n\nTillagningstid: 2.5 timmar\nPro-tips: Låt koka långsamt."
      }
    ],
    availability: "better",
    tastingNotes: "Röda bär, mineralitet, kryddor. Bergskaraktär.",
    servingTemperature: "14-16°C",
    bestDrinkingPeriod: "2023-2030",
    alcoholContent: "14%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 420,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  {
    name: "Albillo",
    producer: "Comando G",
    type: "Naturvin",
    country: "Spanien",
    region: "Gredos",
    year: "2021",
    price: 380,
    rating: 89,
    systembolagetNumber: "BB038",
    description: "Naturvin från Albillo från Gredos. Mineralisk och fruktig med bergskaraktär och citrus.",
    foodPairing: ["Fisk", "Skaldjur", "Ost", "Vegetariskt"],
    foodPairingDetails: [
      {
        dish: "Grillad torsk med citron",
        description: "Färsk torsk grillad med citron och örter.",
        why: "Vinets mineralitet och syra kompletterar torsken perfekt.",
        recipe: "Ingredienser (4 portioner):\n- 4 torskskivor\n- 2 citroner\n- Örter\n- Olivolja\n\nInstruktioner:\n1. Krydda torsken.\n2. Grilla 4 min per sida.\n3. Servera med citron.\n\nTillagningstid: 15 minuter\nPro-tips: Låt inte övergrilla."
      }
    ],
    availability: "quick",
    tastingNotes: "Citrus, mineralitet, bergskaraktär. Fruktig struktur.",
    servingTemperature: "10-12°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "13%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 380,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  // FLER ITALIENSKA VINER
  {
    name: "Aglianico",
    producer: "Cantina Giardino",
    type: "Naturvin",
    country: "Italien",
    region: "Campania",
    year: "2020",
    price: 360,
    rating: 88,
    systembolagetNumber: "BB039",
    description: "Naturvin från Aglianico från Campania. Kraftfull och fruktig med italiensk karaktär och mineralitet.",
    foodPairing: ["Pasta", "Kött", "Ost", "Svamp"],
    foodPairingDetails: [
      {
        dish: "Pasta alla Norma",
        description: "Klassisk siciliansk pasta med aubergine och ricotta.",
        why: "Vinets struktur och fruktighet kompletterar pastans rika smaker.",
        recipe: "Ingredienser (4 portioner):\n- 400g pasta\n- 2 auberginer\n- 400g krossade tomater\n- Ricotta\n- Basilika\n\nInstruktioner:\n1. Stek aubergine.\n2. Gör tomatsås.\n3. Blanda med pasta.\n4. Toppa med ricotta.\n\nTillagningstid: 30 minuter\nPro-tips: Använd färsk basilika."
      }
    ],
    availability: "quick",
    tastingNotes: "Mörka bär, kryddor, mineralitet. Italiensk karaktär.",
    servingTemperature: "14-16°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "13%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 360,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  },
  {
    name: "Falanghina",
    producer: "Cantina Giardino",
    type: "Naturvin",
    country: "Italien",
    region: "Campania",
    year: "2021",
    price: 320,
    rating: 87,
    systembolagetNumber: "BB040",
    description: "Naturvin från Falanghina från Campania. Fruktig och mineralisk med citrus och bergskaraktär.",
    foodPairing: ["Fisk", "Skaldjur", "Ost", "Vegetariskt"],
    foodPairingDetails: [
      {
        dish: "Grillad torsk med citron",
        description: "Färsk torsk grillad med citron och örter.",
        why: "Vinets mineralitet och syra kompletterar torsken perfekt.",
        recipe: "Ingredienser (4 portioner):\n- 4 torskskivor\n- 2 citroner\n- Örter\n- Olivolja\n\nInstruktioner:\n1. Krydda torsken.\n2. Grilla 4 min per sida.\n3. Servera med citron.\n\nTillagningstid: 15 minuter\nPro-tips: Låt inte övergrilla."
      }
    ],
    availability: "quick",
    tastingNotes: "Citrus, mineralitet, bergskaraktär. Fruktig struktur.",
    servingTemperature: "10-12°C",
    bestDrinkingPeriod: "2023-2028",
    alcoholContent: "12.5%",
    volume: "750ml",
    purchaseLocations: [
      {
        name: "Budbreak.se",
        type: "private-import",
        url: "https://budbreak.se",
        stock: "I lager",
        price: 320,
        isPrivateImport: true,
        minimumOrder: "6 flaskor",
        importerContact: {
          email: "info@budbreak.se",
          phone: "08-123 45 67",
          orderUrl: "https://budbreak.se/bestall"
        }
      }
    ],
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
  }
];

// Budbreak producenter
export const budbreakProducers = [
  {
    name: "Radikon",
    country: "Italien",
    region: "Friuli",
    specialty: "Orange viner",
    description: "Pionjärer inom orange viner med lång skalkontakt och traditionell vinbryggning."
  },
  {
    name: "Gravner",
    country: "Italien", 
    region: "Friuli",
    specialty: "Orange viner",
    description: "Exklusiva orange viner med amfora-lagring och traditionell vinbryggning."
  },
  {
    name: "Puzelat",
    country: "Frankrike",
    region: "Loire",
    specialty: "Naturviner",
    description: "Klassiska viner från Loire med fokus på Gamay och Pinot Noir."
  },
  {
    name: "Domaine de la Sénéchalière",
    country: "Frankrike",
    region: "Loire",
    specialty: "Biodynamiska viner",
    description: "Kvalitetsviner från Muscadet med mineralisk karaktär."
  },
  {
    name: "La Garagista",
    country: "USA",
    region: "Vermont",
    specialty: "Pet Nat",
    description: "Naturliga mousserande viner från Vermont med unik karaktär."
  },
  {
    name: "Domaine de la Côte",
    country: "Frankrike",
    region: "Bourgogne",
    specialty: "Biodynamiska viner",
    description: "Biodynamiska viner från Bourgogne med fokus på Chardonnay."
  },
  {
    name: "Cantina Giardino",
    country: "Italien",
    region: "Campania",
    specialty: "Naturviner",
    description: "Naturviner från Campania med Aglianico och italiensk karaktär."
  },
  {
    name: "Comando G",
    country: "Spanien",
    region: "Gredos",
    specialty: "Naturviner",
    description: "Naturviner från Gredos med Garnacha och bergskaraktär."
  },
  {
    name: "Sepp Muster",
    country: "Österrike",
    region: "Steiermark",
    specialty: "Naturviner",
    description: "Naturviner från Steiermark med alpin karaktär och mineralitet."
  },
  {
    name: "Weingut Schmitt",
    country: "Tyskland",
    region: "Rheinhessen",
    specialty: "Naturviner",
    description: "Naturviner från Rheinhessen med Riesling och tysk precision."
  }
];
