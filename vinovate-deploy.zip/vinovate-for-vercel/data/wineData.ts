// Wine regions and grapes by country
export const wineDataMap = {
  "Frankrike": {
    regions: ["Bordeaux", "Bourgogne", "Champagne", "Rhône", "Loire", "Alsace", "Languedoc-Roussillon", "Provence"],
    grapes: {
      "Bordeaux": ["Cabernet Sauvignon", "Merlot", "Cabernet Franc", "Sauvignon Blanc", "Sémillon"],
      "Bourgogne": ["Pinot Noir", "Chardonnay", "Gamay"],
      "Champagne": ["Chardonnay", "Pinot Noir", "Pinot Meunier"],
      "Rhône": ["Syrah", "Grenache", "Mourvèdre", "Viognier"],
      "Loire": ["Sauvignon Blanc", "Chenin Blanc", "Cabernet Franc", "Muscadet"],
      "Alsace": ["Riesling", "Gewürztraminer", "Pinot Gris", "Pinot Blanc"],
      "Languedoc-Roussillon": ["Grenache", "Syrah", "Mourvèdre", "Carignan"],
      "Provence": ["Grenache", "Cinsault", "Mourvèdre", "Rolle"],
    }
  },
  "Italien": {
    regions: ["Toscana", "Piemonte", "Veneto", "Sicilien", "Apulien", "Lombardiet", "Abruzzo"],
    grapes: {
      "Toscana": ["Sangiovese", "Cabernet Sauvignon", "Merlot", "Trebbiano"],
      "Piemonte": ["Nebbiolo", "Barbera", "Dolcetto", "Moscato"],
      "Veneto": ["Corvina", "Garganega", "Pinot Grigio", "Prosecco"],
      "Sicilien": ["Nero d'Avola", "Nerello Mascalese", "Grillo", "Catarratto"],
      "Apulien": ["Primitivo", "Negroamaro", "Bombino Bianco"],
      "Lombardiet": ["Nebbiolo", "Chardonnay", "Pinot Nero"],
      "Abruzzo": ["Montepulciano", "Trebbiano"],
    }
  },
  "Spanien": {
    regions: ["Rioja", "Ribera del Duero", "Priorat", "Rías Baixas", "Jerez", "Penedès", "La Mancha"],
    grapes: {
      "Rioja": ["Tempranillo", "Garnacha", "Mazuelo", "Graciano"],
      "Ribera del Duero": ["Tempranillo", "Cabernet Sauvignon", "Merlot"],
      "Priorat": ["Garnacha", "Cariñena", "Cabernet Sauvignon"],
      "Rías Baixas": ["Albariño"],
      "Jerez": ["Palomino", "Pedro Ximénez", "Moscatel"],
      "Penedès": ["Xarel·lo", "Macabeo", "Parellada", "Chardonnay"],
      "La Mancha": ["Tempranillo", "Airén"],
    }
  },
  "Portugal": {
    regions: ["Douro", "Alentejo", "Dão", "Vinho Verde", "Setúbal"],
    grapes: {
      "Douro": ["Touriga Nacional", "Touriga Franca", "Tinta Roriz", "Tinta Barroca"],
      "Alentejo": ["Aragonez", "Trincadeira", "Alicante Bouschet"],
      "Dão": ["Touriga Nacional", "Jaen", "Alfrocheiro"],
      "Vinho Verde": ["Alvarinho", "Loureiro", "Trajadura"],
      "Setúbal": ["Moscatel", "Castelão"],
    }
  },
  "Tyskland": {
    regions: ["Mosel", "Rheingau", "Pfalz", "Baden"],
    grapes: {
      "Mosel": ["Riesling"],
      "Rheingau": ["Riesling", "Pinot Noir"],
      "Pfalz": ["Riesling", "Pinot Noir", "Dornfelder"],
      "Baden": ["Pinot Noir", "Pinot Gris", "Chardonnay"],
    }
  },
  "USA": {
    regions: ["Napa Valley", "Sonoma", "Paso Robles", "Willamette Valley", "Walla Walla"],
    grapes: {
      "Napa Valley": ["Cabernet Sauvignon", "Chardonnay", "Merlot", "Zinfandel"],
      "Sonoma": ["Pinot Noir", "Chardonnay", "Cabernet Sauvignon", "Zinfandel"],
      "Paso Robles": ["Zinfandel", "Cabernet Sauvignon", "Rhône-druvor"],
      "Willamette Valley": ["Pinot Noir", "Chardonnay", "Pinot Gris"],
      "Walla Walla": ["Cabernet Sauvignon", "Syrah", "Merlot"],
    }
  },
  "Chile": {
    regions: ["Maipo Valley", "Colchagua Valley", "Casablanca Valley"],
    grapes: {
      "Maipo Valley": ["Cabernet Sauvignon", "Carmenère"],
      "Colchagua Valley": ["Carmenère", "Syrah", "Malbec"],
      "Casablanca Valley": ["Sauvignon Blanc", "Chardonnay", "Pinot Noir"],
    }
  },
  "Argentina": {
    regions: ["Mendoza", "Salta", "Patagonia"],
    grapes: {
      "Mendoza": ["Malbec", "Cabernet Sauvignon", "Bonarda"],
      "Salta": ["Torrontés", "Malbec", "Tannat"],
      "Patagonia": ["Pinot Noir", "Malbec", "Chardonnay"],
    }
  },
  "Australien": {
    regions: ["Barossa Valley", "Margaret River", "Hunter Valley", "Yarra Valley"],
    grapes: {
      "Barossa Valley": ["Shiraz", "Grenache", "Cabernet Sauvignon"],
      "Margaret River": ["Cabernet Sauvignon", "Chardonnay", "Sauvignon Blanc"],
      "Hunter Valley": ["Sémillon", "Shiraz", "Chardonnay"],
      "Yarra Valley": ["Pinot Noir", "Chardonnay", "Cabernet Sauvignon"],
    }
  },
  "Nya Zeeland": {
    regions: ["Marlborough", "Central Otago", "Hawke's Bay"],
    grapes: {
      "Marlborough": ["Sauvignon Blanc", "Pinot Noir", "Chardonnay"],
      "Central Otago": ["Pinot Noir", "Riesling"],
      "Hawke's Bay": ["Cabernet Sauvignon", "Merlot", "Syrah", "Chardonnay"],
    }
  },
  "Sydafrika": {
    regions: ["Stellenbosch", "Paarl", "Franschhoek", "Constantia"],
    grapes: {
      "Stellenbosch": ["Cabernet Sauvignon", "Pinotage", "Shiraz", "Chardonnay"],
      "Paarl": ["Shiraz", "Pinotage", "Chenin Blanc"],
      "Franschhoek": ["Cabernet Sauvignon", "Sémillon", "Chardonnay"],
      "Constantia": ["Sauvignon Blanc", "Chardonnay"],
    }
  },
  "Österrike": {
    regions: ["Wachau", "Burgenland", "Kamptal"],
    grapes: {
      "Wachau": ["Grüner Veltliner", "Riesling"],
      "Burgenland": ["Blaufränkisch", "Zweigelt", "St. Laurent"],
      "Kamptal": ["Grüner Veltliner", "Riesling"],
    }
  },
  "Grekland": {
    regions: ["Santorini", "Nemea", "Naoussa"],
    grapes: {
      "Santorini": ["Assyrtiko"],
      "Nemea": ["Agiorgitiko"],
      "Naoussa": ["Xinomavro"],
    }
  },
};

// Get all unique grapes across all countries
export const getAllGrapes = (): string[] => {
  const grapes = new Set<string>();
  Object.values(wineDataMap).forEach(country => {
    Object.values(country.grapes).forEach(regionGrapes => {
      regionGrapes.forEach(grape => grapes.add(grape));
    });
  });
  return Array.from(grapes).sort();
};

// Get regions for a specific country
export const getRegionsForCountry = (country: string): string[] => {
  const countryData = wineDataMap[country as keyof typeof wineDataMap];
  return countryData ? countryData.regions : [];
};

// Get grapes for a specific country and optional region
export const getGrapesForCountryAndRegion = (country: string, region?: string): string[] => {
  const countryData = wineDataMap[country as keyof typeof wineDataMap];
  if (!countryData) return getAllGrapes();
  
  if (region && countryData.grapes[region as keyof typeof countryData.grapes]) {
    return countryData.grapes[region as keyof typeof countryData.grapes];
  }
  
  // Return all grapes for the country
  const grapes = new Set<string>();
  Object.values(countryData.grapes).forEach(regionGrapes => {
    regionGrapes.forEach(grape => grapes.add(grape));
  });
  return Array.from(grapes).sort();
};

