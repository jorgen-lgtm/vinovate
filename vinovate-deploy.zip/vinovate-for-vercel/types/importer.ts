export interface ImporterContact {
  website?: string;
  phone?: string;
  email?: string;
}

export interface ImporterTopWine {
  name: string;
  producer: string;
  price: string;
}

export interface Importer {
  name: string;
  description: string;
  specialties: string[];
  focusRegions: string[];
  priceRange: string;
  portfolioSize: string;
  strengths: string[];
  bestFor: string;
  contact: ImporterContact;
  topWines: ImporterTopWine[];
}

