import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Vinovate - Där passion möter innovation",
  description: "Upptäck ditt perfekta vin med AI-driven precision. Från sökning till smakupplevelse.",
  authors: [{ name: "Jörgen Andersson" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="sv">
      <body className={inter.className}>{children}</body>
    </html>
  );
}

