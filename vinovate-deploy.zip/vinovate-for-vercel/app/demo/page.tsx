"use client";

import { useState } from "react";
import { Search, Sparkles, Wine as WineIcon, Star, Loader2, ArrowRight } from "lucide-react";
import WineModal from "@/components/WineModal";
import { Wine } from "@/types/wine";

export default function DemoPage() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Wine[]>([]);
  const [selectedWine, setSelectedWine] = useState<Wine | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [aiGenerated, setAiGenerated] = useState(false);

  const exampleQueries = [
    "Rött vin till biff",
    "Vitt vin till fisk",
    "Champagne till fest",
    "Italienskt vin till pasta",
    "Franskt vin under 200 kr",
    "Premium rött vin för lagring",
    "Rosévin till sommar",
    "Vitt vin till ost"
  ];

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError(null);
    setResults([]);
    setQuery(searchQuery);

    try {
      const response = await fetch('/api/ai-wine-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          query: searchQuery, 
          preferQuick: true, 
          maxResults: 8 
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setResults(data.wines || []);
      setAiGenerated(data.aiGenerated || false);
      
    } catch (err) {
      setError("Ett fel uppstod vid sökningen. Försök igen.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-wine-800 to-red-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="h-8 w-8 text-yellow-400" />
            <h1 className="text-5xl font-bold text-white tracking-tight">
              🍷 Vinovate AI Demo
            </h1>
            <Sparkles className="h-8 w-8 text-yellow-400" />
          </div>
          <p className="text-xl text-purple-100 mb-2 font-semibold">
            AI-driven vinsökning med intelligent matpairing
          </p>
          <p className="text-lg text-purple-200">
            Beskriv vad du letar efter och få personliga vinrekommendationer
          </p>
        </header>

        {/* Search Section */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
            <div className="flex items-center gap-2 mb-6">
              <WineIcon className="h-6 w-6 text-wine-300" />
              <h2 className="text-2xl font-bold text-white">AI Vinsökning</h2>
            </div>
            
            <form onSubmit={(e) => { e.preventDefault(); handleSearch(query); }} className="mb-6">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Beskriv vad du letar efter... (t.ex. 'rött vin till biff', 'vitt vin under 200 kr', 'champagne till fest')"
                  className="w-full pl-12 pr-4 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-wine-600 focus:border-transparent text-lg"
                  disabled={loading}
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-6 py-2 bg-wine-600 text-white rounded-lg hover:bg-wine-700 transition-colors flex items-center gap-2"
                  disabled={loading || !query.trim()}
                >
                  {loading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Search className="h-4 w-4" />
                      Sök
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Example Queries */}
            <div className="mb-6">
              <p className="text-purple-200 text-sm mb-3">Exempel på sökningar:</p>
              <div className="flex flex-wrap gap-2">
                {exampleQueries.map((example, index) => (
                  <button
                    key={index}
                    onClick={() => handleSearch(example)}
                    className="px-3 py-1 bg-white/20 text-white rounded-full text-sm hover:bg-white/30 transition-colors"
                    disabled={loading}
                  >
                    {example}
                  </button>
                ))}
              </div>
            </div>

            {/* AI Status */}
            {aiGenerated && (
              <div className="flex items-center gap-2 text-green-400 text-sm">
                <Sparkles className="h-4 w-4" />
                <span>AI-genererade rekommendationer</span>
              </div>
            )}
          </div>
        </div>

        {/* Results */}
        {error && (
          <div className="max-w-4xl mx-auto mb-6">
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg">
              {error}
            </div>
          </div>
        )}

        {results.length > 0 && (
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-2 mb-6">
              <h3 className="text-2xl font-bold text-white">
                {results.length} vinrekommendationer
              </h3>
              {aiGenerated && (
                <span className="px-3 py-1 bg-green-500 text-white rounded-full text-sm flex items-center gap-1">
                  <Sparkles className="h-3 w-3" />
                  AI-genererat
                </span>
              )}
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {results.map((wine, index) => (
                <div
                  key={index}
                  onClick={() => setSelectedWine(wine)}
                  className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all cursor-pointer overflow-hidden group"
                >
                  <div className="relative h-48 bg-gradient-to-br from-wine-50 to-purple-100">
                    {wine.imageUrl ? (
                      <img
                        src={wine.imageUrl}
                        alt={wine.name}
                        className="w-full h-full object-contain p-4"
                      />
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full">
                        <WineIcon className="h-12 w-12 text-wine-300 mb-2" />
                        <p className="text-xs text-gray-400">Ingen bild</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="p-6">
                    <h4 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-wine-600 transition-colors">
                      {wine.name}
                    </h4>
                    <p className="text-gray-600 mb-3 text-sm">
                      {wine.producer} • {wine.country} {wine.year ? `• ${wine.year}` : ''}
                    </p>
                    <p className="text-gray-700 mb-4 text-sm line-clamp-2">
                      {wine.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      <span className="px-2 py-1 bg-wine-100 text-wine-800 rounded-full text-xs">
                        {wine.type}
                      </span>
                      {wine.rating && (
                        <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs flex items-center gap-1">
                          <Star className="h-3 w-3 fill-current" />
                          {wine.rating}/100
                        </span>
                      )}
                      {wine.price && (
                        <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                          {wine.price} kr
                        </span>
                      )}
                    </div>

                    <div className="mb-4">
                      <p className="text-xs font-semibold text-gray-700 mb-1">
                        Passar till:
                      </p>
                      <p className="text-xs text-gray-600">
                        {wine.foodPairing.slice(0, 3).join(", ")}
                      </p>
                    </div>
                    
                    <button className="w-full bg-wine-600 text-white py-2 rounded-lg font-medium hover:bg-wine-700 transition-colors flex items-center justify-center gap-2">
                      Visa mer
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Info Section */}
        <div className="max-w-4xl mx-auto mt-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
            <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-yellow-400" />
              Hur fungerar AI-sökningen?
            </h3>
            <div className="grid md:grid-cols-2 gap-6 text-purple-100">
              <div>
                <h4 className="font-semibold text-white mb-2">🎯 Intelligent tolkning</h4>
                <p className="text-sm">
                  AI:n förstår naturligt språk och kan tolka komplexa beskrivningar som "rött vin till biff" eller "premium champagne under 500 kr".
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">🍷 Expertkunskap</h4>
                <p className="text-sm">
                  Baserat på djup kunskap om viner, matpairing och svenska Systembolaget ger AI:n personliga rekommendationer.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">📊 Detaljerad information</h4>
                <p className="text-sm">
                  Varje rekommendation inkluderar betyg, pris, matpairing, recept och köpställen både på Systembolaget och via privatimport.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">⚡ Snabb och smart</h4>
                <p className="text-sm">
                  Resultaten cachar för snabbare sökningar och AI:n lär sig av tidigare sökningar för bättre rekommendationer.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Wine Modal */}
        {selectedWine && (
          <WineModal
            wine={selectedWine}
            onClose={() => setSelectedWine(null)}
          />
        )}
      </div>
    </div>
  );
}
