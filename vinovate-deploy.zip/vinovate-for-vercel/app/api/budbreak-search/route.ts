import { NextRequest, NextResponse } from "next/server";
import { budbreakWines } from "@/data/budbreakWines";

export async function POST(request: NextRequest) {
  try {
    const { query, preferQuick = true, maxResults = 10 } = await request.json();

    if (!query || query.trim().length === 0) {
      return NextResponse.json(
        { error: "Sökfråga krävs" },
        { status: 400 }
      );
    }

    console.log("Budbreak search called with:", { query, preferQuick, maxResults });

    // Intelligent search using semantic matching
    const q = query.toLowerCase();
    
    // Check for country names first - if found, only show wines from that country
    const countries = ["Frankrike", "Italien", "Spanien", "Portugal", "Tyskland", "USA", "Chile", "Argentina", "Australien", "Nya Zeeland", "Sydafrika", "Österrike", "Grekland"];
    let targetCountry = null;
    
    for (const country of countries) {
      if (q.includes(country.toLowerCase())) {
        targetCountry = country;
        break;
      }
    }
    
    // If a country is specified, only show wines from that country
    let filteredWines = budbreakWines;
    if (targetCountry) {
      filteredWines = budbreakWines.filter(wine => 
        wine.country.toLowerCase() === targetCountry.toLowerCase()
      );
    } else {
      // Score wines based on how well they match the query
      const scoredWines = budbreakWines.map(wine => {
        let score = 0;
        const wineText = `${wine.name} ${wine.producer} ${wine.country} ${wine.region} ${wine.type} ${wine.description} ${wine.foodPairing.join(' ')}`.toLowerCase();
        
        // Exact matches get highest score
        if (wine.name.toLowerCase().includes(q)) score += 100;
        if (wine.producer.toLowerCase().includes(q)) score += 90;
        if (wine.type.toLowerCase().includes(q)) score += 70;
        
        // Partial matches
        if (wineText.includes(q)) score += 50;
        
        // Food pairing matches
        if (wine.foodPairing.some(food => food.toLowerCase().includes(q))) score += 60;
        
        // Price range matches
        if (q.includes('under') || q.includes('över') || q.includes('kr')) {
          const priceMatch = q.match(/(under|över)\s+(\d+)/i);
          if (priceMatch) {
            const operator = priceMatch[1].toLowerCase();
            const price = parseInt(priceMatch[2]);
            if (operator === "under" && wine.price && wine.price < price) score += 40;
            if (operator === "över" && wine.price && wine.price > price) score += 40;
          }
        }
        
        // Rating boost for high-rated wines
        if (wine.rating && wine.rating >= 90) score += 10;
        
        return { wine, score };
      });
      
      // Sort by score and filter out zero-score wines
      filteredWines = scoredWines
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .map(item => item.wine);
    }

    // Enhanced food pairing filtering with flexible matching
    const foodKeywords = {
      fisk: ["fisk", "skaldjur", "ostron", "lax", "tonfisk", "torsk", "sill", "makrill"],
      kött: ["kött", "oxfilé", "lamm", "fläsk", "kyckling", "vilt", "gryta", "ragu", "stek", "kött", "meat"],
      ost: ["ost", "cheese", "brie", "camembert", "cheddar", "parmesan"],
      pasta: ["pasta", "spaghetti", "lasagne", "risotto"],
      vegetariskt: ["vegetariskt", "grönsaker", "sallad", "tofu", "quorn"],
      dessert: ["dessert", "choklad", "kaka", "tårta", "glass"],
      förrätt: ["förrätt", "tapas", "antipasti", "smörgås"]
    };

    // Check if query contains food-related keywords
    let foodCategory = null;
    for (const [category, keywords] of Object.entries(foodKeywords)) {
      if (keywords.some(keyword => q.includes(keyword))) {
        foodCategory = category;
        break;
      }
    }

    // Apply food pairing filter if food category is detected
    if (foodCategory) {
      const originalCount = filteredWines.length;
      filteredWines = filteredWines.filter((wine) => {
        return wine.foodPairing.some(food => {
          const foodLower = food.toLowerCase();
          // More flexible matching - check if any keyword from the category matches
          return foodKeywords[foodCategory as keyof typeof foodKeywords].some(keyword => 
            foodLower.includes(keyword) || keyword.includes(foodLower)
          );
        });
      });
      
      // If no wines match the food pairing, fall back to category-based filtering
      if (filteredWines.length === 0) {
        console.log(`No wines found for food category ${foodCategory}, falling back to category-based filtering`);
        // For meat dishes, show red wines; for fish, show white/orange wines
        if (foodCategory === "kött") {
          filteredWines = budbreakWines.filter(wine => 
            wine.type === "Rött vin" || wine.type.includes("Naturvin") || wine.type.includes("Orange")
          );
        } else if (foodCategory === "fisk") {
          filteredWines = budbreakWines.filter(wine => 
            wine.type === "Vitt vin" || wine.type.includes("Orange") || wine.type.includes("Naturvin")
          );
        }
        // Sort by rating
        filteredWines.sort((a, b) => (b.rating || 0) - (a.rating || 0));
      }
    }

    // Sort by rating (highest first)
    filteredWines.sort((a, b) => (b.rating || 0) - (a.rating || 0));

    // Limit results
    const wines = filteredWines.slice(0, maxResults);

    // Add sponsored flag to all wines
    const sponsoredWines = wines.map(wine => ({
      ...wine,
      isSponsored: true,
      sponsorName: "Budbreak.se"
    }));

    return NextResponse.json({
      wines: sponsoredWines,
      cached: false,
      message: `Budbreak.se - ${wines.length} naturviner och biodynamiska viner`,
      hasSponsored: true,
      sponsorInfo: {
        name: "Budbreak.se",
        description: "Ärliga, ursprungstypiska viner av genuina vinbönder som vi respekterar och beundrar",
        website: "https://budbreak.se",
        email: "info@budbreak.se",
        phone: "08-123 45 67"
      }
    });

  } catch (error) {
    console.error("Error in Budbreak search:", error);
    return NextResponse.json(
      { error: "Ett fel uppstod vid sökningen" },
      { status: 500 }
    );
  }
}
