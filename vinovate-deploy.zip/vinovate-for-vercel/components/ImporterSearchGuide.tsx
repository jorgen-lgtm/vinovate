"use client";

import { Building2, Info } from "lucide-react";

export default function ImporterSearchGuide() {
  return (
    <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4 mb-4 border border-blue-200">
      <div className="flex items-start gap-3">
        <Building2 className="h-6 w-6 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
            Sök efter Importörs Portfölj
            <Info className="h-4 w-4 text-gray-500" />
          </h4>
          <p className="text-sm text-gray-700 mb-3">
            Hitta alla viner från en specifik importör. Perfekt för att utforska ett helt sortiment!
          </p>
          
          <div className="space-y-2">
            <div>
              <p className="text-xs font-semibold text-gray-600 mb-1">Exempel på svenska importörer:</p>
              <div className="flex flex-wrap gap-2">
                <span className="px-2 py-1 bg-white text-blue-700 rounded text-xs border border-blue-200">
                  Philipson Söderberg
                </span>
                <span className="px-2 py-1 bg-white text-blue-700 rounded text-xs border border-blue-200">
                  Wineworld
                </span>
                <span className="px-2 py-1 bg-white text-blue-700 rounded text-xs border border-blue-200">
                  Kobrand
                </span>
                <span className="px-2 py-1 bg-white text-blue-700 rounded text-xs border border-blue-200">
                  Domaine Select
                </span>
                <span className="px-2 py-1 bg-white text-blue-700 rounded text-xs border border-blue-200">
                  Vinguiden
                </span>
              </div>
            </div>
            
            <div>
              <p className="text-xs font-semibold text-gray-600 mb-1">Hur söker jag?</p>
              <ul className="text-xs text-gray-600 space-y-1">
                <li>• Skriv bara importörens namn: <code className="bg-white px-1 py-0.5 rounded">Philipson Söderberg</code></li>
                <li>• Eller med "Importör:": <code className="bg-white px-1 py-0.5 rounded">Importör: Wineworld</code></li>
                <li>• Eller "Portfolio från": <code className="bg-white px-1 py-0.5 rounded">Portfolio från Kobrand</code></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

