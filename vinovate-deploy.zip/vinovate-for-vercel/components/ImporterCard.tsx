"use client";

import { Building2, MapPin, TrendingUp, Phone, Mail, Globe, Star } from "lucide-react";
import { Importer } from "@/types/importer";

interface ImporterCardProps {
  importer: Importer;
  onViewPortfolio: (importerName: string) => void;
}

export default function ImporterCard({ importer, onViewPortfolio }: ImporterCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg hover:shadow-xl transition-all p-6 border border-gray-200">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-wine-100 rounded-lg">
            <Building2 className="h-6 w-6 text-wine-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">{importer.name}</h3>
            <p className="text-sm text-gray-600">{importer.portfolioSize}</p>
          </div>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
          importer.priceRange === 'Luxury' ? 'bg-purple-100 text-purple-800' :
          importer.priceRange === 'Premium' ? 'bg-blue-100 text-blue-800' :
          importer.priceRange === 'Medium' ? 'bg-green-100 text-green-800' :
          'bg-gray-100 text-gray-800'
        }`}>
          {importer.priceRange}
        </span>
      </div>

      {/* Description */}
      <p className="text-sm text-gray-700 mb-4">{importer.description}</p>

      {/* Best For */}
      <div className="mb-4 p-3 bg-wine-50 rounded-lg">
        <p className="text-sm">
          <span className="font-semibold text-wine-900">⭐ Bäst för:</span>{' '}
          <span className="text-wine-800">{importer.bestFor}</span>
        </p>
      </div>

      {/* Specialties */}
      <div className="mb-4">
        <p className="text-xs font-semibold text-gray-700 mb-2">Specialiteter:</p>
        <div className="flex flex-wrap gap-2">
          {importer.specialties.map((specialty, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs"
            >
              {specialty}
            </span>
          ))}
        </div>
      </div>

      {/* Focus Regions */}
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-2">
          <MapPin className="h-4 w-4 text-gray-600" />
          <p className="text-xs font-semibold text-gray-700">Fokusregioner:</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {importer.focusRegions.map((region, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs"
            >
              {region}
            </span>
          ))}
        </div>
      </div>

      {/* Strengths */}
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp className="h-4 w-4 text-gray-600" />
          <p className="text-xs font-semibold text-gray-700">Styrkor:</p>
        </div>
        <ul className="space-y-1">
          {importer.strengths.map((strength, index) => (
            <li key={index} className="text-xs text-gray-600 flex items-start gap-2">
              <span className="text-wine-600 font-bold">•</span>
              <span>{strength}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Top Wines */}
      {importer.topWines && importer.topWines.length > 0 && (
        <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Star className="h-4 w-4 text-yellow-600 fill-current" />
            <p className="text-xs font-semibold text-gray-900">Kända viner:</p>
          </div>
          {importer.topWines.slice(0, 2).map((wine, index) => (
            <div key={index} className="text-xs text-gray-700 mb-1">
              <strong>{wine.name}</strong> - {wine.producer} ({wine.price})
            </div>
          ))}
        </div>
      )}

      {/* Contact */}
      <div className="mb-4 pt-4 border-t border-gray-200">
        <p className="text-xs font-semibold text-gray-700 mb-2">Kontakt:</p>
        <div className="space-y-1">
          {importer.contact.website && (
            <a
              href={importer.contact.website.startsWith('http') ? importer.contact.website : `https://${importer.contact.website}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-xs text-blue-600 hover:text-blue-700"
            >
              <Globe className="h-3 w-3" />
              <span>{importer.contact.website}</span>
            </a>
          )}
          {importer.contact.phone && (
            <a
              href={`tel:${importer.contact.phone}`}
              className="flex items-center gap-2 text-xs text-gray-600 hover:text-gray-700"
            >
              <Phone className="h-3 w-3" />
              <span>{importer.contact.phone}</span>
            </a>
          )}
          {importer.contact.email && (
            <a
              href={`mailto:${importer.contact.email}`}
              className="flex items-center gap-2 text-xs text-gray-600 hover:text-gray-700"
            >
              <Mail className="h-3 w-3" />
              <span>{importer.contact.email}</span>
            </a>
          )}
        </div>
      </div>

      {/* Action Button */}
      <button
        onClick={() => onViewPortfolio(importer.name)}
        className="w-full bg-wine-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-wine-700 transition-colors"
      >
        Se hela portföljen →
      </button>
    </div>
  );
}

