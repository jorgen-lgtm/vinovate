"use client";

import { Info, Package, TrendingDown, Truck } from "lucide-react";

export default function PrivateImportInfo() {
  return (
    <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-6 border-2 border-green-200 mb-6">
      <div className="flex items-start gap-3">
        <div className="p-2 bg-green-600 rounded-lg">
          <Package className="h-6 w-6 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-bold text-gray-900 mb-2 flex items-center gap-2">
            💰 Spara pengar med Privatimport
            <Info className="h-4 w-4 text-gray-500" />
          </h3>
          
          <p className="text-sm text-gray-700 mb-4">
            Många svenska vinimportörer säljer direkt till konsumenter genom privatimport. 
            Ofta får du bättre priser och tillgång till exklusiva viner!
          </p>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <TrendingDown className="h-4 w-4 text-green-600" />
                <h4 className="font-semibold text-sm text-gray-900">Lägre Priser</h4>
              </div>
              <p className="text-xs text-gray-600">
                Ofta 10-30% billigare än Systembolaget
              </p>
            </div>

            <div className="bg-white rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <Package className="h-4 w-4 text-green-600" />
                <h4 className="font-semibold text-sm text-gray-900">Större Urval</h4>
              </div>
              <p className="text-xs text-gray-600">
                Viner som inte finns på Systembolaget
              </p>
            </div>

            <div className="bg-white rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <Truck className="h-4 w-4 text-green-600" />
                <h4 className="font-semibold text-sm text-gray-900">Hemleverans</h4>
              </div>
              <p className="text-xs text-gray-600">
                Direkt till din dörr, ofta inom 2-5 dagar
              </p>
            </div>
          </div>

          <div className="mt-4 p-3 bg-white rounded-lg border border-green-200">
            <p className="text-xs text-gray-700">
              <strong className="text-green-900">💡 Så funkar det:</strong> 
              Många importörer kräver en minsta beställning (ofta 6 flaskor eller 1 kartong = 12 flaskor). 
              Perfekt att dela med vänner eller bygga en egen vinkällare!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

