"use client";

import { Wine } from "@/types/wine";
import { X, MapPin, ShoppingCart, Star, Wine as WineIcon, ChefHat, ChevronDown, ExternalLink } from "lucide-react";
import Image from "next/image";
import { useEffect } from "react";
import RecipeCard from "./RecipeCard";

interface WineModalProps {
  wine: Wine;
  onClose: () => void;
}

export default function WineModal({ wine, onClose }: WineModalProps) {
  // Stäng med ESC-tangenten
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto"
      onClick={onClose}
      style={{ animation: 'fadeIn 0.2s ease-in-out' }}
    >
      <div 
        className="bg-white rounded-xl max-w-4xl w-full my-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        style={{ animation: 'scaleIn 0.2s ease-in-out' }}
      >
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">{wine.name}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Stäng"
            title="Stäng (ESC)"
          >
            <X className="h-6 w-6 text-gray-600" />
          </button>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Image Section */}
            <div className="flex flex-col items-center">
              <div className="relative w-full h-96 bg-gradient-to-br from-wine-50 to-purple-100 rounded-lg overflow-hidden shadow-inner">
                {wine.imageUrl ? (
                  <Image
                    src={wine.imageUrl}
                    alt={wine.name}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-contain"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center h-full">
                    <WineIcon className="h-32 w-32 text-wine-300 mb-4" />
                    <p className="text-sm text-gray-500 font-medium">Ingen bild tillgänglig</p>
                    <p className="text-xs text-gray-400 mt-1">{wine.name}</p>
                  </div>
                )}
              </div>
              
              {wine.rating && (
                <div className="mt-4 flex items-center gap-2 bg-yellow-50 px-4 py-2 rounded-lg">
                  <Star className="h-5 w-5 text-yellow-600 fill-current" />
                  <span className="text-lg font-semibold text-yellow-900">
                    {wine.rating}/100
                  </span>
                </div>
              )}
            </div>

            {/* Details Section */}
            <div>
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Om vinet
                </h3>
                <div className="space-y-2 text-gray-700">
                  <p><strong>Producent:</strong> {wine.producer}</p>
                  <p><strong>Typ:</strong> {wine.type}</p>
                  <p><strong>Land:</strong> {wine.country}</p>
                  {wine.region && <p><strong>Region:</strong> {wine.region}</p>}
                  {wine.year && <p><strong>Årgång:</strong> {wine.year}</p>}
                  {wine.price && (
                    <p className="text-xl font-bold text-wine-700">
                      {wine.price} kr
                    </p>
                  )}
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Beskrivning
                </h3>
                <p className="text-gray-700">{wine.description}</p>
              </div>

              {wine.tastingNotes && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Senaste provning
                  </h3>
                  <p className="text-gray-700 bg-wine-50 p-4 rounded-lg">
                    {wine.tastingNotes}
                  </p>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <ChefHat className="h-5 w-5 text-wine-600" />
                  Rustika maträtter som passar perfekt
                </h3>
                {wine.foodPairingDetails && wine.foodPairingDetails.length > 0 ? (
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600 mb-4">
                      Här är klassiska, rustika rätter med fullständiga recept:
                    </p>
                    {wine.foodPairingDetails.map((pairing, index) => (
                      <details key={index} className="group">
                        <summary className="cursor-pointer bg-wine-50 rounded-lg p-4 border-l-4 border-wine-600 hover:bg-wine-100 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h4 className="font-bold text-wine-900 mb-1 flex items-center gap-2">
                                🍴 {pairing.dish}
                              </h4>
                              <p className="text-sm text-gray-700 mb-2">
                                {pairing.description}
                              </p>
                              <p className="text-xs text-wine-700 italic">
                                💡 <strong>Varför:</strong> {pairing.why}
                              </p>
                            </div>
                            <ChevronDown className="h-5 w-5 text-wine-600 group-open:rotate-180 transition-transform" />
                          </div>
                        </summary>
                        <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                          <RecipeCard
                            dish={pairing.dish}
                            description={pairing.description}
                            recipe={pairing.recipe || "Recept kommer snart"}
                            why={pairing.why}
                          />
                        </div>
                      </details>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {wine.foodPairing.map((food, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-wine-100 text-wine-800 rounded-full text-sm"
                      >
                        {food}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div>
                {/* Systembolaget länk - En gång högst upp */}
                <div className="mb-6 p-4 bg-gradient-to-r from-wine-50 to-purple-50 rounded-lg border-2 border-wine-300">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">Systembolaget</h3>
                      <p className="text-sm text-gray-600">
                        Sök efter vinet på Systembolaget.se
                      </p>
                      <p className="text-xs text-orange-600 font-medium mt-1">
                        ⚠️ Kontrollera alltid artikelnummer på Systembolaget.se
                      </p>
                    </div>
                    {wine.price && (
                      <p className="text-2xl font-bold text-wine-700">{wine.price} kr</p>
                    )}
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open('https://www.systembolaget.se/', '_blank', 'noopener,noreferrer');
                    }}
                    className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-wine-600 text-white text-sm rounded-lg hover:bg-wine-700 transition-colors font-medium shadow-md"
                  >
                    <ExternalLink className="h-4 w-4" />
                    Sök på Systembolaget.se
                  </button>
                </div>

                <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Andra köpställen
                </h3>
                
                <div className="space-y-3">
                  {wine.purchaseLocations.filter(loc => loc.isPrivateImport).map((location, index) => (
                    <div
                      key={index}
                      className={`flex items-start gap-3 p-4 rounded-lg ${
                        location.isPrivateImport 
                          ? 'bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300' 
                          : 'bg-gray-50 border border-gray-200'
                      }`}
                    >
                      <MapPin className={`h-5 w-5 flex-shrink-0 mt-0.5 ${
                        location.isPrivateImport ? 'text-green-600' : 'text-wine-600'
                      }`} />
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-1">
                          <p className="font-bold text-gray-900">
                            {location.name}
                            {location.isPrivateImport && (
                              <span className="ml-2 px-2 py-0.5 bg-green-600 text-white text-xs rounded-full">
                                Privatimport
                              </span>
                            )}
                          </p>
                          {location.price && (
                            <p className="font-bold text-green-700">
                              {location.price} kr
                            </p>
                          )}
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-1">
                          {location.type === 'store' ? 'Butik' : 
                           location.type === 'private-import' ? 'Privatimport - Köp direkt från importör' :
                           'Online'}
                          {location.stock && ` • ${location.stock}`}
                        </p>
                        
                        {location.savings && location.savings > 0 && (
                          <p className="text-sm font-semibold text-green-700 mb-2">
                            💰 Spara {location.savings} kr jämfört med Systembolaget!
                          </p>
                        )}
                        
                        {location.minimumOrder && (
                          <p className="text-xs text-gray-600 bg-white px-2 py-1 rounded inline-block mb-2">
                            Minsta beställning: {location.minimumOrder}
                          </p>
                        )}
                        
                        {location.isPrivateImport && location.importerContact && (
                          <div className="mt-2 p-2 bg-white rounded text-xs space-y-1">
                            {location.importerContact.email && (
                              <p className="text-gray-700">
                                📧 <a href={`mailto:${location.importerContact.email}`} className="text-wine-600 hover:underline">
                                  {location.importerContact.email}
                                </a>
                              </p>
                            )}
                            {location.importerContact.phone && (
                              <p className="text-gray-700">
                                📞 <a href={`tel:${location.importerContact.phone}`} className="text-wine-600 hover:underline">
                                  {location.importerContact.phone}
                                </a>
                              </p>
                            )}
                            {location.importerContact.orderUrl && (
                              <a
                                href={location.importerContact.orderUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-block mt-2 px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                              >
                                Beställ direkt →
                              </a>
                            )}
                          </div>
                        )}
                        
                        {location.url && !location.isPrivateImport && (
                          <a
                            href={location.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-wine-600 hover:underline inline-block mt-1"
                          >
                            Besök webbplats →
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

