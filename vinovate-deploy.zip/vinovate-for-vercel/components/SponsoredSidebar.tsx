"use client";

import { SponsoredImporter } from "@/types/sponsor";
import { ExternalLink, Wine } from "lucide-react";
import Image from "next/image";

interface SponsoredSidebarProps {
  sponsors: SponsoredImporter[];
}

export default function SponsoredSidebar({ sponsors }: SponsoredSidebarProps) {
  if (sponsors.length === 0) return null;

  const handleClick = (sponsor: SponsoredImporter) => {
    // Track click for analytics
    console.log(`Sidebar ad clicked: ${sponsor.name}`);
    window.open(sponsor.website, '_blank');
  };

  return (
    <div className="space-y-4">
      <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
        Rekommenderade Importörer
      </div>
      
      {sponsors.map((sponsor) => (
        <div
          key={sponsor.id}
          className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => handleClick(sponsor)}
        >
          <div className="bg-gradient-to-r from-amber-100 to-yellow-100 px-3 py-1">
            <span className="text-xs font-semibold text-amber-800">SPONSRAD</span>
          </div>
          
          <div className="p-4">
            {sponsor.logo && (
              <div className="relative w-full h-20 mb-3 bg-gray-50 rounded overflow-hidden">
                <Image
                  src={sponsor.logo}
                  alt={sponsor.name}
                  fill
                  sizes="200px"
                  className="object-contain p-2"
                />
              </div>
            )}
            
            <h4 className="font-bold text-gray-900 mb-2">{sponsor.name}</h4>
            <p className="text-sm text-gray-600 mb-3 line-clamp-2">
              {sponsor.description}
            </p>
            
            {sponsor.featuredWines.length > 0 && (
              <div className="mb-3 p-2 bg-wine-50 rounded">
                <div className="flex items-center gap-2 mb-1">
                  <Wine className="h-4 w-4 text-wine-600" />
                  <span className="text-xs font-semibold text-wine-800">
                    Utvalda viner:
                  </span>
                </div>
                <p className="text-xs text-gray-700">
                  {sponsor.featuredWines[0].name}
                </p>
                {sponsor.featuredWines[0].rating && (
                  <p className="text-xs text-yellow-700 font-medium">
                    ⭐ {sponsor.featuredWines[0].rating}/100
                  </p>
                )}
              </div>
            )}
            
            <button className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-wine-600 text-white text-sm rounded hover:bg-wine-700 transition-colors">
              <ExternalLink className="h-3 w-3" />
              Besök webbplats
            </button>
          </div>
        </div>
      ))}
      
      <div className="text-xs text-gray-500 text-center mt-4 px-2">
        Vill du annonsera här? <a href="mailto:annons@wineai.se" className="text-wine-600 hover:underline">Kontakta oss</a>
      </div>
    </div>
  );
}

