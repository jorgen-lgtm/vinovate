# 🏢 Guide till Importörs-Sökning i WineAI

## Vad är Importörs-Sökning?

Importörs-sökning låter dig utforska hela vinportföljen från en specifik vinimportör. Istället för att söka efter enskilda viner får du en komplett översikt över vad en importör erbjuder.

## Hur använder jag det?

### Steg 1: Välj sökläge
1. Öppna WineAI
2. Klicka på **"Importörs portfölj"** i sökalternativ

### Steg 2: Sök efter importör
Du kan söka på tre sätt:

#### Metod 1: Bara namnet
```
Philipson Söderberg
Wineworld
Kobrand
```

#### Metod 2: Med "Importör:"
```
Importör: Philipson Söderberg
Importör: Wineworld
```

#### Metod 3: Med "Portfolio från"
```
Portfolio från Kobrand
Portfolio från Domaine Select
```

### Steg 3: Utforska resultaten
Du får en tabell med 10-15 viner som visar:
- **Vinnamn** och producent
- **Typ** (Rött, Vitt, etc.)
- **Land och region**
- **Årgång**
- **Betyg** (1-100 skala)
- **Priser** - både importör och Systembolaget
- **Besparingar** - se direkt var det är billigast!

## Svenska Vinimportörer

### Stora Importörer

#### Philipson Söderberg
- **Specialitet**: Premium viner från Frankrike, Italien, Spanien
- **Känt för**: Bordeaux, Bourgogne, Barolo
- **Sortiment**: 500+ viner

#### Wineworld
- **Specialitet**: Global portfolio
- **Känt för**: Champagne, nya världen
- **Sortiment**: 300+ viner

#### Kobrand
- **Specialitet**: Exklusiva producenter
- **Känt för**: Dom Pérignon, Sassicaia
- **Sortiment**: 200+ premium viner

#### Domaine Select
- **Specialitet**: Boutique-producenter
- **Känt för**: Kvalitet över kvantitet
- **Sortiment**: 150+ selecta viner

#### Vinguiden
- **Specialitet**: Italienska och franska viner
- **Känt för**: Piccini, Antinori
- **Sortiment**: 400+ viner

### Medelstora Importörer

- **Bibendum Wine** - Brittiska och franska viner
- **Terroir Wines** - Biodynamiska och naturviner
- **Vintage Port** - Specialiserade på portvin
- **Nordic Wine Group** - Skandinavisk focus

## Vad får jag se?

### Tabell-vy
Alla viner presenteras i en sorterbar tabell där du kan:
- **Sortera** på betyg, pris, land, år
- **Jämföra** priser mellan importör och Systembolaget
- **Filtrera** visuellt (klicka på kolumner)

### Expanderbara rader
Klicka på en rad för att se:

#### 🍽️ Matpairing
- Förslag på maträtter
- Varför de passar
- Receptförslag

#### ⏰ När dricka
- Bästa drickperiod
- Serveringstemperatur
- Lagringspotential

#### 🛒 Var köpa
- Importörens sida
- Systembolaget
- Lagerstatus
- Direktlänkar

### Detaljerad vy
Klicka på "Visa detaljer" för fullständig popup med:
- Vinbild (om tillgänglig)
- Komplett beskrivning
- Provningsanteckningar
- Alla inköpsställen

## Fördelar med Importörs-sökning

### 1. Upptäck Hela Sortiment
Se allt från en importör på en gång istället för att söka vin för vin.

### 2. Prisjämförelse
Importörer kan ofta erbjuda bättre priser än Systembolaget för vissa viner. Se direkt var du sparar pengar!

### 3. Exklusiva Viner
Många importörer har viner som inte finns på Systembolaget - upptäck dolda pärlor.

### 4. Direkt Beställning
Många importörer säljer direkt till konsumenter. Se kontaktinfo och länkar.

### 5. Bättre Urval
Importörer har ofta större urval inom specifika regioner eller producenter.

## Tips & Tricks

### Tip 1: Sortera på Betyg
Klicka på "Betyg"-kolumnen för att se högst rankade viner först.

### Tip 2: Leta efter Besparingar
Grön text = billigare hos importören. Röd text = billigare på Systembolaget.

### Tip 3: Kombinera med Filter
Använd avancerade filter innan sökning för att smalna av:
- Land: Italien
- Prisklass: 200-300 kr
- Sedan sök: "Philipson Söderberg"

### Tip 4: Expandera för Detaljer
Klicka på rader för snabb översikt, "Visa detaljer" för djupdykning.

### Tip 5: Spara Intressanta
Notera artikelnummer (systembolagetNumber) för lätt återköp.

## Vanliga Frågor

**Q: Hur många viner får jag?**  
A: 10-15 viner per importör, sorterade efter betyg.

**Q: Är priserna aktuella?**  
A: AI ger uppskattningar. Kontrollera alltid med importören/Systembolaget.

**Q: Kan jag köpa direkt?**  
A: Många importörer säljer direkt. Klicka på länkar i "Var kan jag köpa".

**Q: Varför ser jag inte bilder?**  
A: Bilder kräver integration med Systembolagets API (kommer i framtida version).

**Q: Kan jag söka flera importörer samtidigt?**  
A: Nej, en importör åt gången för bästa resultat.

**Q: Finns alla svenska importörer?**  
A: AI känner till stora importörer. Mindre boutique-importörer kan ge begränsade resultat.

## Exempel på Sökningar

### Exempel 1: Premium Bordeaux
```
1. Sök: "Philipson Söderberg"
2. Sortera: Betyg (högst först)
3. Filtrera: Land = Frankrike
4. Hitta: Premium Bordeaux-viner
```

### Exempel 2: Italienska Pärlor
```
1. Sök: "Vinguiden"
2. Expandera: Viner från Toscana
3. Jämför: Priser
4. Köp: Direkt från importör om billigare
```

### Exempel 3: Champagne till Fest
```
1. Sök: "Kobrand"
2. Filtrera: Typ = Mousserande
3. Sortera: Pris (lägst först)
4. Hitta: Bra champagne inom budget
```

## Kontakta Importörer

### Philipson Söderberg
- **Webb**: philipson-soderberg.se
- **Tel**: 08-587 094 00
- **E-post**: info@philipson-soderberg.se

### Wineworld
- **Webb**: wineworld.se
- **Tel**: 08-587 220 00
- **E-post**: info@wineworld.se

### Kobrand
- **Webb**: kobrand.se
- **Tel**: 08-545 670 00
- **E-post**: info@kobrand.se

*(Kontaktuppgifter är exempel - verifiera alltid aktuell info)*

---

**Lycka till med din importörs-utforskning! 🍷**

**Pro-tips**: Många importörer erbjuder provningar och events - kolla deras webbplatser!

