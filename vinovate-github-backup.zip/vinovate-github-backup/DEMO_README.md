# 🍷 Vinovate AI Demo - Fullt Funktionell Vinsökning

## 🚀 Snabbstart

### 1. Installation
```bash
# Klona eller ladda ner projektet
cd WineAI

# Installera dependencies
npm install

# Skapa miljövariabel
echo "OPENAI_API_KEY=din_openai_api_nyckel" > .env.local

# Starta utvecklingsserver
npm run dev
```

### 2. Öppna Demo
Gå till: `http://localhost:3000/demo`

## ✨ AI-funktioner

### 🎯 Intelligent Vinsökning
- **Naturligt språk**: "rött vin till biff", "champagne under 500 kr"
- **Matpairing**: AI förstår vilken mat som ska serveras
- **Prisklass**: Tolkar budget och prisklasser
- **Land/region**: Känner igen geografiska preferenser

### 🍷 Expertrekommendationer
- **Betyg**: Sorterat efter kvalitet (högsta först)
- **Tillgänglighet**: Systembolaget + privatimport
- **Detaljerad info**: Provningsanteckningar, serveringstemperatur
- **Recept**: Kompletta matrecept för varje vin

### 📊 Smart Caching
- **Snabbhet**: Cachar resultat för snabbare sökningar
- **Kostnadseffektivt**: Minskar OpenAI API-anrop
- **Konsekvent**: Samma sökning ger samma resultat

## 🎮 Demo-exempel

### Grundläggande sökningar:
- "rött vin till biff"
- "vitt vin till fisk"
- "champagne till fest"

### Avancerade sökningar:
- "italienskt vin till pasta under 200 kr"
- "premium rött vin för lagring"
- "franskt vin till ost"

### Specifika preferenser:
- "rosévin till sommar"
- "vitt vin till kyckling"
- "mousserande vin till dessert"

## 🔧 Teknisk Arkitektur

### AI Integration
- **OpenAI GPT-4o**: Huvudmotor för vinrekommendationer
- **Strukturerad JSON**: Konsistent dataformat
- **Felhantering**: Fallback till enkel sökning vid problem

### API Endpoints
- `/api/ai-wine-search`: Huvud-AI-sökning
- `/api/search-wine-simple`: Fallback för enkel sökning
- `/api/importer-search`: Producent/importör-sökning

### Frontend
- **Next.js 14**: App Router med TypeScript
- **Tailwind CSS**: Responsiv design
- **React Hooks**: State management
- **Lucide Icons**: Moderna ikoner

## 📱 Responsiv Design

### Desktop
- 3-kolumns layout för vinkort
- Stora bilder och detaljerad information
- Hover-effekter och animationer

### Mobile
- 1-kolumns layout
- Touch-vänliga knappar
- Optimerad för pekskärmar

## 🎨 UI/UX Features

### Visuell Design
- **Gradient bakgrund**: Vin-tema med lila/rött
- **Glassmorphism**: Genomskinliga kort med blur-effekt
- **Smooth animationer**: Hover och transition-effekter

### Användarupplevelse
- **Exempel-sökningar**: Klickbara exempel för snabb start
- **Loading states**: Tydlig feedback under sökning
- **Error handling**: Vänliga felmeddelanden
- **Modal popup**: Detaljerad vininformation

## 🔐 Säkerhet & Prestanda

### API-säkerhet
- **Rate limiting**: Förhindrar missbruk
- **Input validation**: Säker hantering av användarinput
- **Error boundaries**: Graceful felhantering

### Prestanda
- **Image optimization**: Next.js Image-komponent
- **Code splitting**: Lazy loading av komponenter
- **Caching**: Redis-liknande cache för API-svar

## 📈 Skalbarhet

### Produktionsredo
- **Environment variables**: Säker konfiguration
- **Docker support**: Containerisering
- **CI/CD**: Automatiserad deployment
- **Monitoring**: Logging och felspårning

### Monetisering
- **Sponsrade viner**: Integrerat annonssystem
- **Premium features**: Avancerade sökfilter
- **Analytics**: Användarstatistik

## 🚀 Deployment

### Vercel (Rekommenderat)
```bash
# Installera Vercel CLI
npm i -g vercel

# Deploy
vercel

# Lägg till miljövariabler i Vercel dashboard
OPENAI_API_KEY=din_nyckel
```

### Docker
```bash
# Bygg image
docker build -t vinovate-demo .

# Kör container
docker run -p 3000:3000 -e OPENAI_API_KEY=din_nyckel vinovate-demo
```

## 📞 Support

### Vanliga problem
1. **API-nyckel saknas**: Kontrollera `.env.local`
2. **Långsam sökning**: Kontrollera internetanslutning
3. **Inga resultat**: Prova enklare söktermer

### Utveckling
- **Hot reload**: Automatisk uppdatering vid ändringar
- **TypeScript**: Typ-säker utveckling
- **ESLint**: Kodkvalitet och konsistens

## 🎯 Nästa steg

### Planerade funktioner
- **Användarkonton**: Spara favoriter och sökhistorik
- **Social features**: Dela rekommendationer
- **Mobile app**: React Native-version
- **AI-chatbot**: Interaktiv vinrådgivning

### Integreringar
- **Systembolaget API**: Riktiga produktdata
- **Payment**: Betalning för premium
- **Email**: Nyhetsbrev och rekommendationer

---

**Vinovate AI Demo** - Där passion möter innovation 🍷✨
