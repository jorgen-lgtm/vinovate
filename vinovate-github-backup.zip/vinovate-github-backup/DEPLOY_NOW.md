# 🚀 Deploy Vinovate NU!

**Snabbguide för att få igång Vinovate på 10 minuter**

## Steg 1: Förbered miljövariabler (2 min)

Skapa `.env.local` med:
```bash
OPENAI_API_KEY=din_openai_nyckel
ADMIN_PASSWORD=ditt_sakra_losenord
```

**Tips:** Generera säkert lösenord:
```bash
openssl rand -base64 32
```

## Steg 2: Testa lokalt (2 min)

```bash
npm run build
npm run start
```

Öppna `http://localhost:3000` och testa:
- ✅ Vinsökning fungerar
- ✅ Admin-inloggning fungerar (`/admin`)
- ✅ Inga sponsrade viner visas (alla inaktiverade)

## Steg 3: Deploy till Vercel (5 min)

### A. Via Vercel CLI (Snabbast)

```bash
# Installera Vercel CLI
npm install -g vercel

# Logga in
vercel login

# Deploy
vercel

# Sätt miljövariabler
vercel env add OPENAI_API_KEY
vercel env add ADMIN_PASSWORD

# Production deploy
vercel --prod
```

### B. Via GitHub (Enklast)

1. **Pusha till GitHub**
```bash
git add .
git commit -m "Initial Vinovate deployment"
git push origin main
```

2. **Importera på Vercel**
- Gå till https://vercel.com
- Klicka "Import Project"
- Välj ditt GitHub repo
- Lägg till miljövariabler:
  - `OPENAI_API_KEY`
  - `ADMIN_PASSWORD`
- Klicka "Deploy"

## Steg 4: Verifiera deployment (1 min)

```bash
# Testa health check
curl https://your-domain.vercel.app/api/health

# Förväntat svar:
# {"status":"ok","message":"Vinovate API is running","openaiConfigured":true}
```

## Steg 5: Aktivera första sponsorn

1. Gå till `https://your-domain.vercel.app/admin`
2. Logga in med ditt admin-lösenord
3. Klicka "Aktivera" på en sponsor
4. Testa vinsökning - sponsrat vin ska nu visas!

## 🎉 Klart!

Din Vinovate-installation är nu live!

### Nästa steg:
1. ✅ Konfigurera custom domain (vinovate.se)
2. ✅ Sätt upp monitoring
3. ✅ Kontakta potentiella sponsorer
4. ✅ Börja tjäna pengar! 💰

## Snabblänkar

- **Huvudsida:** https://your-domain.vercel.app
- **Admin:** https://your-domain.vercel.app/admin
- **Health:** https://your-domain.vercel.app/api/health
- **Vercel Dashboard:** https://vercel.com/dashboard

## Troubleshooting

### Problem: Build failed
**Lösning:** Kör `npm run build` lokalt först för att hitta fel

### Problem: 500 error
**Lösning:** Kontrollera att miljövariabler är satta i Vercel

### Problem: Admin login fungerar inte
**Lösning:** Verifiera att `ADMIN_PASSWORD` är satt

## Support

📧 support@vinovate.se
📞 070-123 45 67

**Lycka till med lanseringen! 🚀🍷✨**

