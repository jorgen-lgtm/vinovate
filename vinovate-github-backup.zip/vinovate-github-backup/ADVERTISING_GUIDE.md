# Vinovate Annonsguide

**Där passion möter innovation**

## Översikt
Vinovate erbjuder ett intelligent annonssystem där sponsrade viner **endast visas när de matchar användarens sökning**. Detta garanterar relevans och hög konvertering.

## Hur det fungerar

### Intelligent Matchning
När en användare söker visas sponsrade viner **endast om de matchar sökningen**:

#### Exempel:
- **Sökning:** "italienskt rött vin"
  - ✅ Visar: Barolo från Vinguiden Premium (italienskt)
  - ✅ Matchar: Land, typ, specialisering

- **Sökning:** "franskt vin"
  - ❌ Visar INTE italienska sponsrade viner
  - ✅ Endast relevanta sponsorer visas

- **Sökning:** "Barolo"
  - ✅ Visar: Barolo från Vinguiden Premium
  - ✅ Exakt match på vinnamn

### Matchningskriterier
Sponsrade viner visas om de matchar:
1. **Vinnamn** (t.ex. "Barolo", "Chianti")
2. **Land** (t.ex. "Italien", "Frankrike")
3. **Region** (t.ex. "Piemonte", "Toscana")
4. **Vintyp** (t.ex. "Rött vin", "Vitt vin")
5. **Sponsor specialisering** (t.ex. "Italien", "Ekologiskt")

## Annonspaket

### 🌟 Premium - 15,000 kr/månad
**Perfekt för stora importörer med brett sortiment**

✅ **100 visningar/dag** i sökresultat  
✅ **Banner-annons** överst på sidan  
✅ **Sidebar-annons** (sticky, alltid synlig)  
✅ **5 utvalda viner** i rotation  
✅ **Högsta prioritet** (10x viktat)  
✅ **Garanterad synlighet** vid matchande sökningar  

**ROI-exempel:**
- 100 visningar/dag × 30 dagar = 3,000 visningar/månad
- Estimerad CTR: 5% = 150 klick
- Kostnad per klick: 100 kr
- Konvertering: 10% = 15 beställningar
- Genomsnittlig order: 2,000 kr
- **Total försäljning: 30,000 kr/månad**
- **Vinst: 15,000 kr (100% ROI)**

### 📊 Standard - 8,000 kr/månad
**Perfekt för medelstora importörer med fokuserat sortiment**

✅ **50 visningar/dag** i sökresultat  
✅ **Sidebar-annons** (sticky)  
✅ **3 utvalda viner** i rotation  
✅ **Hög prioritet** (7x viktat)  

**ROI-exempel:**
- 50 visningar/dag × 30 dagar = 1,500 visningar/månad
- Estimerad CTR: 5% = 75 klick
- **Vinst: 7,000 kr (87% ROI)**

### 📦 Basic - 3,000 kr/månad
**Perfekt för mindre importörer och nystartade företag**

✅ **20 visningar/dag** i sökresultat  
✅ **1 utvalt vin**  
✅ **Standard prioritet** (5x viktat)  

**ROI-exempel:**
- 20 visningar/dag × 30 dagar = 600 visningar/månad
- Estimerad CTR: 5% = 30 klick
- **Vinst: 3,000 kr (100% ROI)**

## Annonsplatser

### 1. Banner-annons (Premium)
- **Placering:** Överst på sidan, före sökresultat
- **Design:** Guld/gul gradient med logo och utvalda viner
- **Synlighet:** Första användaren ser
- **Storlek:** Full bredd, ~150px höjd
- **Sticky:** Nej

### 2. Sidebar-annons (Premium & Standard)
- **Placering:** Höger sidebar
- **Design:** Kompakt kort med logo och info
- **Synlighet:** Alltid synlig vid scroll
- **Storlek:** 300px bredd
- **Sticky:** Ja

### 3. Sponsrade viner i sökresultat (Alla paket)
- **Placering:** Första positionen i sökresultat
- **Design:** Guld/gul design med "SPONSRAD"-märkning
- **Synlighet:** Garanterad vid matchande sökning
- **Markering:** Tydligt märkt "⭐ Sponsrad av [Importör]"

## Teknisk Implementation

### Viktad Visning
Sponsorer visas baserat på prioritet och relevans:
- **Premium (10):** 10x högre chans att visas
- **Standard (7):** 7x högre chans att visas
- **Basic (5):** 5x högre chans att visas

### Smart Matchning
```typescript
// Exempel: Sökning på "italienskt rött vin från Piemonte"
// Systemet kollar:
1. Har sponsorn "Italien" i specialisering? ✓
2. Har sponsorn "Piemonte" i specialisering? ✓
3. Har sponsorn viner från Italien? ✓
4. Har sponsorn viner från Piemonte? ✓

// Resultat: Visar Barolo från Vinguiden Premium
```

### Ingen Matchning = Ingen Visning
Om ingen sponsor matchar sökningen visas **inga sponsrade viner**. Detta garanterar:
- ✅ Hög relevans för användaren
- ✅ Bättre konvertering för sponsorn
- ✅ Bättre användarupplevelse

## Statistik & Tracking

### Admin Dashboard (`/admin`)
- 📊 Antal aktiva sponsorer
- 💰 Estimerad månadsintäkt
- 📦 Antal utvalda viner
- 👁️ Annonsplatser aktiva
- 📈 Fördelning per paket

### Framtida Tracking (Fas 2)
- Impressions per sponsor
- Klick per sponsor
- CTR (Click-Through Rate)
- Konverteringar
- ROI-beräkningar

## Prissättning & ROI

### Varför WineAI är värt investeringen:

1. **Målgrupp:** Vinentusiaster med köpkraft
2. **Intent:** Användare söker aktivt efter vin att köpa
3. **Relevans:** Endast matchande annonser visas
4. **Synlighet:** Garanterad placering vid matchning
5. **Direktlänkar:** Enkel väg till beställning

### Jämförelse med andra kanaler:

| Kanal | Kostnad/månad | Målgrupp | Relevans | ROI |
|-------|---------------|----------|----------|-----|
| Vinovate Premium | 15,000 kr | Hög | Mycket hög | 100%+ |
| Google Ads | 20,000 kr | Medel | Medel | 50-80% |
| Facebook Ads | 15,000 kr | Låg | Låg | 30-50% |
| Tidningsannons | 10,000 kr | Medel | Låg | 20-40% |

## Kom igång

### Steg 1: Välj paket
Kontakta oss för att diskutera vilket paket som passar er:
- 📧 **Email:** annons@wineai.se
- 📞 **Telefon:** 070-123 45 67

### Steg 2: Skicka material
Vi behöver:
- Logo (PNG/SVG, 200×200px)
- Företagsbeskrivning (max 200 tecken)
- 1-5 utvalda viner med:
  - Vinnamn
  - Producent
  - Land/Region
  - Pris
  - Beskrivning
  - Bild (valfritt)
  - Systembolaget-nummer (om finns)

### Steg 3: Aktivering
- Vi sätter upp er profil
- Ni får tillgång till statistik
- Aktivering inom 24 timmar

### Steg 4: Optimering
- Vi följer upp resultat månadsvis
- Justerar strategi baserat på data
- Föreslår förbättringar

## Vanliga frågor

### Q: Visas mina viner i varje sökning?
**A:** Nej, endast när de matchar användarens sökning. Detta ger högre relevans och bättre konvertering.

### Q: Kan jag byta ut mina utvalda viner?
**A:** Ja, kontakta oss så uppdaterar vi inom 24 timmar.

### Q: Hur mäts resultatet?
**A:** Vi ger dig månadsrapporter med impressions, klick och CTR. I Fas 2 får ni tillgång till realtidsstatistik.

### Q: Kan jag pausa mitt sponsorskap?
**A:** Ja, med 30 dagars uppsägningstid.

### Q: Vad händer om ingen söker på mina viner?
**A:** Vi hjälper er optimera era utvalda viner och specialiseringar för att matcha populära sökningar.

### Q: Kan jag testa först?
**A:** Ja, vi erbjuder en gratis testperiod på 2 veckor för Basic-paketet.

## Kontakt

**Vill du nå tusentals vinentusiaster varje månad?**

📧 **Email:** annons@vinovate.se  
📞 **Telefon:** 070-123 45 67  
🌐 **Admin:** https://vinovate.se/admin  
💼 **LinkedIn:** [Vinovate Business](https://linkedin.com/company/vinovate)

**Vi hjälper dig skapa ett skräddarsytt sponsorpaket!**

---

*Uppdaterad: Oktober 2025*

