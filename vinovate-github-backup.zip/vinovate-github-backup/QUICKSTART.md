# 🚀 Snabbstart - WineAI

## 3 enkla steg för att komma igång

### 1️⃣ Installera dependencies
\`\`\`bash
npm install
\`\`\`

### 2️⃣ Konfigurera OpenAI API
Skapa en `.env.local` fil i projektets rot:
\`\`\`bash
echo "OPENAI_API_KEY=din-api-nyckel-här" > .env.local
\`\`\`

Eller kopiera från exempel-filen:
\`\`\`bash
cp .env.example .env.local
\`\`\`
Redigera sedan `.env.local` och lägg till din riktiga API-nyckel.

### 3️⃣ Starta applikationen
\`\`\`bash
npm run dev
\`\`\`

Öppna [http://localhost:3000](http://localhost:3000) 🎉

## Var får jag en OpenAI API-nyckel?

1. Gå till [platform.openai.com](https://platform.openai.com/)
2. Skapa ett konto eller logga in
3. Navigera till [API Keys](https://platform.openai.com/api-keys)
4. Klicka på "Create new secret key"
5. Kopiera nyckeln (den börjar med `sk-proj-...`)

## Första sökningen

När appen är igång, prova att söka:
- "Rött vin till pasta carbonara"
- "Champagne till fest under 400 kr"
- Eller klicka på ett av exemplen!

## Felsökning

**Applikationen startar inte:**
- Kontrollera att Node.js är installerat: `node --version`
- Installera om dependencies: `rm -rf node_modules && npm install`

**API-fel vid sökning:**
- Kontrollera att `.env.local` existerar
- Kontrollera att API-nyckeln är korrekt kopierad (inga mellanslag)
- Starta om dev-servern efter att ha lagt till API-nyckeln

**Inga resultat:**
- Kontrollera din internetanslutning
- Kontrollera att du har krediter på ditt OpenAI-konto
- Kolla konsolen för felmeddelanden (F12 i webbläsaren)

## Nästa steg

- Läs [README.md](README.md) för fullständig dokumentation
- Se [EXAMPLES.md](EXAMPLES.md) för fler sökexempel
- Läs [SETUP.md](SETUP.md) för detaljerad setup-guide

Lycka till med din vinupplevelse! 🍷✨

