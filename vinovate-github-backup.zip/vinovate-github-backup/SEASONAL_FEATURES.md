# 🍂 Säsongsanpassade Funktioner i WineAI

## Översikt

WineAI anpassar automatiskt exempel-förslag och hälsningar baserat på aktuell säsong. Detta ger användare relevanta vinförslag som passar tiden på året.

## Säsonger

### 🌸 Vår (Mars - Maj)
**Tema:** Fräscht, lätt, förnyelse

**Exempel-sökningar:**
- "Fräscht vitt vin till vårsallad"
- "Rosé till terassen"
- "Lätt rött vin till lamm"
- "Prosecco till brunch"
- "Vårlig Sauvignon Blanc"

**Hälsning:**
"Välkommen till våren! Upptäck fräscha viner för säsongen."

**Typiska maträtter:**
- Vårsallader med sparris
- Lammrätter (påsk)
- Lätta fiskrätter
- Utomhusgrillning börjar

---

### ☀️ Sommar (Juni - Augusti)
**Tema:** Kallskänkt, lätt, utomhus

**Exempel-sökningar:**
- "Kallskänkt rosé till sommar"
- "Fräsch Albariño till skaldjur"
- "Mousserande till midsommar"
- "Vitt vin till grillad fisk"
- "Lätt rött till grill under 150 kr"

**Hälsning:**
"Sommarens bästa viner väntar! Hitta perfekt vin till grillen."

**Typiska maträtter:**
- Grillat kött och fisk
- Skaldjur
- Sallader
- Midsommar-fest
- Utomhusmat

---

### 🍂 Höst (September - November)
**Tema:** Kraftfullt, viltkött, svamp

**Exempel-sökningar:**
- "Rött vin till viltkött"
- "Barolo till svampragu"
- "Kraftfullt vin till höstgryta"
- "Amarone till viltfond"
- "Bordeaux till oxfilé"

**Hälsning:**
"Höstens viner är här! Kraftfulla röda till säsongens rätter."

**Typiska maträtter:**
- Viltkött (älg, hjort, rådjur)
- Svamprätter
- Grytor och lång kok
- Rotfrukter
- Kraftiga såser

**Nuvarande:** ✓ **Vi är i höst-säsongen nu (Oktober 2025)**

---

### ❄️ Vinter (December - Februari)
**Tema:** Fylligt, varmt, fest

**Exempel-sökningar:**
- "Fylligt rött vin till julbord"
- "Portvin till dessert"
- "Kraftig Syrah till lammstek"
- "Barolo till hjortfilé"
- "Vin till vintergryta"

**Hälsning:**
"Vinterns värme i glaset! Hitta fylliga viner till kalla kvällar."

**Typiska maträtter:**
- Julmat
- Stek och stora kötträtter
- Vintergrytor
- Dessertvin till kaffe
- Innemiddag

---

## Teknisk Implementation

### Automatisk Säsongs-Detektion

```typescript
function getCurrentSeason(): Season {
  const month = new Date().getMonth() + 1;
  
  if (month >= 3 && month <= 5) return 'spring';
  if (month >= 6 && month <= 8) return 'summer';
  if (month >= 9 && month <= 11) return 'autumn';
  return 'winter';
}
```

### Komponenter som Använder Säsong

#### 1. ExampleQueries.tsx
- Visar säsongsikon (🌸☀️🍂❄️)
- Visar säsongsnamn ("Höst-förslag")
- Badge: "Säsongsanpassat"
- Säsongens exempel-queries

#### 2. app/page.tsx
- Säsongsanpassad hälsning under rubriken
- Uppdateras automatiskt

### Fil-Struktur

```
lib/seasonalExamples.ts       # Säsongs-logik och data
components/ExampleQueries.tsx # Visar säsongsexempel
app/page.tsx                  # Visar säsongshälsning
```

## Användnings-Exempel

### Höst (Nu - Oktober)

**Vad användare ser:**
```
🍷 WineAI
Din intelligenta vinrådgivare - hitta det perfekta vinet med AI
Höstens viner är här! Kraftfulla röda till säsongens rätter.

✨ 🍂 Höst-förslag [Säsongsanpassat]
[Rött vin till viltkött] [Barolo till svampragu]
[Kraftfullt vin till höstgryta] [Amarone till viltfond]
```

### Vinter (December - Februari)

**Vad användare ser:**
```
🍷 WineAI
Din intelligenta vinrådgivare - hitta det perfekta vinet med AI
Vinterns värme i glaset! Hitta fylliga viner till kalla kvällar.

✨ ❄️ Vinter-förslag [Säsongsanpassat]
[Fylligt rött vin till julbord] [Portvin till dessert]
[Kraftig Syrah till lammstek] [Barolo till hjortfilé]
```

## Fördelar

### 1. Relevans 📅
Användare får förslag som matchar säsongens mat och tillfällen.

### 2. Upptäckt 🔍
Lär användare om säsongens specialiteter (t.ex. viltkött på hösten).

### 3. Försäljning 💰
Hjälper importörer/butiker att pusha säsongens viner.

### 4. Inspiration ✨
Ger idéer användare kanske inte tänkt på själva.

### 5. Automatisk 🤖
Ingen manuell uppdatering - ändras automatiskt vid säsongsskifte.

## Framtida Förbättringar

### Version 2.0: Speciella Tillfällen

```typescript
// Detektera speciella datum
- Valborg (30 april): "Mousserande till valborg"
- Midsommar (juni): "Rosé till sillfest"
- Jul (december): "Vin till julbord"
- Nyår (31 dec): "Champagne till nyår"
- Kräftpremiär (augusti): "Vitt vin till kräftor"
```

### Version 3.0: Väder-Anpassning

```typescript
// Integration med väder-API
- Varmt väder: Föreslå lätta, kalla viner
- Kallt väder: Föreslå fylliga, varma viner
- Regn: Föreslå mys-viner för hemmet
```

### Version 4.0: Regional Anpassning

```typescript
// Olika för olika delar av Sverige
- Norra Sverige: Tidigare höst, senare vår
- Södra Sverige: Längre sommar
- Västkusten: Mer skaldjur-fokus
```

### Version 5.0: Personalisering

```typescript
// Användarprofil
- Tidigare sökningar
- Favoriter
- Preferred säsongsstil
- Kalender-integration (födelsedagar, events)
```

## Anpassa Själv

### Lägg till Egna Exempel

Redigera `/lib/seasonalExamples.ts`:

```typescript
autumn: [
  "Rött vin till viltkött",
  "Barolo till svampragu",
  "DIN EGEN HÖST-QUERY HÄR", // Lägg till här!
],
```

### Ändra Säsongs-Datum

```typescript
// T.ex. för australisk kalender (omvänt)
if (month >= 3 && month <= 5) return 'autumn';  // Mars-Maj
if (month >= 6 && month <= 8) return 'winter';  // Juni-Augusti
// osv...
```

### Lägg till Ny Säsong

```typescript
// T.ex. "early-summer" (försommar)
export type Season = 'spring' | 'early-summer' | 'summer' | ...

seasonalExamples = {
  'early-summer': [
    "Rosé till första grillen",
    "Fräscht till utomhusmiddag",
  ],
  // ...
};
```

## Testing

### Testa Olika Säsonger

```typescript
// I lib/seasonalExamples.ts, override getCurrentSeason():
export function getCurrentSeason(): Season {
  // return 'spring';  // Testa vår
  // return 'summer';  // Testa sommar
  return 'autumn';     // Testa höst (nuvarande)
  // return 'winter';  // Testa vinter
}
```

Refresh webbläsaren för att se säsongens exempel!

## API för Säsongs-Info

### GET /api/season (optional)

Skapa endpoint för att hämta säsongsinformation:

```typescript
// app/api/season/route.ts
import { getCurrentSeason, getSeasonalExamples } from '@/lib/seasonalExamples';

export async function GET() {
  return NextResponse.json({
    season: getCurrentSeason(),
    examples: getSeasonalExamples(),
    greeting: getSeasonalGreeting()
  });
}
```

## Säsongs-Kalender

| Månad | Säsong | Fokus |
|-------|--------|-------|
| Jan | ❄️ Vinter | Julrester, mys-viner |
| Feb | ❄️ Vinter | Köttfest, fylliga röda |
| **Mar** | 🌸 Vår | Påsk börjar närma sig |
| Apr | 🌸 Vår | Lamm, valborg |
| Maj | 🌸 Vår | Utomhus-säsong startar |
| **Jun** | ☀️ Sommar | Midsommar, grill, rosé |
| Jul | ☀️ Sommar | Skaldjur, lätta vita |
| Aug | ☀️ Sommar | Kräftor, fortsatt grill |
| **Sep** | 🍂 Höst | Vilt börjar, svamp |
| **Okt** | 🍂 Höst | Viltsäsong, kraftiga röda |
| Nov | 🍂 Höst | Höstgrytor, långkok |
| **Dec** | ❄️ Vinter | Jul, fest, portvin |

**✓ = Vi är här nu (Oktober = Höst)**

## Sammanfattning

✅ **Säsongsanpassade exempel** - 5 nya förslag varje säsong  
✅ **Automatisk uppdatering** - Ändras vid månadsskifte  
✅ **Säsongshälsning** - Under WineAI-logotyp  
✅ **Visuella ikoner** - 🌸☀️🍂❄️  
✅ **"Säsongsanpassat" badge** - Tydlig markering  

**Appen känns nu levande och relevant för tiden på året! 🍷🍂**

