# Bidra till WineAI

Tack för ditt intresse att bidra till WineAI! Här är några riktlinjer.

## Utvecklingsmiljö

1. Forka projektet
2. Klona din fork:
   \`\`\`bash
   git clone https://github.com/ditt-användarnamn/WineAI.git
   cd WineAI
   \`\`\`

3. Installera dependencies:
   \`\`\`bash
   npm install
   \`\`\`

4. Skapa en branch för din feature:
   \`\`\`bash
   git checkout -b feature/min-nya-feature
   \`\`\`

## Kod-standard

- Använd TypeScript för all kod
- Följ ESLint-reglerna (kör `npm run lint`)
- Använd Tailwind CSS för styling
- Skriv beskrivande commit-meddelanden
- Testa dina ändringar lokalt innan du pushar

## Pull Requests

1. Uppdatera README.md om nödvändigt
2. Se till att linting fungerar: `npm run lint`
3. Testa att appen bygger: `npm run build`
4. Skapa en pull request med en tydlig beskrivning

## Idéer för bidrag

### Features
- [ ] Integration med Systembolagets officiella API
- [ ] Användarautentisering och favoriter
- [ ] Dela vinrekommendationer
- [ ] Fler språk (engelska, etc.)
- [ ] Mobilapp med React Native
- [ ] Vinkarta med regioner
- [ ] Betygshistorik och grafer

### Förbättringar
- [ ] Bättre caching av AI-svar
- [ ] Bildoptimering
- [ ] Progressive Web App (PWA)
- [ ] Dark mode
- [ ] Accessibility förbättringar
- [ ] Enhetstester

### Buggar
Om du hittar en bugg, öppna en issue med:
- Beskrivning av problemet
- Steg för att återskapa
- Förväntad vs faktisk beteende
- Screenshots om relevant

## Frågor?

Öppna en issue med taggen "question"!

Tack för din hjälp att göra WineAI bättre! 🍷

