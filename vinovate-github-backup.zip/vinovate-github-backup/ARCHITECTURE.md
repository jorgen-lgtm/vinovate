# WineAI - Systemarkitektur

## 🏛️ Arkitektur-översikt

```
┌─────────────────────────────────────────────────────────┐
│                    ANVÄNDARE                             │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│              NEXT.JS FRONTEND (React)                    │
│  ┌────────────┐  ┌────────────┐  ┌──────────────────┐  │
│  │ WineSearch │  │ WineModal  │  │ ExampleQueries   │  │
│  │ Component  │  │ Component  │  │ Component        │  │
│  └────────────┘  └────────────┘  └──────────────────┘  │
│                                                          │
│  State Management: React Hooks (useState, useEffect)     │
│  Styling: Tailwind CSS                                   │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼ HTTP Request
┌─────────────────────────────────────────────────────────┐
│            NEXT.JS API ROUTES (Backend)                  │
│  ┌────────────────────────────────────────────────────┐ │
│  │  /api/search-wine                                   │ │
│  │  - Validerar input                                  │ │
│  │  - Anropar OpenAI                                   │ │
│  │  - Bearbetar svar                                   │ │
│  │  - Returnerar JSON                                  │ │
│  └────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────┐ │
│  │  /api/health                                        │ │
│  │  - Health check                                     │ │
│  └────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼ API Call
┌─────────────────────────────────────────────────────────┐
│                 OPENAI API (GPT-4o)                      │
│  - Naturligt språk-processing                            │
│  - Vinrekommendationer                                   │
│  - Matpairing                                            │
│  - Strukturerad JSON-output                              │
└─────────────────────────────────────────────────────────┘
```

## 📦 Komponent-hierarki

```
app/page.tsx (Home)
├── ExampleQueries
│   └── onClick → uppdaterar searchQuery
├── WineSearch
│   ├── Form Input
│   ├── Priority Toggle (Quick/Best)
│   ├── Search Button
│   └── Results List
│       └── Wine Card → onClick → öppnar modal
├── WineModal (conditional)
│   ├── Wine Image
│   ├── Wine Details
│   ├── Tasting Notes
│   ├── Food Pairing
│   └── Purchase Locations
└── Footer
```

## 🔄 Dataflöde

### 1. Sökning
```
Användare anger sökning
    ↓
WineSearch component
    ↓
handleSearch() körs
    ↓
POST /api/search-wine
    ↓
OpenAI API anrop
    ↓
JSON-parsning och validering
    ↓
Systembolaget-berikning (om tillgänglig)
    ↓
Returnera wines[]
    ↓
Uppdatera results state
    ↓
Visa vinlista
```

### 2. Visa detaljer
```
Användare klickar på vin
    ↓
onWineSelect(wine) anropas
    ↓
setSelectedWine(wine) uppdaterar state
    ↓
WineModal renderas med wine-data
    ↓
Modal visas med animation
```

## 🗂️ Filstruktur och ansvar

### Frontend Components

#### `app/page.tsx`
- **Ansvar**: Huvudsida, state management
- **State**: selectedWine, searchQuery
- **Rendering**: Komponenter och layout

#### `components/WineSearch.tsx`
- **Ansvar**: Sökgränssnitt och resultatvisning
- **State**: query, preferQuick, loading, results, error
- **API-kommunikation**: POST /api/search-wine

#### `components/WineModal.tsx`
- **Ansvar**: Detaljerad vinvisning
- **Props**: wine, onClose
- **Features**: Bild, beskrivning, betyg, inköpsställen

#### `components/ExampleQueries.tsx`
- **Ansvar**: Fördefinierade exempel-sökningar
- **Props**: onSelectExample
- **Features**: Klickbara exempel-queries

#### `components/Footer.tsx`
- **Ansvar**: Sidfot med länkar
- **Features**: Credits, externa länkar

### Backend API

#### `app/api/search-wine/route.ts`
- **Metod**: POST
- **Input**: { query: string, preferQuick: boolean }
- **Process**:
  1. Validera input
  2. Konstruera OpenAI-prompt
  3. Anropa OpenAI API
  4. Parsera JSON-svar
  5. Berika med Systembolaget-data
- **Output**: { wines: Wine[] }

#### `app/api/health/route.ts`
- **Metod**: GET
- **Output**: { status, message, openaiConfigured }

### Types

#### `types/wine.ts`
```typescript
interface Wine {
  name: string
  producer: string
  type: string
  country: string
  region?: string
  year?: string
  price?: number
  rating?: number
  description: string
  foodPairing: string[]
  imageUrl?: string
  systembolagetNumber?: string
  availability: 'quick' | 'better'
  tastingNotes?: string
  purchaseLocations: PurchaseLocation[]
}

interface PurchaseLocation {
  name: string
  type: 'store' | 'online'
  url?: string
  stock?: string
}
```

## 🔌 API Integration

### OpenAI GPT-4o
- **Modell**: `gpt-4o`
- **Temperature**: 0.7 (balans mellan kreativitet och konsistens)
- **Prompt-strategi**: 
  - System: Definierar roll som sommelierexpert
  - User: Detaljerad förfrågan med JSON-struktur
- **Output-format**: Strukturerad JSON array

### Systembolaget (Planerad)
- **Status**: Grundläggande mock-implementation
- **Framtida**: 
  - Officiell API-integration
  - Live produktdata
  - Lagerstatus
  - Riktiga produktbilder

## 🎨 Styling-arkitektur

### Tailwind CSS
- **Utility-first**: Direkta CSS-klasser
- **Custom colors**: Wine-palett (50-900)
- **Responsive**: Mobile-first design
- **Dark mode**: Färdigförberett

### Färgschema
```css
Primary: Wine/Purple gradient
- Background: purple-900 → wine-800 → red-900
- Accent: wine-600, wine-700
- Text: white, purple-200

Secondary: 
- Success: green-100, green-800
- Warning: yellow-100, yellow-800
- Error: red-50, red-700
```

## 🔒 Säkerhet

### API-nycklar
- Lagras i `.env.local` (ej versionshanterat)
- Endast tillgängliga på servern
- Aldrig exponerade till klienten

### Input-validering
- Query-längd valideras
- Sanitering av användarinput
- Error handling för API-fel

### Rate Limiting (Framtida)
- OpenAI har egna rate limits
- Planerad: Client-side debouncing
- Planerad: Server-side caching

## 📊 State Management

### Client State (React Hooks)
- `useState`: Lokal komponent-state
- `useEffect`: Side-effects och API-anrop
- Props drilling: För parent-child kommunikation

### Server State
- Stateless API routes
- Ingen session management (ännu)

## 🚀 Deployment-arkitektur

### Vercel (Rekommenderat)
```
Git Push → Vercel
    ↓
Build Process
    ↓
Optimering (Next.js)
    ↓
Edge Network Deploy
    ↓
Global CDN
```

### Alternativ: Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN npm install && npm run build
CMD ["npm", "start"]
```

## 📈 Skalbarhet

### Nuvarande
- Stateless API routes → Horisontell skalning
- No database → Ingen bottleneck
- CDN för statiska filer

### Framtida förbättringar
1. **Caching**
   - Redis för API-svar
   - Client-side cache med SWR

2. **Database**
   - PostgreSQL för användare
   - MongoDB för vinfavoriter

3. **Load Balancing**
   - Vercel auto-scaling
   - Eller Kubernetes cluster

## 🧪 Testnings-strategi

### Enhetstester (Planerat)
- Jest för utility-funktioner
- React Testing Library för komponenter

### Integration-tester (Planerat)
- API route-tester
- OpenAI mock-svar

### E2E-tester (Planerat)
- Playwright för user flows
- Cypress för interaktiva tester

## 📝 Best Practices

### Code
- TypeScript för typ-säkerhet
- ESLint för kod-kvalitet
- Prettier för formatering

### Git
- Feature branches
- Descriptive commits
- Pull request reviews

### Performance
- Next.js Image optimization
- Code splitting
- Lazy loading

---

**Arkitektur-version**: 1.0  
**Senast uppdaterad**: Oktober 2025

