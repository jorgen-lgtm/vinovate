# Vinovate - AI Wine Recommendation App

En intelligent vinrekommendationsapp byggd med Next.js 14 och OpenAI GPT-4o.

## 🍷 Funktioner

- **AI-driven vinsökning** med OpenAI GPT-4o
- **Prisfilter** - sök viner inom ditt budget
- **Matrekommendationer** för varje vin
- **Köpställen** - Systembolaget, Vinoteket, Winefinder, m.fl.
- **Responsiv design** med Tailwind CSS
- **TypeScript** för typsäkerhet

## 🚀 Snabbstart

1. **Installera dependencies:**
   ```bash
   npm install
   ```

2. **Konfigurera miljövariabler:**
   ```bash
   cp .env.example .env.local
   ```
   
   Lägg till din OpenAI API-nyckel i `.env.local`:
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   ```

3. **Starta utvecklingsservern:**
   ```bash
   npm run dev
   ```

4. **Öppna i webbläsaren:**
   ```
   http://localhost:3000
   ```

## 🛠️ Teknisk stack

- **Next.js 14** (App Router)
- **TypeScript**
- **Tailwind CSS**
- **OpenAI API** (GPT-4o)
- **Lucide React** (ikoner)

## 📁 Projektstruktur

```
app/
  api/          # API routes
  page.tsx      # Huvudsida
  layout.tsx    # Layout
components/     # React komponenter
lib/           # Hjälpfunktioner
types/         # TypeScript interfaces
public/        # Statiska filer
```

## 🔧 API Endpoints

- `POST /api/ai-wine-search` - AI-vinsökning
- `POST /api/quick-search` - Snabb sökning
- `GET /api/health` - Hälsokontroll

## 🎯 Användning

1. **Sök viner** med naturligt språk
2. **Filtrera på pris** (t.ex. "Barolo 450kr")
3. **Klicka på vin** för detaljer
4. **Hitta köpställen** och matrekommendationer

## 🚀 Deployment

### Vercel (Rekommenderat)
```bash
npx vercel --prod
```

### Andra plattformar
```bash
npm run build
npm start
```

## 📝 Miljövariabler

| Variabel | Beskrivning | Krävs |
|----------|-------------|-------|
| `OPENAI_API_KEY` | OpenAI API-nyckel | Ja |

## 🤝 Bidrag

1. Forka projektet
2. Skapa en feature branch
3. Commita ändringar
4. Pusha till branch
5. Skapa Pull Request

## 📄 Licens

MIT License - se LICENSE-filen för detaljer.

## 🆘 Support

För frågor och support, skapa en issue på GitHub.

---

**Utvecklat med ❤️ för vinälskare**