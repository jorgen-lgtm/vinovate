# 🎨 WineAI - Visuell guide

## 📱 Användarupplevelse

### 1. Startsida
```
┌─────────────────────────────────────────────┐
│         🍷 WineAI                           │
│  Din intelligenta vinrådgivare              │
│                                             │
│  ┌───────────────────────────────────────┐ │
│  │ ✨ Prova dessa exempel:               │ │
│  │  [Rött vin till pasta carbonara]      │ │
│  │  [Champagne till fest under 400 kr]   │ │
│  │  [Italienskt vitt vin]                │ │
│  └───────────────────────────────────────┘ │
│                                             │
│  ┌───────────────────────────────────────┐ │
│  │ Vad letar du efter?                   │ │
│  │ ┌─────────────────────────────────┐   │ │
│  │ │ 🔍 T.ex. 'rött vin till pasta'  │   │ │
│  │ └─────────────────────────────────┘   │ │
│  │                                       │ │
│  │ Prioritering:                         │ │
│  │ ┌──────────────┐  ┌─────────────────┐│ │
│  │ │⏱️ Snabb      │  │⭐ Bästa betyg   ││ │
│  │ │ tillgänglighet│  │                 ││ │
│  │ └──────────────┘  └─────────────────┘│ │
│  │                                       │ │
│  │        [🔍 Sök vin]                   │ │
│  └───────────────────────────────────────┘ │
│                                             │
│  Skapad med ❤️ för vinälskare              │
└─────────────────────────────────────────────┘
```

### 2. Sökresultat
```
┌─────────────────────────────────────────────┐
│  ┌───────────────────────────────────────┐ │
│  │ Barolo DOCG 2018                      │ │
│  │ Marchesi di Barolo • Italien • 2018   │ │
│  │                                       │ │
│  │ En kraftfull och komplex Barolo...    │ │
│  │                                       │ │
│  │ [Rött vin] [⭐ 92/100] [289 kr]       │ │
│  │                                       │ │
│  │ Passar till:                          │ │
│  │ Pasta carbonara, Grillat kött, Ost    │ │
│  │                                       │ │
│  │     [Visa mer information]            │ │
│  └───────────────────────────────────────┘ │
│                                             │
│  [... fler viner ...]                       │
└─────────────────────────────────────────────┘
```

### 3. Vin-modal (Popup)
```
┌──────────────────────────────────────────────────────┐
│  Barolo DOCG 2018                            [✕]     │
├──────────────────────────────────────────────────────┤
│                                                      │
│  ┌───────────┐  Om vinet                            │
│  │           │  Producent: Marchesi di Barolo       │
│  │   🍷      │  Typ: Rött vin                       │
│  │   BILD    │  Land: Italien                       │
│  │           │  Region: Piemonte                    │
│  │           │  Årgång: 2018                        │
│  └───────────┘                                       │
│                 289 kr                               │
│      ⭐ 92/100                                       │
│                                                      │
│                 Beskrivning                          │
│                 En kraftfull och komplex Barolo...   │
│                                                      │
│                 Senaste provning                     │
│                 Robust tannin, körsbär, lakrits...   │
│                                                      │
│                 Passar till                          │
│                 [Pasta carbonara] [Grillat kött]     │
│                                                      │
│                 🛒 Var kan jag köpa?                 │
│                 📍 Systembolaget                     │
│                    Butik • Finns i de flesta butiker │
│                    → Besök webbplats                 │
│                                                      │
│                 📍 Systembolaget Online              │
│                    Online • Beställ online           │
│                    → Besök webbplats                 │
└──────────────────────────────────────────────────────┘
```

## 🎨 Färgschema

### Gradient bakgrund
```
┌─────────────────────────────────────┐
│  🟣 Purple-900 (Top)                │
│     ↓                               │
│  🍷 Wine-800 (Middle)               │
│     ↓                               │
│  🔴 Red-900 (Bottom)                │
└─────────────────────────────────────┘
```

### Komponent-färger
- **Primär knapp**: Wine-600 → Wine-700 (hover)
- **Valda alternativ**: Wine-50 bakgrund, Wine-700 text
- **Informations-chips**: 
  - Vintyp: Wine-100/Wine-800
  - Betyg: Yellow-100/Yellow-800
  - Pris: Green-100/Green-800

## 📱 Responsivitet

### Desktop (>768px)
```
┌────────────────────────────────────────────────────────┐
│                    FULL WIDTH                          │
│  ┌──────────────────────────────────────────────────┐ │
│  │              Search Box (max-width: 4xl)         │ │
│  └──────────────────────────────────────────────────┘ │
│                                                        │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐        │
│  │   Vin 1    │ │   Vin 2    │ │   Vin 3    │        │
│  └────────────┘ └────────────┘ └────────────┘        │
└────────────────────────────────────────────────────────┘
```

### Mobile (<768px)
```
┌──────────────────┐
│   FULL WIDTH     │
│  ┌────────────┐  │
│  │ Search Box │  │
│  └────────────┘  │
│                  │
│  ┌────────────┐  │
│  │   Vin 1    │  │
│  └────────────┘  │
│                  │
│  ┌────────────┐  │
│  │   Vin 2    │  │
│  └────────────┘  │
└──────────────────┘
```

## 🔄 Interaktioner

### Hover-effekter
- **Vin-kort**: Shadow-lg → Shadow-xl
- **Knappar**: Färgövergang (transition-colors)
- **Exempel-queries**: Opacity 20% → 30%

### Loading-states
```
Sökning pågår...
┌─────────────────────┐
│  ⟳ Söker...         │
│  (Spinning icon)    │
└─────────────────────┘
```

### Animationer
- Modal: Fade in + Scale up
- Results: Stagger fade in
- Buttons: Hover transition

## 📋 Typografi

### Rubriker
- **H1**: 5xl (48px), bold, white
- **H2**: 2xl (24px), bold, gray-900
- **H3**: lg (18px), semibold, gray-900

### Body text
- **Normal**: base (16px), gray-700
- **Small**: sm (14px), gray-600
- **Label**: sm (14px), medium, gray-700

## 🎯 Call-to-Actions

### Primär CTA
```css
Background: wine-600
Text: white
Hover: wine-700
Padding: 3 (12px) vertical, full width
Border-radius: lg (8px)
Font: semibold
```

### Sekundär CTA
```css
Background: transparent/white-20
Border: 2px solid
Hover: Background opacity change
```

## 📊 Layout-grid

```
Container: max-w-4xl mx-auto (1024px max)
Padding: px-4 (16px horizontal)
Gap between elements: 
  - Small: 2-4 (8-16px)
  - Medium: 6 (24px)
  - Large: 8-12 (32-48px)
```

## 🌟 Special touches

### Gradient text (potentiell)
```css
background: linear-gradient(to right, wine-600, wine-400)
-webkit-background-clip: text
-webkit-text-fill-color: transparent
```

### Glass-morphism cards
```css
background: white/10
backdrop-blur: sm
border: 1px solid white/20
```

### Shadow layers
```css
shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1)
```

## 🖼️ Ikoner (Lucide React)

- 🔍 Search - Sökfunktion
- ⏱️ Clock - Snabb tillgänglighet
- ⭐ Star - Betyg/bästa val
- 🍷 Wine - Placeholder för vin
- 🛒 ShoppingCart - Inköpsställen
- 📍 MapPin - Platser
- ❤️ Heart - Footer favorit
- ✕ X - Stäng modal
- ⟳ Loader2 - Laddning (spinning)
- ✨ Sparkles - Exempel-queries

---

Denna visuella guide hjälper utvecklare och designers att förstå och vidarebygga på WineAI:s användarupplevelse! 🎨🍷

