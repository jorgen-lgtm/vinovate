"use client";

import { Info } from "lucide-react";

interface DebugInfoProps {
  wineCount: number;
  source: "OpenAI" | "Mock" | "Cache";
  cached?: boolean;
  aiGenerated?: boolean;
  endpoint?: string;
}

export default function DebugInfo({ wineCount, source, cached, aiGenerated, endpoint }: DebugInfoProps) {
  // Determine source based on props
  let displaySource = source;
  if (cached) {
    displaySource = "Cache";
  } else if (aiGenerated) {
    displaySource = "OpenAI";
  } else if (aiGenerated === false) {
    displaySource = "Mock";
  }

  return (
    <div className="bg-blue-50 border-l-4 border-blue-400 p-3 mb-4 rounded-r-lg">
      <div className="flex items-start gap-3">
        <Info className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <h3 className="text-sm font-semibold text-blue-900 mb-1">
            🔍 Debug Information
          </h3>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="font-medium text-blue-800">Antal viner:</span>
              <span className="ml-2 text-blue-700 font-mono">{wineCount}</span>
            </div>
            <div>
              <span className="font-medium text-blue-800">Källa:</span>
              <span className={`ml-2 font-mono font-semibold ${
                displaySource === "OpenAI" ? "text-green-700" :
                displaySource === "Cache" ? "text-purple-700" :
                "text-orange-700"
              }`}>
                {displaySource}
              </span>
            </div>
            {endpoint && (
              <div className="col-span-2">
                <span className="font-medium text-blue-800">Endpoint:</span>
                <span className="ml-2 text-blue-600 font-mono text-xs">{endpoint}</span>
              </div>
            )}
          </div>
          <div className="mt-2 pt-2 border-t border-blue-200 text-xs text-blue-600">
            <div className="flex gap-4">
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                <span>OpenAI = AI-genererat</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 bg-purple-600 rounded-full"></span>
                <span>Cache = Cachad sökning</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 bg-orange-600 rounded-full"></span>
                <span>Mock = Fallback-data</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


