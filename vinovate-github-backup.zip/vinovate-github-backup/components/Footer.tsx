"use client";

import { Heart, Github } from "lucide-react";

export default function Footer() {
  return (
    <footer className="mt-16 pb-8">
      <div className="max-w-4xl mx-auto text-center">
        <div className="flex items-center justify-center gap-2 text-white/80 text-sm">
          <span>Skapad med</span>
          <Heart className="h-4 w-4 text-red-400 fill-current" />
          <span>för vinälskare</span>
        </div>
        <div className="mt-4 flex items-center justify-center gap-6 text-white/60 text-sm">
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-white transition-colors flex items-center gap-2"
          >
            <Github className="h-4 w-4" />
            <span>GitHub</span>
          </a>
          <span>•</span>
          <a
            href="https://platform.openai.com"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-white transition-colors"
          >
            Powered by OpenAI
          </a>
          {/* Systembolaget link removed per request */}
        </div>
        <div className="mt-4 text-white/40 text-xs">
          <p>© 2025 Jörgen Andersson • Drick ansvarsfullt 🍷</p>
          <div className="mt-2 flex items-center justify-center gap-2">
            <span className="bg-wine-800/50 px-2 py-1 rounded text-xs font-mono">
              v2.2.2 - Stable
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

