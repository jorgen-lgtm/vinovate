"use client";

import { Zap } from "lucide-react";

interface CacheIndicatorProps {
  cached?: boolean;
  hitCount?: number;
}

export default function CacheIndicator({ cached, hitCount }: CacheIndicatorProps) {
  if (!cached) return null;

  return (
    <div className="flex items-center gap-2 px-3 py-1 bg-green-50 border border-green-200 rounded-full text-xs text-green-700">
      <Zap className="h-3 w-3 fill-current" />
      <span>
        Snabbsvar från cache {hitCount && hitCount > 1 ? `(${hitCount} ggr tidigare)` : ''}
      </span>
    </div>
  );
}

