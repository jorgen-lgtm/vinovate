"use client";

import { Wine } from "@/types/wine";
import { Star, ExternalLink, Wine as WineIcon } from "lucide-react";
import Image from "next/image";

interface SponsoredWineCardProps {
  wine: Wine & { isSponsored?: boolean; sponsorName?: string; sponsorWebsite?: string };
  onClick: () => void;
}

export default function SponsoredWineCard({ wine, onClick }: SponsoredWineCardProps) {
  return (
    <div
      onClick={onClick}
      className="bg-gradient-to-br from-amber-50 to-yellow-50 rounded-lg shadow-lg hover:shadow-xl transition-shadow cursor-pointer overflow-hidden border-2 border-amber-300"
    >
      {/* Sponsored badge */}
      <div className="bg-gradient-to-r from-amber-400 to-yellow-400 px-4 py-2 flex items-center justify-between">
        <span className="text-xs font-bold text-amber-900 uppercase tracking-wide flex items-center gap-1">
          ⭐ Sponsrad av {wine.sponsorName}
        </span>
        {wine.sponsorWebsite && (
          <a
            href={wine.sponsorWebsite}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="text-xs text-amber-900 hover:text-amber-950 flex items-center gap-1"
          >
            <ExternalLink className="h-3 w-3" />
            Besök
          </a>
        )}
      </div>
      
      <div className="flex">
        {/* Wine Image */}
        <div className="relative w-32 h-32 flex-shrink-0 bg-gradient-to-br from-wine-50 to-purple-100">
          {wine.imageUrl ? (
            <Image
              src={wine.imageUrl}
              alt={wine.name}
              fill
              sizes="128px"
              className="object-contain p-2"
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full">
              <WineIcon className="h-12 w-12 text-wine-300 mb-2" />
              <p className="text-xs text-gray-400 text-center px-1">Ingen bild</p>
            </div>
          )}
        </div>
        
        {/* Wine Details */}
        <div className="flex-1 p-6">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h3 className="text-xl font-bold text-gray-900 mb-1">
                {wine.name}
              </h3>
              <p className="text-gray-600 mb-2">
                {wine.producer} • {wine.country} {wine.year ? `• ${wine.year}` : ''}
              </p>
              <p className="text-gray-700 mb-3 line-clamp-2">{wine.description}</p>
              
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="px-3 py-1 bg-wine-100 text-wine-800 rounded-full text-sm">
                  {wine.type}
                </span>
                {wine.rating && (
                  <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm flex items-center gap-1">
                    <Star className="h-3 w-3 fill-current" />
                    {wine.rating}/100
                  </span>
                )}
                {wine.price && (
                  <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                    {wine.price} kr
                  </span>
                )}
              </div>

              <div className="mb-2">
                <p className="text-sm font-semibold text-gray-700 mb-1">
                  Passar till:
                </p>
                <p className="text-sm text-gray-600">
                  {(wine.foodPairing || []).join(", ")}
                </p>
              </div>
            </div>
          </div>
          
          <button className="mt-4 w-full bg-wine-600 text-white py-2 rounded-lg font-medium hover:bg-wine-700 transition-colors">
            Visa mer information
          </button>
        </div>
      </div>
    </div>
  );
}

