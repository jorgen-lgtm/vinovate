"use client";

import { useState, useEffect } from "react";
import { ChevronDown, SlidersHorizontal, X } from "lucide-react";
import { 
  getRegionsForCountry, 
  getGrapesForCountryAndRegion, 
  getAllGrapes 
} from "@/data/wineData";

interface FilterOptions {
  country?: string;
  region?: string;
  grape?: string;
  priceRange?: string;
  type?: string;
  searchMode?: 'wines' | 'importers' | 'both';
}

interface AdvancedFiltersProps {
  onApplyFilters: (filters: FilterOptions) => void;
  onDirectSearch?: () => void;
}

export default function AdvancedFilters({ onApplyFilters, onDirectSearch }: AdvancedFiltersProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({ searchMode: 'both' });

  // Dynamic lists based on selections
  const [availableRegions, setAvailableRegions] = useState<string[]>([]);
  const [availableGrapes, setAvailableGrapes] = useState<string[]>(getAllGrapes());

  const countries = [
    "Frankrike", "Italien", "Spanien", "Portugal", "Tyskland",
    "USA", "Chile", "Argentina", "Australien", "Nya Zeeland",
    "Sydafrika", "Österrike", "Grekland"
  ];

  // Update available regions when country changes
  useEffect(() => {
    if (filters.country) {
      const regions = getRegionsForCountry(filters.country);
      setAvailableRegions(regions);
      
      // Reset region if it's no longer valid for the new country
      if (filters.region && !regions.includes(filters.region)) {
        setFilters(prev => ({ ...prev, region: undefined }));
      }
    } else {
      setAvailableRegions([]);
    }
  }, [filters.country]);

  // Update available grapes when country or region changes
  useEffect(() => {
    if (filters.country) {
      const grapes = getGrapesForCountryAndRegion(filters.country, filters.region);
      setAvailableGrapes(grapes);
      
      // Reset grape if it's no longer valid
      if (filters.grape && !grapes.includes(filters.grape)) {
        setFilters(prev => ({ ...prev, grape: undefined }));
      }
    } else {
      setAvailableGrapes(getAllGrapes());
    }
  }, [filters.country, filters.region]);

  const priceRanges = [
    "Under 100 kr",
    "100-150 kr",
    "150-200 kr",
    "200-300 kr",
    "300-500 kr",
    "Över 500 kr"
  ];

  const types = [
    "Rött vin",
    "Vitt vin",
    "Rosé",
    "Mousserande",
    "Champagne",
    "Dessertvin",
    "Portvin"
  ];

  const handleApply = () => {
    onApplyFilters(filters);
    setIsOpen(false);
  };
  
  const handleDirectSearch = () => {
    onApplyFilters(filters);
    if (onDirectSearch) {
      onDirectSearch();
    }
    setIsOpen(false);
  };

  const handleClear = () => {
    setFilters({ searchMode: 'both' });
    onApplyFilters({ searchMode: 'both' });
  };

  const hasActiveFilters = Object.entries(filters).some(([key, value]) => {
    // Räkna inte 'both' som ett aktivt filter
    if (key === 'searchMode' && value === 'both') return false;
    return value;
  });

  return (
    <div className="mb-6">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg border-2 transition-all ${
          hasActiveFilters
            ? "border-wine-600 bg-wine-50 text-wine-700"
            : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
        }`}
      >
        <SlidersHorizontal className="h-5 w-5" />
        <span className="font-medium">Avancerade filter</span>
        {hasActiveFilters && (
          <span className="ml-2 px-2 py-0.5 bg-wine-600 text-white rounded-full text-xs">
            Aktiva
          </span>
        )}
        <ChevronDown
          className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`}
        />
      </button>

      {isOpen && (
        <div className="mt-4 p-6 bg-white rounded-lg border border-gray-200 shadow-lg">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Sökläge */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Avgränsa sökning (valfritt)
              </label>
              <select
                value={filters.searchMode || 'both'}
                onChange={(e) => setFilters({ ...filters, searchMode: e.target.value as any })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent text-gray-900"
              >
                <option value="both">- Visa allt -</option>
                <option value="wines">Endast viner (5st med bäst betyg)</option>
                <option value="importers">Endast importörer (5st matchande)</option>
              </select>
              <p className="text-xs text-gray-500 mt-1">
                {filters.searchMode === 'wines' && '📋 Sökningen visar endast viner'}
                {filters.searchMode === 'importers' && '🏢 Sökningen visar endast importörer'}
                {(!filters.searchMode || filters.searchMode === 'both') && '🎯 Fullständiga resultat'}
              </p>
            </div>

            {/* Vintyp */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Vintyp
              </label>
              <select
                value={filters.type || ""}
                onChange={(e) => setFilters({ ...filters, type: e.target.value || undefined })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent text-gray-900"
              >
                <option value="">Alla typer</option>
                {types.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>

            {/* Land */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Land
              </label>
              <select
                value={filters.country || ""}
                onChange={(e) => setFilters({ ...filters, country: e.target.value || undefined })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent text-gray-900"
              >
                <option value="">Alla länder</option>
                {countries.map((country) => (
                  <option key={country} value={country}>
                    {country}
                  </option>
                ))}
              </select>
            </div>

            {/* Region */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Region {filters.country && `(i ${filters.country})`}
              </label>
              <select
                value={filters.region || ""}
                onChange={(e) => setFilters({ ...filters, region: e.target.value || undefined })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent text-gray-900"
                disabled={!filters.country}
              >
                <option value="">
                  {filters.country ? "Alla regioner" : "Välj land först"}
                </option>
                {availableRegions.map((region) => (
                  <option key={region} value={region}>
                    {region}
                  </option>
                ))}
              </select>
              {!filters.country && (
                <p className="text-xs text-gray-500 mt-1">💡 Välj ett land för att se regioner</p>
              )}
            </div>

            {/* Druva */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Druva {filters.region && `(i ${filters.region})`}
              </label>
              <select
                value={filters.grape || ""}
                onChange={(e) => setFilters({ ...filters, grape: e.target.value || undefined })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent text-gray-900"
              >
                <option value="">Alla druvor</option>
                {availableGrapes.map((grape) => (
                  <option key={grape} value={grape}>
                    {grape}
                  </option>
                ))}
              </select>
              {filters.country && availableGrapes.length < getAllGrapes().length && (
                <p className="text-xs text-gray-500 mt-1">
                  ✓ Filtrerad baserat på {filters.region || filters.country}
                </p>
              )}
            </div>

            {/* Prisklass */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Prisklass
              </label>
              <select
                value={filters.priceRange || ""}
                onChange={(e) => setFilters({ ...filters, priceRange: e.target.value || undefined })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent text-gray-900"
              >
                <option value="">Alla prisklasser</option>
                {priceRanges.map((range) => (
                  <option key={range} value={range}>
                    {range}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Aktiva filter */}
          {hasActiveFilters && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <p className="text-sm font-medium text-gray-700 mb-2">Aktiva filter:</p>
              <div className="flex flex-wrap gap-2">
                {Object.entries(filters).map(([key, value]) => {
                  // Visa inte searchMode om den är 'both' (standard)
                  if (!value || (key === 'searchMode' && value === 'both')) return null;
                  
                  // Formatera displaynamn för searchMode
                  let displayValue = value;
                  if (key === 'searchMode') {
                    if (value === 'wines') displayValue = 'Endast viner';
                    else if (value === 'importers') displayValue = 'Endast importörer';
                  }
                  
                  return (
                    <span
                      key={key}
                      className="inline-flex items-center gap-1 px-3 py-1 bg-wine-100 text-wine-800 rounded-full text-sm"
                    >
                      {displayValue}
                      <button
                        onClick={() => setFilters({ ...filters, [key]: key === 'searchMode' ? 'both' : undefined })}
                        className="hover:text-wine-900"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  );
                })}
              </div>
            </div>
          )}

          <div className="mt-6 flex gap-3">
            <button
              onClick={handleDirectSearch}
              className="flex-1 bg-wine-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-wine-700 transition-colors"
            >
              🔍 Sök direkt med filter
            </button>
            <button
              onClick={handleApply}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors"
            >
              Tillämpa
            </button>
            <button
              onClick={handleClear}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
            >
              Rensa
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

