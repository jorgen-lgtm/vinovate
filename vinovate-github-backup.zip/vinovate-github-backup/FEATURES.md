# 🍷 WineAI - Funktionsöversikt

## ✨ Huvudfunktioner

### 1. **Intelligent Vinsökning med AI**
- **5 viner** per sökning, sorterade efter betyg (högsta först)
- OpenAI GPT-4o för intelligenta rekommendationer
- Naturligt språk i sökningar
- Två söklägen:
  - **Allmän sökning** - för vanliga vinbehov
  - **Importörs portfölj** - visa hela sortiment

### 2. **Avancerade Filter** 🎯
Snabbfiltrering innan sökning med dropdown-menyer för:
- **Vintyp**: Rött, Vitt, Rosé, Mousserande, etc.
- **Land**: 13 länder (Frankrike, Italien, Spanien, etc.)
- **Region**: 14 regioner (Bordeaux, Toscana, Rioja, etc.)
- **Druva**: 12 druvor (Cabernet Sauvignon, Pinot Noir, etc.)
- **Prisklass**: 6 prisklasser (Under 100 kr till Över 500 kr)

### 3. **Rustika Matrecept** 👨‍🍳
Kompletta, klassiska recept som passar till varje vin:
- **4+ rustika rätter** per vin
- Fullständiga recept med:
  - 📋 Ingredienser (4 portioner)
  - 👨‍🍳 Steg-för-steg instruktioner
  - ⏱️ Tillagn ingstid
  - 💡 Pro-tips
- **Expanderbara kort** - klicka för att visa/dölja recept
- **Smakprofilsförklaring** - varför vinet passar

### 4. **Matpairing-Förslag** 🍽️
När du väljer ett vin:
- Prominent visning av rustika maträtter
- Detaljerade förklaringar varför de passar
- Serverings-tips
- Klassiska, fylliga rätter (grytor, långkok, stekt kött, rotfrukter)

### 5. **Importörs-Portfölj i Tabell** 📊
- Sök på importör (t.ex. "Importör: Philipson Söderberg")
- Visa alla viner i sorterbar tabell
- Klicka på kolumner för att sortera
- Expandera rader för följdfrågor:
  - 🍽️ Vad ska man äta till?
  - ⏰ När ska man dricka?
  - 🛒 Var kan man köpa?

### 6. **Prisjämförelse** 💰
- Visa både importörens pris OCH Systembolagets pris
- Automatisk beräkning av besparingen
- Grön markering när importören är billigare
- "Spara X kr!" meddelande

### 7. **Vin-Information** 📝
För varje vin:
- **Grundinfo**: Producent, land, region, årgång
- **Betyg**: 1-100 skala
- **Pris**: Från både importör och Systembolaget
- **Beskrivning**: Professionell vinbeskrivning
- **Provningsanteckningar**: Senaste tillgängliga provning
- **Serveringstemperatur**: Optimal temperatur
- **Bästa drickperiod**: När vinet är som bäst

### 8. **Inköpsställen** 🛒
- Lista med var du kan köpa vinet
- Systembolaget (butik + online)
- Importörer med direktförsäljning
- Lagerstatus
- Direktlänkar till webbplatser

### 9. **Interaktiv UI** 🎨
- **Modal för vin-detaljer**: Popup med fullständig information
- **Stäng på 3 sätt**:
  - X-knapp
  - Klicka utanför
  - ESC-tangent
- **Gradient bakgrunder**: Wine-temad design
- **Smooth animationer**: Fade-in, scale, hover-effekter
- **Responsiv**: Fungerar på alla enheter

### 10. **Exempel-Queries** ✨
Fördefinierade exempel för snabb start:
- "Rött vin till pasta carbonara"
- "Vad kan man äta till Barolo?"
- "Champagne till fest under 400 kr"
- "Vin till grillat kött med matförslag"
- "Importör: Philipson Söderberg"

## 🎯 Användningsexempel

### Scenario 1: Söka rustik mat till vin
```
1. Sök: "Vad kan man äta till Barolo?"
2. Få 5 viner sorterade efter betyg
3. Klicka på ett vin
4. Se rustika matförslag i modal
5. Stäng modal
6. Scrolla ner för fullständiga recept
7. Klicka på recept-kort för att expandera
8. Få komplett recept med ingredienser och steg
```

### Scenario 2: Filtrera och söka
```
1. Klicka "Avancerade filter"
2. Välj:
   - Vintyp: Rött vin
   - Land: Italien
   - Region: Toscana
   - Prisklass: 200-300 kr
3. Klicka "Tillämpa filter"
4. Sök: "vin till pasta"
5. Få 5 italienska Toscana-viner (200-300 kr)
6. Med rustika pastarecept
```

### Scenario 3: Importörs-portfölj
```
1. Välj "Importörs portfölj"
2. Sök: "Importör: Philipson Söderberg"
3. Få tabell med alla viner
4. Sortera på betyg (klicka kolumn)
5. Klicka på rad för att expandera
6. Se matpairing, när dricka, var köpa
7. Jämför priser (importör vs Systembolaget)
```

## 📊 Statistik

- **Antal viner per sökning**: 5
- **Rustika recept per vin**: 4-5
- **Filter-alternativ**: 50+
- **Matpairing-detaljer**: Ja
- **Prisjämförelse**: Ja
- **Receptinstruktioner**: Fullständiga
- **Responsiv design**: Ja
- **Animationer**: Ja

## 🔮 Kommande Funktioner

Planerade förbättringar:
- [ ] Riktiga bilder från Systembolaget API
- [ ] Spara favorit-viner
- [ ] Dela recept med vänner
- [ ] Skapa egen vinkällare
- [ ] Vinkartan med regioner
- [ ] Mer avancerade filter (eklagring, druv-blandningar)
- [ ] Mobil-app

## 💡 Tips för Bästa Upplevelse

1. **Använd filter** - Smal in sökningen innan du börjar
2. **Klicka på recept** - Expandera för fullständiga instruktioner
3. **Jämför priser** - Se var det är billigast att köpa
4. **Läs "varför"** - Förstå varför mat och vin passar ihop
5. **Testa importörs-sök** - Upptäck hela sortiment

---

**Uppdaterad**: Oktober 2025  
**Version**: 2.0  
**Status**: ✅ Alla funktioner implementerade

