import { NextRequest, NextResponse } from "next/server";
import { openai } from "@/lib/openai";

export async function GET() {
  try {
    console.log("🧪 Testing OpenAI API...");
    console.log("🔑 API key exists:", !!process.env.OPENAI_API_KEY);
    console.log("🔑 API key starts with:", process.env.OPENAI_API_KEY ? process.env.OPENAI_API_KEY.substring(0, 10) + "..." : "NOT SET");

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: "Say hello" }],
      max_tokens: 10
    });

    const response = completion.choices[0].message.content;
    console.log("✅ OpenAI response:", response);

    return NextResponse.json({
      success: true,
      response: response,
      model: "gpt-4o-mini"
    });
  } catch (error) {
    console.error("❌ OpenAI test failed:", error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
