import { NextRequest, NextResponse } from "next/server";
import { openai } from "@/lib/openai";
import { 
  getCachedResult, 
  cacheSearchResult, 
  recordCacheHit, 
  recordCacheMiss 
} from "@/lib/searchCache";

// Initialize OpenAI only if API key is available
// OpenAI client is now imported from lib/openai.ts

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json();

    if (!query) {
      return NextResponse.json(
        { error: "Query is required" },
        { status: 400 }
      );
    }

    // Check cache first
    const cached = getCachedResult(query, {}, 'find-importers');
    if (cached && cached.results.importers) {
      recordCacheHit();
      return NextResponse.json({ 
        importers: cached.results.importers,
        cached: true,
        hitCount: cached.hitCount
      });
    }
    
    recordCacheMiss();

    const prompt = `Du är en expert på svenska vinimportörer och vinmarknaden. Baserat på följande sökkriterier, ge mig EXAKT 5 svenska vinimportörer som bäst matchar.

Sökkriterier: "${query}"

${query.includes('specifika viner') ? `
KRITISKT VIKTIGT: Användaren söker importörer som har SPECIFIKA VINER som nämns i sökningen.
Prioritera importörer som faktiskt har dessa viner i sitt sortiment eller liknande viner från samma producent/region.
Om viner nämns med producent och pris, leta efter importörer som specialiserar sig på dessa märken/regioner.
` : ""}

${query.toLowerCase().includes('champagne') || query.toLowerCase().includes('champange') || query.toLowerCase().includes('mousserande') ? `
KRITISKT VIKTIGT: Användaren söker efter importörer som specialiserar sig på CHAMPAGNE/MOUSSERANDE viner. 
GE ENDAST importörer som är KÄNDA för champagne och mousserande viner:
- Champagne från Champagne-regionen
- Mousserande viner (Prosecco, Cava, Crémant)
- Sparkling wines från olika regioner
- Importörer som har champagne som en HUVUDKATEGORI (inte bara några få flaskor)
` : ""}

För varje importör, ge följande information i JSON-format:

{
  "importers": [
    {
      "name": "Importörens namn",
      "description": "Kort beskrivning (2-3 meningar) om importörens profil och specialitet",
      "specialties": ["Specialitet 1", "Specialitet 2", "Specialitet 3"],
      "focusRegions": ["Region 1", "Region 2", "Region 3"],
      "priceRange": "Budget/Medium/Premium/Luxury",
      "portfolioSize": "Cirka antal viner i sortiment (t.ex. '300+ viner')",
      "strengths": ["Styrka 1", "Styrka 2", "Styrka 3"],
      "bestFor": "Vad de är bäst för (t.ex. 'Bordeaux-älskare', 'Budgetmedvetna', 'Premium italienska viner')",
      "contact": {
        "website": "webbadress (om känd)",
        "phone": "telefonnummer (om känt)",
        "email": "e-postadress (om känd)"
      },
      "topWines": [
        {
          "name": "Ett känt vin från deras sortiment",
          "producer": "Producent",
          "price": "Ca-pris i SEK"
        }
      ]
    }
  ]
}

VIKTIGT:
1. Ge EXAKT 5 VERKLIGA svenska vinimportörer (INTE FLER, INTE FÄRRE)
2. Matcha importörer baserat på kriterierna (land, prisklass, typ av vin, etc.)
3. Sortera efter hur väl de matchar kriterierna (bästa matchen först)
4. Ge realistisk information om varje importör
5. Om kriterier inkluderar specifika regioner/länder, prioritera importörer som är starka där

Exempel på kända svenska vinimportörer:
- Philipson Söderberg (Premium, Frankrike, Italien)
- Wineworld (Bred portfolio, alla prisklasser)
- Kobrand Sweden (Exklusivt, champagne, toppviner, Moët & Chandon)
- Domaine Select (Boutique-producenter, kvalitet, champagne)
- Vinguiden (Italien, Frankrike, medelpris)
- Bibendum Wine (Storbritannien, klassiska viner)
- Terroir Wines (Naturviner, biodynamiskt)
- Nordic Wine Group (Skandinavisk profil)
- Champagnehuset (Specialiserad på champagne)
- Laurent-Perrier Sverige (Champagne specialist)
- Mentzendorff (Bollinger, champagne)
- Pernod Ricard (Stora märken, champagne)
- Arvid Nordquist (Brett sortiment inkl. mousserande)

KRITISKA REGLER:
1. GE EXAKT 5 importörer (kontrollräkna innan du svarar)
2. Matcha importörer EXAKT till kriterierna
3. Om "italienska viner" - ge importörer som FRÄMST fokuserar på Italien
4. Om "champagne/mousserande" - ge ENDAST importörer SPECIALISERADE på champagne/mousserande
5. Om "budget" - ge importörer kända för bra pris/kvalitet-förhållande
6. Om "premium" - ge exklusiva importörer
7. Ge VERKLIGA svenska importörer med korrekt information

VIKTIGT OM JSON-FORMAT:
- Svara ENDAST med giltig JSON
- Ingen annan text före eller efter JSON
- Inga markdown-kodblock
- Börja direkt med { och sluta med }
- Dubbla citattecken runt ALLA nycklar och strängar
- Inga trailing commas
- Inga null-nycklar
- KONTROLLERA att du har EXAKT 5 importörer i din lista

Om du inte kan skapa giltig JSON, svara med: {"importers": []}`;

    // Check if OpenAI is available
    if (!openai) {
      return NextResponse.json({
        importers: [],
        cached: false,
        message: "OpenAI API key not configured. Please add OPENAI_API_KEY to your environment variables."
      }, { status: 500 });
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Du är en expert på svenska vinimportörer och vinmarknaden. Svara alltid med välformaterad JSON. Matcha importörer EXAKT till kriterierna. KRITISKT: Svara ENDAST med giltig JSON. Inga markdown-kodblock. Inga förklaringar. Börja direkt med { och sluta med }. Dubbla citattecken runt alla nycklar och strängar. Inga trailing commas.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.7, // Increased for more variation
      max_tokens: 2500,
      top_p: 0.9,
      frequency_penalty: 0.5,
      presence_penalty: 0.3,
    });

    const responseText = completion.choices[0].message.content;
    
    if (!responseText) {
      throw new Error("No response from OpenAI");
    }

    let result;
    try {
      // Check if response is too short (likely empty result)
      if (responseText.length < 50) {
        console.log("⚠️ Response too short, likely empty result");
        throw new Error("Response too short");
      }
      
      // More aggressive JSON cleaning
      let cleanedResponse = responseText
        .replace(/```json\n?/g, "")
        .replace(/```\n?/g, "")
        .replace(/^[^{]*/, "") // Remove everything before first {
        .replace(/[^}]*$/, "") // Remove everything after last }
        .trim();
      
      // Try to find and extract just the JSON part
      const jsonMatch = cleanedResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        cleanedResponse = jsonMatch[0];
      }
      
      // Fix common JSON syntax errors - MORE AGGRESSIVE
      cleanedResponse = cleanedResponse
        .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
        .replace(/\\"/g, '"') // Fix escaped quotes that shouldn't be escaped
        .replace(/\\"\\"/g, '""') // Fix double escaped quotes
        .replace(/""""/g, '"') // Fix quadruple quotes
        .replace(/"""/g, '"') // Fix triple quotes
        .replace(/""/g, '"') // Fix double quotes
        .replace(/null:/g, '"null":') // Fix null keys
        .replace(/undefined:/g, '"undefined":') // Fix undefined keys
        .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas again
        .replace(/\n/g, ' ') // Remove newlines
        .replace(/\s+/g, ' '); // Normalize whitespace
      
      result = JSON.parse(cleanedResponse);
      
      // Validate that we have importers array
      if (!result.importers || !Array.isArray(result.importers)) {
        throw new Error("Invalid response format: missing importers array");
      }
      
      console.log(`✅ Successfully parsed ${result.importers.length} importers from AI`);
    } catch (parseError) {
      console.error("Failed to parse OpenAI response:", responseText);
      console.error("Parse error:", parseError);
      throw new Error("Failed to parse importer recommendations");
    }

    // Cache the result
    cacheSearchResult(query, { importers: result.importers }, {}, 'find-importers');

    return NextResponse.json({
      ...result,
      cached: false
    });
  } catch (error) {
    console.error("Error in find importers:", error);
    
    // Return mock importers as fallback
    const fallbackImporters = [
      {
        name: "Kobrand Sweden",
        description: "Exklusiv importör av premiummousserande viner med fokus på champagne. Representerar några av världens mest prestigefyllda champagnehus.",
        specialties: ["Champagne", "Premium mousserande", "Exklusiva producenter"],
        focusRegions: ["Champagne", "Frankrike"],
        priceRange: "Premium",
        portfolioSize: "150+ champagner",
        strengths: ["Champagne-expertis", "Exklusivitet", "Toppkvalitet"],
        bestFor: "Champagne-entusiaster och lyxsegmentet",
        contact: {
          website: "https://www.kobrandwine.com",
          phone: "08-545 123 45",
          email: "info@kobrand.se"
        },
        topWines: [
          {
            name: "Moët & Chandon Impérial",
            producer: "Moët & Chandon",
            price: "449 kr"
          }
        ]
      },
      {
        name: "Champagnehuset",
        description: "Specialiserad champagneimportör med ett noggrant kurerat urval från både stora hus och mindre producenter. Expertis inom hela champagne-spektrumet.",
        specialties: ["Champagne", "Grower champagne", "Vintage champagne"],
        focusRegions: ["Champagne"],
        priceRange: "Medium-Luxury",
        portfolioSize: "200+ champagner",
        strengths: ["Specialisering", "Kunskapsdjup", "Personlig service"],
        bestFor: "Champagnekännare som söker både klassiker och rariteter",
        contact: {
          website: "https://www.champagnehuset.se",
          phone: "08-XXX XX XX",
          email: "info@champagnehuset.se"
        },
        topWines: [
          {
            name: "Pol Roger Brut Réserve",
            producer: "Pol Roger",
            price: "529 kr"
          }
        ]
      },
      {
        name: "Domaine Select",
        description: "Boutique-importör med fokus på kvalitet och hållbarhet. Starkt sortiment av champagne och mousserande viner från mindre, ofta familjeägda producenter.",
        specialties: ["Boutique champagne", "Biodynamiska mousserande", "Grower champagne"],
        focusRegions: ["Champagne", "Loire", "Alsace"],
        priceRange: "Premium",
        portfolioSize: "100+ mousserande",
        strengths: ["Hållbarhet", "Unika producenter", "Kvalitetsfokus"],
        bestFor: "Konsumenter som söker autentiska, mindre kända champagner",
        contact: {
          website: "https://www.domaineselect.se",
          phone: "08-XXX XX XX",
          email: "info@domaineselect.se"
        },
        topWines: [
          {
            name: "Drappier Carte d'Or",
            producer: "Drappier",
            price: "379 kr"
          }
        ]
      },
      {
        name: "Laurent-Perrier Sverige",
        description: "Officiell svensk representant för det prestigefyllda champagnehuset Laurent-Perrier. Erbjuder hela deras sortiment från klassiska cuvéer till vintage och rosé.",
        specialties: ["Laurent-Perrier champagne", "Prestige champagne", "Rosé champagne"],
        focusRegions: ["Champagne"],
        priceRange: "Premium-Luxury",
        portfolioSize: "25+ champagner",
        strengths: ["Hus-expertis", "Komplett sortiment", "Kvalitetsgaranti"],
        bestFor: "Laurent-Perrier-älskare och champagne-entusiaster",
        contact: {
          website: "https://www.laurent-perrier.com",
          phone: "08-XXX XX XX",
          email: "sverige@laurent-perrier.com"
        },
        topWines: [
          {
            name: "Laurent-Perrier La Cuvée",
            producer: "Laurent-Perrier",
            price: "449 kr"
          }
        ]
      },
      {
        name: "Wineworld",
        description: "Bred portfolio med mousserande viner från hela världen. Erbjuder allt från prisvärd Prosecco till exklusiv champagne, med fokus på tillgänglighet och variation.",
        specialties: ["Champagne", "Prosecco", "Cava", "Crémant"],
        focusRegions: ["Frankrike", "Italien", "Spanien"],
        priceRange: "Budget-Premium",
        portfolioSize: "300+ mousserande viner",
        strengths: ["Bredd", "Tillgänglighet", "Prisvärt"],
        bestFor: "Bred målgrupp som söker mousserande i alla prisklasser",
        contact: {
          website: "https://www.wineworld.se",
          phone: "08-XXX XX XX",
          email: "info@wineworld.se"
        },
        topWines: [
          {
            name: "Veuve Clicquot Yellow Label",
            producer: "Veuve Clicquot",
            price: "499 kr"
          }
        ]
      }
    ];
    
    return NextResponse.json({
      importers: fallbackImporters,
      cached: false,
      message: "Sökning misslyckades, visar grundläggande resultat"
    });
  }
}

