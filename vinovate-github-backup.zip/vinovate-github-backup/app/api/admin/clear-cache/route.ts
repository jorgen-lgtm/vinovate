import { NextRequest, NextResponse } from "next/server";
import { clearCache } from "@/lib/searchCache";
import { checkAdminAuth } from "@/lib/auth";

export async function POST(request: NextRequest) {
  try {
    const { password } = await request.json();

    if (!password || !checkAdminAuth(password)) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    // Clear the cache
    clearCache();

    return NextResponse.json({
      success: true,
      message: "Cache cleared successfully"
    });
  } catch (error) {
    console.error("Error clearing cache:", error);
    return NextResponse.json(
      { error: "Failed to clear cache" },
      { status: 500 }
    );
  }
}

