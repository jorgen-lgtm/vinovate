import { NextRequest, NextResponse } from "next/server";
import { openai } from "@/lib/openai";

export async function POST(request: NextRequest) {
  try {
    const { query, maxResults = 3 } = await request.json();
    
    console.log("🚀 Simple wine search for:", query);
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "Du är en vinexpert. Svara ENDAST med JSON. Inga förklaringar."
        },
        {
          role: "user",
          content: `Ge ${maxResults} viner för: "${query}". Svara med JSON: {"wines": [{"name": "Chianti", "producer": "Castello", "country": "Italien", "type": "Rött vin", "price": 245, "rating": 90, "description": "Bra vin", "foodPairing": ["Pasta"], "systembolagetNumber": "7892", "drinkingPeriod": "Nu-2028", "tastingNotes": "Frukt", "availability": "quick", "purchaseLocations": [{"name": "Systembolaget", "type": "store", "url": "https://systembolaget.se", "stock": "I lager", "price": 245, "isPrivateImport": false}]}]}`
        }
      ],
      temperature: 0.2,
      max_tokens: 400,
      response_format: { type: "json_object" }
    });

    const responseText = completion.choices[0].message.content || "{}";
    console.log("📥 OpenAI response:", responseText);
    
    // Clean and fix JSON
    let cleanedText = responseText.trim();
    if (cleanedText.startsWith('```json')) {
      cleanedText = cleanedText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    }
    if (cleanedText.startsWith('```')) {
      cleanedText = cleanedText.replace(/^```\s*/, '').replace(/\s*```$/, '');
    }
    
    console.log("🧹 Cleaned JSON:", cleanedText);
    
    let data;
    try {
      data = JSON.parse(cleanedText);
    } catch (parseError) {
      console.error("❌ JSON parse error:", parseError);
      console.error("❌ Raw response:", responseText);
      console.error("❌ Cleaned response:", cleanedText);
      throw new Error("Invalid JSON response from OpenAI");
    }
    
    if (data.wines && Array.isArray(data.wines) && data.wines.length > 0) {
      console.log("✅ Success! Found", data.wines.length, "wines");
      return NextResponse.json({
        wines: data.wines,
        cached: false,
        query: query,
        aiGenerated: true,
        message: "AI-genererade resultat"
      });
    } else {
      console.log("⚠️ No wines found in response");
      return NextResponse.json({
        wines: [],
        cached: false,
        query: query,
        aiGenerated: false,
        message: "Inga viner hittades"
      });
    }
  } catch (error) {
    console.error("❌ Simple wine search failed:", error);
    return NextResponse.json({
      wines: [],
      cached: false,
      query: "error",
      aiGenerated: false,
      message: "Fel: " + (error instanceof Error ? error.message : String(error))
    }, { status: 500 });
  }
}
