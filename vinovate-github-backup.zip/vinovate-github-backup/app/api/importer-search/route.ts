import { NextRequest, NextResponse } from "next/server";
import { openai } from "@/lib/openai";
import { 
  getCachedResult, 
  cacheSearchResult, 
  recordCacheHit, 
  recordCacheMiss 
} from "@/lib/searchCache";

// Initialize OpenAI only if API key is available
// OpenAI client is now imported from lib/openai.ts

export async function POST(request: NextRequest) {
  try {
    const { importerName } = await request.json();

    if (!importerName) {
      return NextResponse.json(
        { error: "Importer name is required" },
        { status: 400 }
      );
    }

    console.log("Importer search called with:", { importerName });

    // Check cache first
    const cached = getCachedResult(importerName, {}, 'importer');
    if (cached && cached.results.wines) {
      recordCacheHit();
      return NextResponse.json({ 
        wines: cached.results.wines,
        importers: cached.results.importers,
        cached: true,
        hitCount: cached.hitCount
      });
    }
    
    recordCacheMiss();

    // Mock data for known producers/importers
    const knownImporters: Record<string, any[]> = {
      "gaja": [
        {
          name: "Barolo Sperss",
          producer: "Gaja",
          type: "Rött vin",
          country: "Italien",
          region: "Piemonte",
          year: "2019",
          price: 850,
          rating: 95,
          description: "Exklusiv barolo från Gaja med kraftig struktur och komplexitet. Perfekt för lagring.",
          foodPairing: ["Kött", "Vilt", "Truffel"],
          tastingNotes: "Mörka bär, kryddor, mineralitet. Kraftig struktur.",
          importer: "Gaja",
          importerPrice: 750,
          systembolagetPrice: 850,
          bestDrinkingPeriod: "Bäst 2024-2030",
          servingTemperature: "16-18°C",
          alcoholContent: "14.5%",
          volume: "750ml",
          imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80",
          systembolagetNumber: "72345",
          availability: "better",
          purchaseLocations: [
            {
              name: "Gaja",
              type: "private-import",
              url: "https://gaja.com",
              stock: "I lager",
              price: 750,
              savings: 100,
              isPrivateImport: true,
              minimumOrder: "6 flaskor",
              importerContact: {
                email: "info@gaja.com",
                phone: "08-123 45 67",
                orderUrl: "https://gaja.com/bestall"
              }
            },
            {
              name: "Systembolaget",
              type: "store",
              url: "https://www.systembolaget.se",
              stock: "Beställningsvara",
              price: 850,
              isPrivateImport: false
            }
          ]
        },
        {
          name: "Barbaresco",
          producer: "Gaja",
          type: "Rött vin",
          country: "Italien",
          region: "Piemonte",
          year: "2020",
          price: 650,
          rating: 92,
          description: "Elegant barbaresco med dofter av ros och kryddor. Mjukare än barolo men med stor komplexitet.",
          foodPairing: ["Kött", "Vilt", "Ost"],
          tastingNotes: "Ros, kryddor, mineralitet. Elegant struktur.",
          importer: "Gaja",
          importerPrice: 580,
          systembolagetPrice: 650,
          bestDrinkingPeriod: "Bäst 2024-2028",
          servingTemperature: "16-18°C",
          alcoholContent: "14%",
          volume: "750ml",
          imageUrl: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300&h=400&fit=crop&auto=format&q=80",
          systembolagetNumber: "67890",
          availability: "better",
          purchaseLocations: [
            {
              name: "Gaja",
              type: "private-import",
              url: "https://gaja.com",
              stock: "I lager",
              price: 580,
              savings: 70,
              isPrivateImport: true,
              minimumOrder: "6 flaskor",
              importerContact: {
                email: "info@gaja.com",
                phone: "08-123 45 67",
                orderUrl: "https://gaja.com/bestall"
              }
            },
            {
              name: "Systembolaget",
              type: "store",
              url: "https://www.systembolaget.se",
              stock: "Beställningsvara",
              price: 650,
              isPrivateImport: false
            }
          ]
        }
      ],
      "castello di brolio": [
        {
          name: "Chianti Classico",
          producer: "Castello di Brolio",
          type: "Rött vin",
          country: "Italien",
          region: "Toscana",
          year: "2020",
          price: 189,
          rating: 88,
          description: "Klassisk italiensk chianti med dofter av körsbär och kryddor. Mjuk och rund smak med bra struktur.",
          foodPairing: ["Pasta", "Kött", "Ost"],
          tastingNotes: "Röd frukt, kryddor och läder. Mjuk tannin.",
          importer: "Castello di Brolio",
          importerPrice: 165,
          systembolagetPrice: 189,
          bestDrinkingPeriod: "Drick nu - 2026",
          servingTemperature: "16-18°C",
          alcoholContent: "13.5%",
          volume: "750ml",
          imageUrl: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=300&h=400&fit=crop&auto=format&q=80",
          systembolagetNumber: "87654",
          availability: "quick",
          purchaseLocations: [
            {
              name: "Castello di Brolio",
              type: "private-import",
              url: "https://brolio.com",
              stock: "I lager",
              price: 165,
              savings: 24,
              isPrivateImport: true,
              minimumOrder: "12 flaskor",
              importerContact: {
                email: "info@brolio.com",
                phone: "08-987 65 43",
                orderUrl: "https://brolio.com/bestall"
              }
            },
            {
              name: "Systembolaget",
              type: "store",
              url: "https://www.systembolaget.se",
              stock: "Finns i de flesta butiker",
              price: 189,
              isPrivateImport: false
            }
          ]
        }
      ],
      "allegrini": [
        {
          name: "Amarone della Valpolicella",
          producer: "Allegrini",
          type: "Rött vin",
          country: "Italien",
          region: "Veneto",
          year: "2017",
          price: 380,
          rating: 90,
          description: "Kraftig amarone med rik smak av torkad frukt och kryddor. Perfekt till rött kött.",
          foodPairing: ["Kött", "Vilt", "Ost"],
          tastingNotes: "Torkad frukt, kryddor, choklad. Kraftig och rund.",
          importer: "Allegrini",
          importerPrice: 320,
          systembolagetPrice: 380,
          bestDrinkingPeriod: "Bäst 2024-2030",
          servingTemperature: "18-20°C",
          alcoholContent: "15%",
          volume: "750ml",
          imageUrl: "https://images.unsplash.com/photo-1584916201218-f4242ceb4809?w=300&h=400&fit=crop&auto=format&q=80",
          systembolagetNumber: "54321",
          availability: "better",
          purchaseLocations: [
            {
              name: "Allegrini",
              type: "private-import",
              url: "https://allegrini.it",
              stock: "I lager",
              price: 320,
              savings: 60,
              isPrivateImport: true,
              minimumOrder: "6 flaskor",
              importerContact: {
                email: "info@allegrini.it",
                phone: "08-555 44 33",
                orderUrl: "https://allegrini.it/bestall"
              }
            },
            {
              name: "Systembolaget",
              type: "store",
              url: "https://www.systembolaget.se",
              stock: "Beställningsvara",
              price: 380,
              isPrivateImport: false
            }
          ]
        }
      ]
    };

    // Find matching importer/producer
    const searchKey = importerName.toLowerCase();
    let foundWines = [];
    let foundImporter = importerName;

    for (const [key, wines] of Object.entries(knownImporters)) {
      if (searchKey.includes(key) || key.includes(searchKey)) {
        foundWines = wines;
        foundImporter = wines[0]?.importer || importerName;
        break;
      }
    }

    // If no exact match found in mock data, try AI search
    if (foundWines.length === 0 && openai) {
      try {
        console.log(`No mock data found for "${importerName}", trying AI search...`);
        
        const prompt = `Du är en vinexpert. Användaren söker efter portföljen från importören/producenten "${importerName}".

Ge mig 5-8 VERKLIGA viner från denna importör/producent. Om du inte känner till denna specifika importör/producent, ge ett tomt svar.

VIKTIGT: Svara ENDAST med giltig JSON. Ingen annan text.

Returnera JSON i exakt detta format:
{
  "wines": [
    {
      "name": "Vinets exakta namn",
      "producer": "Producent",
      "type": "Rött vin/Vitt vin/Rosé/Mousserande",
      "country": "Land",
      "region": "Region",
      "year": 2021,
      "price": 299,
      "rating": 88,
      "description": "Detaljerad beskrivning",
      "foodPairing": ["Maträtt 1", "Maträtt 2", "Maträtt 3"],
      "tastingNotes": "Smakprofil",
      "importer": "${importerName}",
      "bestDrinkingPeriod": "Drick nu - 2026",
      "servingTemperature": "16-18°C",
      "alcoholContent": "13.5%",
      "volume": "750ml",
      "systembolagetNumber": "12345",
      "availability": "quick"
    }
  ]
}`;

        const completion = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            {
              role: "system",
              content: "Du är en vinexpert som hjälper användare hitta viner från specifika importörer och producenter. Svara ENDAST med giltig JSON."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          temperature: 0.7,
        });

        const responseText = completion.choices[0]?.message?.content?.trim() || "";
        
        // Parse AI response
        let data;
        try {
          const cleanedResponse = responseText
            .replace(/```json\n?/g, "")
            .replace(/```\n?/g, "")
            .trim();
          data = JSON.parse(cleanedResponse);
        } catch (parseError) {
          console.error("Failed to parse AI response for importer search:", responseText);
          throw new Error("Kunde inte tolka AI-svaret");
        }

        if (data.wines && data.wines.length > 0) {
          foundWines = data.wines;
          foundImporter = importerName;
          
          // Cache the AI result
          cacheSearchResult(importerName, { wines: foundWines, importers: [foundImporter] }, {}, 'importer');
          
          return NextResponse.json({ 
            wines: foundWines,
            importer: foundImporter,
            cached: false,
            aiGenerated: true
          });
        }
      } catch (aiError) {
        console.error("AI search for importer failed:", aiError);
        // Fall through to return empty result
      }
    }

    // If no exact match and AI failed or not available, return empty result with helpful message
    if (foundWines.length === 0) {
      return NextResponse.json({ 
        wines: [],
        importer: importerName,
        message: openai 
          ? `Inga viner hittades för "${importerName}". Kontrollera stavningen eller prova en annan importör/producent.`
          : `Inga viner hittades för "${importerName}". Prova att söka på en känd producent som "Gaja", "Castello di Brolio" eller "Allegrini".`,
        cached: false
      });
    }

    // Cache the result
    cacheSearchResult(importerName, { wines: foundWines, importers: foundImporter ? [foundImporter] : [] }, {}, 'importer');

    return NextResponse.json({ 
      wines: foundWines,
      importer: foundImporter,
      cached: false
    });

  } catch (error) {
    console.error("Error in importer search:", error);
    return NextResponse.json(
      { error: "Failed to search for importer portfolio" },
      { status: 500 }
    );
  }
}