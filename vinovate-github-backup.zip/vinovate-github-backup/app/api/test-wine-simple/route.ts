import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

export const runtime = 'edge';

export async function POST(req: NextRequest) {
  try {
    const { query } = await req.json();
    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY?.trim().replace(/\s/g, ''),
    });

    const prompt = `Ge 3 italienska röda viner. Svara med JSON: {"wines": [{"name": "Chianti", "producer": "Castello", "country": "Italien", "type": "Rött vin", "price": 245, "rating": 90, "description": "Bra vin", "foodPairing": ["Pasta"], "systembolagetNumber": "7892", "drinkingPeriod": "Nu-2028", "tastingNotes": "Frukt", "availability": "quick", "purchaseLocations": [{"name": "Systembolaget", "type": "store", "url": "https://systembolaget.se", "stock": "I lager", "price": 245, "isPrivateImport": false}]}]}`;

    console.log("🔍 Testing simple wine search for:", query);

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.2,
      max_tokens: 1500, // Increased tokens
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: "Du är en snabb JSON-generator. Svara ENDAST med JSON. Inga förklaringar. Inga markdown." },
        { role: "user", content: prompt },
      ],
    });

    const rawResponse = completion.choices[0].message.content || "{}";
    console.log("📥 Raw OpenAI response length:", rawResponse.length);
    console.log("📥 First 200 chars:", rawResponse.substring(0, 200));
    console.log("📥 Last 200 chars:", rawResponse.substring(rawResponse.length - 200));

    // Try direct JSON parse
    let data;
    try {
      data = JSON.parse(rawResponse);
      console.log("✅ Successfully parsed JSON");
    } catch (parseError) {
      console.error("❌ JSON parse error:", parseError);
      console.error("❌ Raw response:", rawResponse);
      throw new Error("Invalid JSON response from OpenAI");
    }

    if (data.wines && Array.isArray(data.wines) && data.wines.length > 0) {
      console.log("✅ Success! Found", data.wines.length, "wines");
      return NextResponse.json({
        wines: data.wines,
        cached: false,
        query,
        aiGenerated: true,
        responseLength: rawResponse.length
      });
    } else {
      throw new Error("No wines found in AI response");
    }
  } catch (error: any) {
    console.error("❌ Simple wine search failed:", error);
    return NextResponse.json({
      wines: [],
      cached: false,
      query: "error",
      aiGenerated: false,
      message: `Fel: ${error.message}`
    }, { status: 500 });
  }
}
