import { NextRequest, NextResponse } from "next/server";
import { openai } from "@/lib/openai";
import { 
  getCachedResult, 
  cacheSearchResult, 
  recordCacheHit, 
  recordCacheMiss 
} from "@/lib/searchCache";
import { fetchSystembolagetProduct } from "@/lib/systembolaget";

export async function POST(request: NextRequest) {
  let query: string = '';
  
  try {
    console.log("🔵 AI Wine Search - Request received");
    const requestData = await request.json();
    query = requestData.query;
    const maxResults = Math.min(requestData.maxResults ?? 5, 5); // Max 5 to prevent JSON truncation
    const strictFilters = requestData.strictFilters ?? {};
    
    // Extract price filter from query
    const priceMatch = query.match(/(\d+)\s*kr/i);
    const maxPrice = priceMatch ? parseInt(priceMatch[1]) : null;
    if (maxPrice) {
      console.log(`💰 Price filter detected: max ${maxPrice}kr`);
    }
    
    console.log(`🔵 Query: "${query}", maxResults: ${maxResults}, strictFilters:`, strictFilters);

    if (!query || query.trim().length === 0) {
      console.log("❌ Empty query");
      return NextResponse.json({ error: "Sökfråga krävs" }, { status: 400 });
    }

    // Check cache first
    const cacheKey = `${query}-${maxResults}-${JSON.stringify(strictFilters)}-${maxPrice || 'no-price'}`;
    console.log(`🔍 Checking cache with key: ${cacheKey.substring(0, 50)}...`);
    const cached = getCachedResult(cacheKey, { preferQuick: true, maxResults }, 'ai-wine');
    if (cached && cached.results.wines) {
      console.log("✅ Cache hit! Returning cached result");
      recordCacheHit();
      return NextResponse.json({ 
        wines: cached.results.wines,
        cached: true,
        query,
        aiGenerated: true
      });
    }
    
    console.log("❌ Cache miss - calling OpenAI");
    recordCacheMiss();

    // Build filter instructions
    let filterInstructions = "";
    if (strictFilters.country) {
      filterInstructions += `\n🚨 KRITISKT: Alla viner MÅSTE vara från "${strictFilters.country}". Inga andra länder!`;
    }
    if (strictFilters.type) {
      filterInstructions += `\n🚨 KRITISKT: Alla viner MÅSTE vara "${strictFilters.type}". Inga andra typer!`;
    }
    if (strictFilters.region) {
      filterInstructions += `\n🚨 KRITISKT: Alla viner MÅSTE vara från regionen "${strictFilters.region}". Inga andra regioner!`;
    }
    if (strictFilters.grape) {
      filterInstructions += `\n🚨 KRITISKT: Alla viner MÅSTE innehålla druvan "${strictFilters.grape}". Inga andra druvor!`;
    }
    if (maxPrice) {
      filterInstructions += `\n💰 KRITISKT: Alla viner MÅSTE kosta max ${maxPrice}kr. Inga dyrare viner!`;
    }

    // Enhanced AI approach with recipes and alternative importers (NO fake Systembolaget numbers)
    const simplePrompt = `Ge ${maxResults} viner för: "${query}".${filterInstructions}

Inkludera för varje vin:
- Recept på rustik maträtt som passar perfekt (2-3 meningar med steg-för-steg instruktioner)
- Minst 2-3 alternativa importörer/köpställen
- Riktiga butiker som Vinoteket, Winefinder, Vinmonopolet, Philipson Söderberg, etc.

VIKTIGT: Inkludera INTE systembolagetNumber - användare ska söka själva på Systembolaget.se

Svara med JSON: {"wines": [{"name": "Chianti Classico", "producer": "Castello di Ama", "country": "Italien", "type": "Rött vin", "price": 245, "rating": 90, "description": "Klassisk Chianti med god struktur", "foodPairing": ["Pasta med köttfärssås"], "recipe": "Pasta alla Bolognese: Hacka kött, lök, morot, selleri. Stek tillsammans, tillsätt tomatpuré och vin. Servera med tagliatelle.", "drinkingPeriod": "Nu-2028", "tastingNotes": "Körsbär, läder, tobak", "availability": "quick", "purchaseLocations": [{"name": "Systembolaget", "type": "store", "url": "https://systembolaget.se", "stock": "I lager", "price": 245, "isPrivateImport": false}, {"name": "Vinoteket", "type": "store", "url": "https://vinoteket.se", "stock": "I lager", "price": 245, "isPrivateImport": false}, {"name": "Winefinder", "type": "store", "url": "https://winefinder.se", "stock": "Begränsad", "price": 245, "isPrivateImport": false}]}]}`;

    console.log(`🚀 Calling OpenAI with query: "${query}"`);
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.05, // Lower for faster, more consistent responses
      max_tokens: 2000, // Optimized for 5 wines with recipes, Systembolaget numbers, and 3 purchase locations each
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: "Du är en snabb JSON-generator. Svara ENDAST med JSON. Inga förklaringar. Inga markdown. Följ ALLA filter-instruktioner exakt. Använd riktiga Systembolaget-nummer och butiker." },
        { role: "user", content: simplePrompt },
      ],
    });

    const rawResponse = completion.choices[0].message.content || "{}";
    console.log(`✅ OpenAI response length: ${rawResponse.length}`);
    console.log(`📄 First 200 chars: ${rawResponse.substring(0, 200)}`);
    
    // Validate JSON before parsing
    let data;
    try {
      data = JSON.parse(rawResponse);
      console.log(`✅ JSON parsed successfully, wines count: ${data.wines?.length || 0}`);
    } catch (parseError) {
      console.error("❌ JSON parse error:", parseError);
      console.error("❌ Raw response:", rawResponse);
      throw new Error("Invalid JSON from OpenAI");
    }

    if (data.wines && Array.isArray(data.wines) && data.wines.length > 0) {
      // Apply strict filters if any (post-validation)
      let wines = data.wines;
      const beforeFilter = wines.length;
      
      if (strictFilters.country) {
        wines = wines.filter((w: any) => {
          const matches = w.country && w.country.toLowerCase() === String(strictFilters.country).toLowerCase();
          if (!matches) console.log(`⚠️ Filtered out wine from ${w.country}, expected ${strictFilters.country}`);
          return matches;
        });
      }
      if (strictFilters.type) {
        wines = wines.filter((w: any) => {
          const matches = w.type && w.type.toLowerCase().includes(String(strictFilters.type).toLowerCase().split(' ')[0]);
          if (!matches) console.log(`⚠️ Filtered out wine type ${w.type}, expected ${strictFilters.type}`);
          return matches;
        });
      }
      if (strictFilters.region) {
        wines = wines.filter((w: any) => {
          const matches = w.region && w.region.toLowerCase().includes(String(strictFilters.region).toLowerCase());
          if (!matches) console.log(`⚠️ Filtered out wine from region ${w.region}, expected ${strictFilters.region}`);
          return matches;
        });
      }
      if (strictFilters.grape) {
        wines = wines.filter((w: any) => {
          const matches = (w.grapes || []).some((g: string) => g.toLowerCase().includes(String(strictFilters.grape).toLowerCase()));
          if (!matches) console.log(`⚠️ Filtered out wine with grapes ${w.grapes}, expected ${strictFilters.grape}`);
          return matches;
        });
      }
      if (maxPrice) {
        wines = wines.filter((w: any) => {
          const winePrice = w.price || 0;
          const matches = winePrice <= maxPrice;
          if (!matches) console.log(`⚠️ Filtered out wine with price ${winePrice}kr, max allowed ${maxPrice}kr`);
          return matches;
        });
      }

      const afterFilter = wines.length;
      if (beforeFilter > afterFilter) {
        console.log(`🔍 Post-filter: ${beforeFilter} wines → ${afterFilter} wines (removed ${beforeFilter - afterFilter})`);
      }

      if (wines.length > 0) {
        // Don't add fake Systembolaget numbers - let users search themselves
        const enrichedWines = wines.map((wine: any) => {
          // Remove any fake systembolagetNumber from AI response
          const { systembolagetNumber, ...wineWithoutFakeNumber } = wine;
          
          // Ensure all purchase locations have consistent pricing
          const updatedPurchaseLocations = wine.purchaseLocations?.map((location: any) => ({
            ...location,
            price: wine.price
          })) || [];
          
          return {
            ...wineWithoutFakeNumber,
            purchaseLocations: updatedPurchaseLocations
          };
        });
        
        const validWines = enrichedWines;

        cacheSearchResult(cacheKey, { wines: validWines }, { preferQuick: true, maxResults }, 'ai-wine');
        return NextResponse.json({ 
          wines: validWines, 
          cached: false, 
          query,
          aiGenerated: true
        });
      } else {
        console.error(`❌ All wines were filtered out! Original count: ${beforeFilter}`);
      }
    }

    // Fallback to simple mock data if AI fails
    const fallbackWines = [
      {
        name: "Chianti Classico",
        producer: "Castello di Ama",
        country: "Italien",
        region: "Toscana",
        type: "Rött vin",
        price: 245,
        rating: 90,
        description: "Klassisk Chianti med god struktur och elegans.",
        foodPairing: ["Pasta", "Kött", "Ost"],
        systembolagetNumber: "7234",
        drinkingPeriod: "Nu-2028",
        tastingNotes: "Körsbär, läder, tobak",
        availability: "quick",
        purchaseLocations: [
          { name: "Systembolaget", type: "store", url: "https://systembolaget.se", stock: "I lager", price: 245, isPrivateImport: false }
        ]
      }
    ];

    return NextResponse.json({ 
      wines: fallbackWines,
      cached: false,
      query,
      aiGenerated: false,
      message: "AI-sökning misslyckades, visar grundläggande resultat"
    });

  } catch (error) {
    console.error("Error in AI wine search:", error);
    
    // Return fallback wines instead of error
    const fallbackWines = [
      {
        name: "Chianti Classico",
        producer: "Castello di Ama",
        country: "Italien",
        region: "Toscana",
        type: "Rött vin",
        price: 245,
        rating: 90,
        description: "Klassisk Chianti med god struktur och elegans.",
        foodPairing: ["Pasta", "Kött", "Ost"],
        drinkingPeriod: "Nu-2028",
        tastingNotes: "Körsbär, läder, tobak",
        availability: "quick",
        purchaseLocations: [
          { name: "Systembolaget", type: "store", url: "https://systembolaget.se", stock: "I lager", price: 245, isPrivateImport: false }
        ]
      }
    ];
    
      return NextResponse.json({
        wines: fallbackWines,
        cached: false,
      query: query || "error",
        aiGenerated: false,
      message: "Sökningen misslyckades, visar grundläggande resultat"
    });
  }
}
