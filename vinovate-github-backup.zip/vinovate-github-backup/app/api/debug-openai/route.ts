import { NextRequest, NextResponse } from "next/server";
import { openai } from "@/lib/openai";

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json();
    
    console.log("🔍 Debug OpenAI for query:", query);
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "Du är en vinexpert. Svara ENDAST med JSON. Inga förklaringar."
        },
        {
          role: "user",
          content: `Ge 2 viner för: "${query}". Svara med JSON: {"wines": [{"name": "Chianti", "producer": "Castello", "country": "Italien", "type": "Rött vin", "price": 245, "rating": 90, "description": "Bra vin", "foodPairing": ["Pasta"], "systembolagetNumber": "7892", "drinkingPeriod": "Nu-2028", "tastingNotes": "Frukt", "availability": "quick", "purchaseLocations": [{"name": "Systembolaget", "type": "store", "url": "https://systembolaget.se", "stock": "I lager", "price": 245, "isPrivateImport": false}]}]}`
        }
      ],
      temperature: 0.2,
      max_tokens: 400,
      response_format: { type: "json_object" }
    });

    const responseText = completion.choices[0].message.content || "";
    
    return NextResponse.json({
      success: true,
      rawResponse: responseText,
      responseLength: responseText.length,
      firstChars: responseText.substring(0, 100),
      lastChars: responseText.substring(Math.max(0, responseText.length - 100))
    });
  } catch (error) {
    console.error("❌ Debug OpenAI failed:", error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
