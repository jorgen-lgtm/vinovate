import { NextRequest, NextResponse } from "next/server";
import { sponsoredImporters, getActiveSponsoredImporters, sponsorshipPackages } from "@/data/sponsoredImporters";

// GET - Get all sponsors or active sponsors
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const activeOnly = searchParams.get('active') === 'true';
    
    const sponsors = activeOnly ? getActiveSponsoredImporters() : sponsoredImporters;
    
    return NextResponse.json({
      sponsors,
      count: sponsors.length,
      packages: sponsorshipPackages
    });
  } catch (error) {
    console.error("Error fetching sponsors:", error);
    return NextResponse.json(
      { error: "Failed to fetch sponsors" },
      { status: 500 }
    );
  }
}

// POST - Create new sponsor (in production, this would save to database)
export async function POST(request: NextRequest) {
  try {
    const sponsorData = await request.json();
    
    // Validate required fields
    if (!sponsorData.name || !sponsorData.email || !sponsorData.sponsorshipLevel) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }
    
    // In production, save to database
    // For now, just return success
    return NextResponse.json({
      success: true,
      message: "Sponsor created successfully",
      sponsor: {
        id: `sponsor-${Date.now()}`,
        ...sponsorData,
        isActive: true
      }
    }, { status: 201 });
  } catch (error) {
    console.error("Error creating sponsor:", error);
    return NextResponse.json(
      { error: "Failed to create sponsor" },
      { status: 500 }
    );
  }
}

