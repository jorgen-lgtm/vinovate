import { NextRequest, NextResponse } from "next/server";
import { sponsoredImporters } from "@/data/sponsoredImporters";

// GET - Get single sponsor
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const sponsor = sponsoredImporters.find(s => s.id === params.id);
    
    if (!sponsor) {
      return NextResponse.json(
        { error: "Sponsor not found" },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ sponsor });
  } catch (error) {
    console.error("Error fetching sponsor:", error);
    return NextResponse.json(
      { error: "Failed to fetch sponsor" },
      { status: 500 }
    );
  }
}

// PATCH - Update sponsor (toggle active status, etc.)
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const updates = await request.json();
    
    // In production, update database
    // For now, just return success
    return NextResponse.json({
      success: true,
      message: "Sponsor updated successfully",
      updates
    });
  } catch (error) {
    console.error("Error updating sponsor:", error);
    return NextResponse.json(
      { error: "Failed to update sponsor" },
      { status: 500 }
    );
  }
}

// DELETE - Delete sponsor
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // In production, delete from database
    return NextResponse.json({
      success: true,
      message: "Sponsor deleted successfully"
    });
  } catch (error) {
    console.error("Error deleting sponsor:", error);
    return NextResponse.json(
      { error: "Failed to delete sponsor" },
      { status: 500 }
    );
  }
}

