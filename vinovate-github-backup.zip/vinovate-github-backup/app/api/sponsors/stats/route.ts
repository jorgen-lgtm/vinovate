import { NextRequest, NextResponse } from "next/server";
import { getActiveSponsoredImporters } from "@/data/sponsoredImporters";

// GET - Get sponsor statistics
export async function GET(request: NextRequest) {
  try {
    const sponsors = getActiveSponsoredImporters();
    
    // Calculate statistics
    const stats = {
      totalActiveSponsors: sponsors.length,
      sponsorsByLevel: {
        premium: sponsors.filter(s => s.sponsorshipLevel === 'premium').length,
        standard: sponsors.filter(s => s.sponsorshipLevel === 'standard').length,
        basic: sponsors.filter(s => s.sponsorshipLevel === 'basic').length
      },
      totalFeaturedWines: sponsors.reduce((sum, s) => sum + s.featuredWines.length, 0),
      adPlacements: {
        searchResults: sponsors.filter(s => s.adSettings.showInSearchResults).length,
        sidebar: sponsors.filter(s => s.adSettings.showInSidebar).length,
        banner: sponsors.filter(s => s.adSettings.showBanner).length
      },
      // Mock revenue data (in production, calculate from actual data)
      estimatedMonthlyRevenue: sponsors.reduce((sum, s) => {
        const packagePrices = { premium: 15000, standard: 8000, basic: 3000 };
        return sum + packagePrices[s.sponsorshipLevel];
      }, 0)
    };
    
    return NextResponse.json(stats);
  } catch (error) {
    console.error("Error fetching sponsor stats:", error);
    return NextResponse.json(
      { error: "Failed to fetch statistics" },
      { status: 500 }
    );
  }
}

