"use client";

import { useState } from "react";

export default function TestAI() {
  const [query, setQuery] = useState("rött italien");
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const testAI = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/test-wine-simple", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });
      
      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error("Error:", error);
      setResults({ error: "Failed to fetch" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-wine-800 to-red-900 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8">AI Wine Test</h1>
        
        <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 mb-6">
          <div className="flex gap-4 mb-4">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 px-4 py-2 rounded-lg bg-white/20 text-white placeholder-white/70"
              placeholder="Sök efter viner..."
            />
            <button
              onClick={testAI}
              disabled={loading}
              className="px-6 py-2 bg-pink-600 hover:bg-pink-700 disabled:bg-gray-500 text-white rounded-lg font-semibold"
            >
              {loading ? "Testar..." : "Testa AI"}
            </button>
          </div>
        </div>

        {results && (
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <h2 className="text-xl font-bold text-white mb-4">Resultat</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="bg-white/20 rounded-lg p-4">
                <h3 className="font-semibold text-white mb-2">Status</h3>
                <p className="text-white/80">
                  AI Genererad: {results.aiGenerated ? "✅ Ja" : "❌ Nej"}
                </p>
                <p className="text-white/80">
                  Antal viner: {results.wines?.length || 0}
                </p>
                <p className="text-white/80">
                  Svar längd: {results.responseLength || "N/A"}
                </p>
              </div>
              
              <div className="bg-white/20 rounded-lg p-4">
                <h3 className="font-semibold text-white mb-2">Query</h3>
                <p className="text-white/80">{results.query}</p>
                {results.message && (
                  <p className="text-yellow-300 text-sm mt-2">{results.message}</p>
                )}
              </div>
            </div>

            {results.wines && results.wines.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Viner</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {results.wines.map((wine: any, index: number) => (
                    <div key={index} className="bg-white/20 rounded-lg p-4">
                      <h4 className="font-semibold text-white">{wine.name}</h4>
                      <p className="text-white/80 text-sm">{wine.producer}</p>
                      <p className="text-white/80 text-sm">{wine.country}</p>
                      <p className="text-white/80 text-sm">{wine.type}</p>
                      <p className="text-pink-300 font-semibold">{wine.price}kr</p>
                      <p className="text-yellow-300 text-sm">⭐ {wine.rating}/100</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {results.error && (
              <div className="bg-red-500/20 border border-red-500 rounded-lg p-4">
                <p className="text-red-300">Fel: {results.error}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
