# Environment Variables för Vinovate

Skapa en `.env.local` fil i projektets root med följande variabler:

## Obligatoriska Variabler

### OpenAI API Key
```bash
OPENAI_API_KEY=your_openai_api_key_here
```
Hämta din API-nyckel från: https://platform.openai.com/api-keys

### Admin Password
```bash
ADMIN_PASSWORD=vinovate2025
```
**VIKTIGT:** Ändra detta till ett säkert lösenord innan deployment!

## Exempel .env.local

Kopiera detta och fyll i dina värden:

```bash
# OpenAI API Key (Required)
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Admin Password (Required)
ADMIN_PASSWORD=ditt_sakra_losenord_har

# Optional: Node Environment
NODE_ENV=production
```

## Säkerhet

### Generera säkert lösenord
```bash
# macOS/Linux
openssl rand -base64 32

# eller använd en lösenordsgenerator
```

### Skydda .env.local
- ✅ Lägg till `.env.local` i `.gitignore`
- ✅ Committa ALDRIG lösenord till Git
- ✅ Använd olika lösenord för dev/staging/production
- ✅ Rotera lösenord regelbundet

## Deployment

### Vercel
1. Gå till Project Settings → Environment Variables
2. Lägg till `OPENAI_API_KEY` och `ADMIN_PASSWORD`
3. Markera som "Production"

### Netlify
1. Site Settings → Environment Variables
2. Lägg till variabler
3. Redeploy

### Docker
```bash
docker run -e OPENAI_API_KEY=xxx -e ADMIN_PASSWORD=xxx vinovate
```

## Verifiering

Testa att variablerna är korrekt satta:
```bash
# Kör health check
curl http://localhost:3000/api/health

# Förväntat resultat:
# {"status":"ok","message":"Vinovate API is running","openaiConfigured":true}
```

