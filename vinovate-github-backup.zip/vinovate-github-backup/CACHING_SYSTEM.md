# 🚀 WineAI Caching & Indexering System

## Översikt

WineAI använder ett intelligent caching-system som gör appen **snabbare och billigare** ju fler användare som söker. Systemet lär sig från tidigare sökningar och kan återanvända resultat.

## Hur Fungerar Det?

### 1. **Cache-First Arkitektur**

```
Användare söker → Kolla cache → Hit? → Returnera direkt (blixtsn abbt!)
                                ↓ Miss
                          → OpenAI API → Spara i cache → Returnera
```

### 2. **Intelligent Matching**

#### Exakt Matchning
```
Sökning: "Rött vin till pasta"
Cache: "Rött vin till pasta" ✅
→ Exakt träff! (< 50ms responstid)
```

#### Similarity Matching (80%+ likhet)
```
Sökning: "Röda viner till pasta carbonara"
Cache: "Rött vin till pasta" (85% likhet) ✅
→ Liknande nog! Återanvänd resultat
```

#### Normalisering
```
"Röda viner från Italien" 
→ normaliseras till: "roda viner fran italien"

"Rött vin Italia"
→ normaliseras till: "rott vin italia"

Similarity: 75% (använder cached om > 80%)
```

### 3. **Vad Cachas?**

- ✅ Vinsökningar
- ✅ Importörs-portföljer
- ✅ "Hitta importörer"-sökningar
- ✅ Filter-kombinationer

### 4. **Cache TTL (Time To Live)**

- **7 dagar** - Efter det rensas data
- Motivering: Vinpriser och tillgänglighet ändras, behöver uppdateras

## Fördelar

### 💰 Kostnadsbesparing

**Utan cache:**
- 100 användare × "rött vin till pasta" = 100 API-anrop
- Kostnad: 100 × $0.02 = **$2.00**

**Med cache:**
- 100 användare × "rött vin till pasta" = 1 API-anrop + 99 cache hits
- Kostnad: 1 × $0.02 = **$0.02**
- **Besparing: 99%!** 💰

### ⚡ Snabbare Svar

**Utan cache:**
- Genomsnittlig responstid: **3-8 sekunder** (OpenAI API)

**Med cache:**
- Genomsnittlig responstid: **< 50 millisekunder** 
- **60-160x snabbare!** ⚡

### 📊 Populära Sökningar

Systemet spårar vilka sökningar som är mest populära:
- "Rött vin till pasta" - 847 ggr
- "Champagne till fest" - 523 ggr
- "Barolo" - 412 ggr

Detta kan användas för:
- Föreslå populära sökningar
- Pre-cache vanliga queries
- Analytics och insights

## Teknisk Implementation

### Cache-Struktur

```typescript
interface CachedSearch {
  query: string;               // Original query
  normalizedQuery: string;     // Normalized for matching
  filters?: any;               // Applied filters
  results: {
    wines?: Wine[];
    importers?: Importer[];
  };
  timestamp: number;           // When cached
  hitCount: number;            // How many times used
  searchType: string;          // 'wine', 'importer', etc.
}
```

### Similarity Algorithm (Jaccard)

```typescript
function calculateSimilarity(str1, str2) {
  const words1 = new Set(str1.split(' '));
  const words2 = new Set(str2.split(' '));
  
  const intersection = words1 ∩ words2;  // Gemensamma ord
  const union = words1 ∪ words2;         // Alla ord
  
  return |intersection| / |union|;
}
```

**Exempel:**
```
Query 1: "rött vin pasta"        → [rött, vin, pasta]
Query 2: "rött vin carbonara"    → [rött, vin, carbonara]

Intersection: [rött, vin]        → 2 ord
Union: [rött, vin, pasta, carbonara] → 4 ord

Similarity: 2/4 = 0.5 (50%) ✗ (för låg, använd inte cache)
```

```
Query 1: "rött vin till pasta"
Query 2: "rött vin pasta"

Similarity: 3/4 = 0.75 ✗
Men om threshold är 0.8: Gör ny sökning

Query 1: "rött vin pasta carbonara"
Query 2: "rött vin till pasta"

Similarity: 3/5 = 0.6 ✗
```

### Cache Cleanup

**Automatisk rensning när:**
- Cache > 1000 entries
- Entries äldre än 7 dagar
- Tar bort minst använda först (LRU-like)

## API Endpoints

### GET /api/cache/stats
```json
{
  "totalEntries": 347,
  "totalHits": 1893,
  "avgHitCount": 5.45,
  "cacheHitRate": 0.73,
  "topQueries": [
    { "query": "Rött vin till pasta", "hits": 89 },
    { "query": "Champagne till fest", "hits": 67 }
  ]
}
```

### POST /api/cache/clear
```json
{
  "success": true,
  "message": "Cache cleared successfully"
}
```

## Framtida Förbättringar

### Version 2.0: Persistent Cache (Redis)

```typescript
import Redis from 'ioredis';

const redis = new Redis(process.env.REDIS_URL);

// Persistent mellan server-restarts
// Delad mellan multiple servers
// Snabbare än in-memory för stora dataset
```

### Version 3.0: Database + Machine Learning

```typescript
// PostgreSQL för långtids-lagring
// Analysera sök-patterns
// Förbättra recommendations med ML
// Personalisering per användare
```

### Version 4.0: Pre-caching

```typescript
// Pre-cache populära kombinationer
// Background jobs för att uppdatera cache
// Smart prefetch baserat på användarbeteende
```

## Prestanda-Metrics

### Nuvarande Implementation (In-Memory)

| Metrik | Värde |
|--------|-------|
| Cache Lookup | < 1ms |
| Cache Hit Return | 10-50ms |
| Cache Miss (OpenAI) | 3000-8000ms |
| Max Entries | 1000 |
| TTL | 7 dagar |
| Similarity Threshold | 80% |

### Förväntad Prestanda

Med 1000 användare/dag:
- **Cache Hit Rate**: 60-80% efter 1 vecka
- **Cost Reduction**: 60-80% lägre OpenAI-kostnader
- **Speed Improvement**: 60-80% snabbare svar
- **User Experience**: Betydligt bättre

## Användning för Utvecklare

### Kolla Cache Stats

```bash
curl http://localhost:3000/api/cache/stats
```

### Rensa Cache (Dev/Test)

```bash
curl -X POST http://localhost:3000/api/cache/clear
```

### Debug Cache

```typescript
import { getCacheStats, getTopQueries } from '@/lib/searchCache';

const stats = getCacheStats();
console.log('Cache stats:', stats);

const popular = getTopQueries(20);
console.log('Top 20 queries:', popular);
```

## Begränsningar (Nuvarande)

### In-Memory Cache

❌ **Försvinner vid server-restart**
❌ **Delas inte mellan multiple servers**
❌ **Begränsad till 1000 entries**
✅ **Gratis**
✅ **Snabb**
✅ **Enkel**

### Migration till Redis (Rekommenderat för Produktion)

```bash
# 1. Installera Redis
npm install ioredis

# 2. Lägg till i .env.local
REDIS_URL=redis://localhost:6379

# 3. Uppdatera lib/searchCache.ts
# Ersätt Map med Redis
```

## Best Practices

### 1. Monitored Cache Hit Rate
- Kolla /api/cache/stats regelbundet
- Mål: > 60% hit rate
- Om lägre: Justera similarity threshold

### 2. Cache Warming
För populära queries, kör pre-search:
```typescript
// cron job eller init script
preCache([
  "Rött vin till pasta",
  "Champagne till fest",
  "Barolo"
]);
```

### 3. Cache Invalidation
Vid stora dataändringar (t.ex. nya priser):
```bash
curl -X POST /api/cache/clear
```

## Visuell Indikation

När ett resultat kommer från cache, ser användaren:

```
⚡ Snabbsvar från cache (12 ggr tidigare)
```

- Grön badge
- Blixt-ikon
- Visar hur många gånger sökningen gjorts

## Analytics Insights

Med tiden kan du se:
- Vilka viner är mest sökta
- Vilka priskla sser är populärast
- Vilka länder/regioner folk föredrar
- Peak-tider för sökningar
- Konverteringsrate (sökning → klick → info)

## Säkerhet

### Cache Poisoning Prevention
- Validera ALL data innan caching
- Sanitera användarinput
- Ingen känslig data i cache
- Rate limiting för att förhindra spam

### Privacy
- Inga användaridentifierare i cache
- Endast söktermer och resultat
- GDPR-compliant (anonymt)

## Monitoring

### Production Checklist

- [ ] Sätt upp Redis för persistent cache
- [ ] Implementera cache metrics dashboard
- [ ] Sätt alerts för låg hit rate
- [ ] Logga cache performance
- [ ] Monitored cache size och cleanup

---

**Version**: 1.0  
**Status**: ✅ Implementerat (In-Memory)  
**Nästa steg**: Redis integration för produktion

För frågor om caching-systemet, se `/lib/searchCache.ts` källkod.

