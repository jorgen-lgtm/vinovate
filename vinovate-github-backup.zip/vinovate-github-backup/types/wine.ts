export interface FoodPairingDetail {
  dish: string;
  description: string;
  why: string;
  recipe?: string;
}

export interface Wine {
  name: string;
  producer: string;
  type: string;
  country: string;
  region?: string;
  year?: string;
  price?: number;
  rating?: number;
  description: string;
  foodPairing: string[];
  foodPairingDetails?: FoodPairingDetail[];
  recipe?: string; // NEW: Rustic recipe that pairs with the wine
  imageUrl?: string;
  systembolagetNumber?: string;
  availability: 'quick' | 'better';
  tastingNotes?: string;
  purchaseLocations: PurchaseLocation[];
  importer?: string;
  importerPrice?: number;
  systembolagetPrice?: number;
  bestDrinkingPeriod?: string;
  servingTemperature?: string;
  alcoholContent?: string;
  volume?: string;
}

export interface PurchaseLocation {
  name: string;
  type: 'store' | 'online' | 'private-import';
  url?: string;
  stock?: string;
  price?: number;
  savings?: number;
  importerContact?: {
    email?: string;
    phone?: string;
    orderUrl?: string;
  };
  isPrivateImport?: boolean;
  minimumOrder?: string;
}

export interface WineSearchParams {
  query: string;
  preferQuick: boolean;
  searchType?: 'general' | 'importer';
}

export interface ImporterPortfolio {
  importer: string;
  wines: Wine[];
  totalWines: number;
}

