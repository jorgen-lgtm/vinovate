// Types for sponsored content and advertising

export interface SponsoredImporter {
  id: string;
  name: string;
  description: string;
  logo?: string;
  website: string;
  email: string;
  phone: string;
  specialization: string[]; // e.g., ["Italien", "Frankrike", "Rött vin"]
  
  // Advertising details
  sponsorshipLevel: 'premium' | 'standard' | 'basic';
  sponsorshipStartDate: string;
  sponsorshipEndDate: string;
  isActive: boolean;
  
  // Featured wines
  featuredWines: {
    name: string;
    producer: string;
    type: string;
    country: string;
    region: string;
    year?: string;
    price: number;
    rating?: number;
    description: string;
    imageUrl?: string;
    systembolagetNumber?: string;
  }[];
  
  // Ad placement settings
  adSettings: {
    showInSearchResults: boolean;
    showInSidebar: boolean;
    showBanner: boolean;
    priority: number; // Higher = shown more often
  };
}

export interface Advertisement {
  id: string;
  type: 'banner' | 'sidebar' | 'inline' | 'modal';
  sponsor: SponsoredImporter;
  content: {
    title: string;
    description: string;
    imageUrl?: string;
    ctaText: string;
    ctaUrl: string;
  };
  placement: {
    page: 'home' | 'search' | 'all';
    position: 'top' | 'bottom' | 'right' | 'left';
  };
  impressions: number;
  clicks: number;
  isActive: boolean;
}

export interface SponsorshipPackage {
  id: string;
  name: string;
  level: 'premium' | 'standard' | 'basic';
  price: number; // per month
  features: {
    searchResultPlacements: number; // How many times per day
    sidebarAds: boolean;
    bannerAds: boolean;
    featuredWinesCount: number;
    priority: number;
  };
  description: string;
}

