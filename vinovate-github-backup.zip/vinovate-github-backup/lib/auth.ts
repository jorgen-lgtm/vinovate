// Enhanced authentication for admin panel
// In production, use a proper auth solution like NextAuth.js

export function checkAdminAuth(password: string): boolean {
  const adminPassword = process.env.ADMIN_PASSWORD || "vinovate2025";
  
  // Simple comparison (in production, use bcrypt or similar)
  return password === adminPassword;
}

// Generate a simple session token (in production, use proper JWT)
function generateSessionToken(): string {
  // Use Web Crypto API for browser compatibility
  if (typeof window !== 'undefined' && window.crypto) {
    const array = new Uint8Array(32);
    window.crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
  }
  // Fallback for older environments
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

export function setAdminSession(): string {
  if (typeof window !== 'undefined') {
    const token = generateSessionToken();
    const expires = Date.now() + (24 * 60 * 60 * 1000); // 24 hours
    const sessionData = JSON.stringify({ token, expires });
    sessionStorage.setItem('vinovate_admin_auth', sessionData);
    return token;
  }
  return '';
}

export function getAdminSession(): boolean {
  if (typeof window !== 'undefined') {
    const sessionData = sessionStorage.getItem('vinovate_admin_auth');
    if (!sessionData) return false;
    
    try {
      const { expires } = JSON.parse(sessionData);
      if (Date.now() > expires) {
        clearAdminSession();
        return false;
      }
      return true;
    } catch {
      clearAdminSession();
      return false;
    }
  }
  return false;
}

export function clearAdminSession() {
  if (typeof window !== 'undefined') {
    sessionStorage.removeItem('vinovate_admin_auth');
  }
}

