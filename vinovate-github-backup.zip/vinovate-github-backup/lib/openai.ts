import OpenAI from 'openai';

// Sanitize API key to avoid illegal header characters (e.g., newlines/spaces)
const rawKey = process.env.OPENAI_API_KEY || '';
const sanitizedKey = rawKey.trim().replace(/\s+/g, '');

// Initialize OpenAI with sanitized API key
export const openai = sanitizedKey
  ? new OpenAI({ apiKey: sanitizedKey })
  : undefined as unknown as OpenAI; // will be checked by callers

export default openai;

