# Exempel på vinsökningar i WineAI

## Grundläggande sökningar

### Typ av vin
- "Rött vin"
- "Vitt vin"
- "Rosé"
- "Mousserande vin"
- "Champagne"

### Med prisintervall
- "Rött vin under 150 kr"
- "Lyxigt vin mellan 300-500 kr"
- "Billigt men gott vitt vin"
- "Champagne till fest under 400 kr"

### Land och region
- "Italienskt rött vin"
- "Franskt vitt vin från Bourgogne"
- "Spanskt vin"
- "Nyzeeländskt Sauvignon Blanc"
- "Argentinskt Malbec"

## Matsökning (rekommenderat!)

### Kött
- "Vin till biff"
- "Rött vin till lamm"
- "Vin som passar till grillat kött"
- "Vin till fläskfilé"

### Fisk och skaldjur
- "Vitt vin till lax"
- "Vin till musslor"
- "Vin som passar till sushi"
- "Vin till hummer"

### Pasta och italienskt
- "Vin till pasta carbonara"
- "Rött vin till pizza"
- "Vin till lasagne"
- "Vin som passar till risotto"

### Övrigt
- "Vin till ost"
- "Vin till dessert"
- "Vin till asiatisk mat"
- "Aperitif vin"

## Tillfällen

- "Vin till fest"
- "Romantiskt vin till middag"
- "Vin till midsommar"
- "Presentvin"
- "Vardagsvin"

## Avancerade sökningar

### Kombinationer
- "Fruktigt rött vin under 200 kr till pasta"
- "Torrt vitt vin från Frankrike till fisk"
- "Lättdrucket rött vin till vardagen under 150 kr"

### Specifika egenskaper
- "Fylligt rött vin med mycket tanniner"
- "Fräscht vitt vin med hög syra"
- "Sött vin till dessert"
- "Torrt mousserande vin"

## Tips för bästa resultat

1. **Var specifik**: Ju mer detaljer du ger, desto bättre rekommendationer
2. **Inkludera mat**: Matpairing ger ofta de bästa förslagen
3. **Ange budget**: Hjälper AI:n att ge realistiska förslag
4. **Använd prioritering**: 
   - "Snabb tillgänglighet" för viner som oftast finns i lager
   - "Bästa betyg" för högkvalitativa rekommendationer

## Exempel på komplett sökning

**Sökning**: "Italienskt rött vin under 200 kr som passar till pasta bolognese"

**Prioritering**: Snabb tillgänglighet

**Förväntade resultat**: 
- 3 specifika italienska rödviner
- Pris under 200 kr
- Matpairing med pasta bolognese
- Information om var du kan köpa
- Provningsanteckningar

Lycka till med din vinsökning! 🍷

