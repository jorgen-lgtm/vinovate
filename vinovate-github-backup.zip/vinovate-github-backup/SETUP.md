# Installationsguide för WineAI

## Steg-för-steg installation

### 1. OpenAI API-nyckel

Innan du kan använda applikationen behöver du en OpenAI API-nyckel:

1. Gå till [OpenAI Platform](https://platform.openai.com/)
2. Skapa ett konto eller logga in
3. Navigera till API-nycklar: [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
4. Klicka på "Create new secret key"
5. Kopiera din API-nyckel (du kommer inte kunna se den igen!)

### 2. Installera projektet

\`\`\`bash
# Installera dependencies
npm install

# Skapa .env.local fil
cp .env.example .env.local
\`\`\`

### 3. Konfigurera miljövariabler

Öppna `.env.local` filen och lägg till din OpenAI API-nyckel:

\`\`\`
OPENAI_API_KEY=sk-proj-...din-faktiska-nyckel-här...
\`\`\`

### 4. Starta applikationen

\`\`\`bash
# Starta utvecklingsservern
npm run dev
\`\`\`

Öppna [http://localhost:3000](http://localhost:3000) i din webbläsare!

## Felsökning

### "API key not found" eller liknande fel
- Kontrollera att du har skapat `.env.local` filen
- Kontrollera att din API-nyckel är korrekt kopierad
- Starta om utvecklingsservern efter att ha lagt till API-nyckeln

### Viner visas inte
- Kontrollera din internetanslutning
- Kontrollera att din OpenAI API-nyckel är giltig
- Kontrollera att du har krediter kvar på ditt OpenAI-konto

### Bilder saknas
- Detta är normalt - Systembolaget-integration kräver ytterligare konfiguration
- Applikationen fungerar fortfarande utan bilder

## Kostnader

WineAI använder OpenAI's GPT-4o modell. Varje sökning kostar cirka:
- ~$0.01-0.03 per sökning (beroende på komplexitet)
- Du kan övervaka din användning på [OpenAI Platform](https://platform.openai.com/usage)

## Nästa steg

När applikationen fungerar kan du:
1. Prova olika vinsökningar
2. Experimentera med "Snabb tillgänglighet" vs "Bästa betyg"
3. Utforska matpairing-förslag
4. Anpassa UI:t i Tailwind CSS

Njut av din vinupplevelse! 🍷

