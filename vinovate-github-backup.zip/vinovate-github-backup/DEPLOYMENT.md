# Vinovate Deployment Guide

**Där passion möter innovation**

## Förberedelser

### 1. Miljövariabler
Skapa `.env.local` med:
```bash
OPENAI_API_KEY=your_key_here
ADMIN_PASSWORD=your_secure_password
```

Se `ENV_EXAMPLE.md` för detaljer.

### 2. Bygg projektet
```bash
npm run build
```

Verifiera att bygget lyckas utan fel.

### 3. Testa lokalt
```bash
npm run start
```

Besök `http://localhost:3000` och testa alla funktioner.

## Deployment Alternativ

### Option 1: Vercel (Rekommenderat) ⭐

**Fördelar:**
- ✅ Gratis för hobby-projekt
- ✅ Automatisk CI/CD från Git
- ✅ Global CDN
- ✅ Automatisk HTTPS
- ✅ Perfekt för Next.js

**Steg:**

1. **Installera Vercel CLI**
```bash
npm install -g vercel
```

2. **Logga in**
```bash
vercel login
```

3. **Deploy**
```bash
vercel
```

4. **Sätt miljövariabler**
```bash
vercel env add OPENAI_API_KEY
vercel env add ADMIN_PASSWORD
```

5. **Production deploy**
```bash
vercel --prod
```

**Alternativt via GitHub:**
1. Pusha kod till GitHub
2. Importera projekt på vercel.com
3. Lägg till miljövariabler
4. Deploy automatiskt vid push

### Option 2: Netlify

**Steg:**

1. **Installera Netlify CLI**
```bash
npm install -g netlify-cli
```

2. **Logga in**
```bash
netlify login
```

3. **Init**
```bash
netlify init
```

4. **Sätt miljövariabler**
```bash
netlify env:set OPENAI_API_KEY "your_key"
netlify env:set ADMIN_PASSWORD "your_password"
```

5. **Deploy**
```bash
netlify deploy --prod
```

### Option 3: Docker

**Dockerfile:**
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 3000

CMD ["npm", "start"]
```

**Bygg och kör:**
```bash
docker build -t vinovate .
docker run -p 3000:3000 \
  -e OPENAI_API_KEY=xxx \
  -e ADMIN_PASSWORD=xxx \
  vinovate
```

### Option 4: VPS (DigitalOcean, AWS, etc.)

**Steg:**

1. **SSH till server**
```bash
ssh user@your-server.com
```

2. **Installera Node.js**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

3. **Klona repo**
```bash
git clone https://github.com/yourusername/vinovate.git
cd vinovate
```

4. **Installera dependencies**
```bash
npm install
```

5. **Sätt miljövariabler**
```bash
nano .env.local
# Lägg till OPENAI_API_KEY och ADMIN_PASSWORD
```

6. **Bygg**
```bash
npm run build
```

7. **Kör med PM2**
```bash
npm install -g pm2
pm2 start npm --name "vinovate" -- start
pm2 save
pm2 startup
```

8. **Nginx reverse proxy**
```nginx
server {
    listen 80;
    server_name vinovate.se;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Post-Deployment Checklist

### Säkerhet
- [ ] Ändra `ADMIN_PASSWORD` till ett starkt lösenord
- [ ] Aktivera HTTPS
- [ ] Sätt upp rate limiting
- [ ] Konfigurera CORS om nödvändigt
- [ ] Granska säkerhetsheaders

### Performance
- [ ] Verifiera att caching fungerar
- [ ] Testa bildoptimering
- [ ] Kör Lighthouse audit
- [ ] Sätt upp monitoring

### Funktionalitet
- [ ] Testa vinsökning
- [ ] Testa admin-inloggning
- [ ] Testa sponsor-aktivering
- [ ] Verifiera Systembolaget-länkar
- [ ] Testa "Hitta 5 nya"-funktionen

### SEO & Analytics
- [ ] Lägg till Google Analytics
- [ ] Konfigurera sitemap
- [ ] Lägg till robots.txt
- [ ] Verifiera meta tags

## Domän & DNS

### Köp domän
Rekommenderade registrars:
- Namecheap
- GoDaddy
- Loopia (Sverige)

### DNS-konfiguration för Vercel
```
A Record: @ → 76.76.21.21
CNAME: www → cname.vercel-dns.com
```

### SSL/HTTPS
- Vercel: Automatiskt
- Netlify: Automatiskt
- VPS: Använd Let's Encrypt (certbot)

## Monitoring & Underhåll

### Uptime Monitoring
- UptimeRobot (gratis)
- Pingdom
- StatusCake

### Error Tracking
- Sentry
- LogRocket
- Rollbar

### Analytics
- Google Analytics
- Plausible (privacy-friendly)
- Fathom

## Backup

### Databas (framtida)
```bash
# Automatisk backup varje dag
0 2 * * * pg_dump vinovate > backup-$(date +\%Y\%m\%d).sql
```

### Kod
- Använd Git
- Pusha till GitHub/GitLab
- Tagga releases

## Kostnader (Estimat)

### Gratis Tier
- **Vercel:** Gratis för hobby
- **Hosting:** 0 kr/mån
- **OpenAI:** Betala per användning (~500-2000 kr/mån)
- **Total:** ~500-2000 kr/mån

### Skalning
- **Vercel Pro:** $20/mån (~220 kr)
- **Database:** $15/mån (~165 kr)
- **OpenAI:** ~2000-5000 kr/mån
- **Total:** ~2400-5400 kr/mån

### Med Sponsorer
- **Kostnader:** ~2400 kr/mån
- **Intäkter:** 15,000-170,000 kr/mån
- **Vinst:** 12,600-167,600 kr/mån 💰

## Support

### Dokumentation
- README.md - Översikt
- QUICKSTART.md - Snabbstart
- DEPLOYMENT.md - Denna fil
- ENV_EXAMPLE.md - Miljövariabler

### Kontakt
📧 support@vinovate.se
📞 070-123 45 67

## Nästa Steg

Efter deployment:
1. ✅ Testa alla funktioner
2. ✅ Logga in på `/admin`
3. ✅ Aktivera första sponsorn
4. ✅ Börja marknadsföra!

**Lycka till med lanseringen! 🚀🍷**

