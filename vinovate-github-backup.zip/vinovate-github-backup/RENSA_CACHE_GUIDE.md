# 🔄 Guide: Rensa Webbläsarens Cache

## Problem
Webbläsaren visar gammal "Mock"-data trots att Vercel returnerar OpenAI-data.

## Verifiering (Fungerar!)
```bash
# Testa API direkt (fungerar perfekt):
curl -X POST https://vinovate-r5fryewlc-jorgen-lgtms-projects.vercel.app/api/ai-wine-search \
  -H "Content-Type: application/json" \
  -d '{"query":"rött spanien","maxResults":3}'

# Resultat: ✅ OpenAI-genererade viner med recept!
```

## Lösning: Rensa Cache

### Metod 1: Hard Refresh (Snabbast)
- **Windows/Linux:** `Ctrl + Shift + R`
- **Mac:** `Cmd + Shift + R`

### Metod 2: Developer Tools
1. Öppna Developer Tools: `F12`
2. Högerklicka på refresh-knappen
3. Välj "Empty Cache and Hard Reload"

### Metod 3: Inkognito-läge
1. Öppna en ny inkognito/privat flik
2. Gå till: https://vinovate-r5fryewlc-jorgen-lgtms-projects.vercel.app
3. Testa sökningen

### Metod 4: Manuell Cache-rensning
**Chrome/Edge:**
1. `Ctrl + Shift + Delete` (Windows) eller `Cmd + Shift + Delete` (Mac)
2. Välj "Cached images and files"
3. Välj tidsperiod: "Last 24 hours"
4. Klicka "Clear data"

**Firefox:**
1. `Ctrl + Shift + Delete`
2. Välj "Cache"
3. Klicka "Clear Now"

**Safari:**
1. `Cmd + Option + E` (töm cache)
2. Eller: Safari > Inställningar > Avancerat > Visa utvecklarmeny
3. Utvecklare > Töm cache

## Bekräftelse
Efter cache-rensning ska du se:
- ✅ **Källa: OpenAI** (grön text)
- ✅ **Recept** på rustik maträtt
- ✅ **Systembolaget-nummer** (6-7 siffror)
- ✅ **3 köpställen** (Systembolaget, Vinoteket, Winefinder)

## Senaste URL
https://vinovate-r5fryewlc-jorgen-lgtms-projects.vercel.app
