import { NextRequest, NextResponse } from "next/server";
import { getSponsoredWineForSearch } from "@/data/sponsoredImporters";
import { fetchSystembolagetProduct } from "@/lib/systembolaget";

export async function POST(request: NextRequest) {
  try {
    const { query, preferQuick } = await request.json();

    if (!query) {
      return NextResponse.json(
        { error: "Query is required" },
        { status: 400 }
      );
    }

    console.log("Simple search called with:", { query, preferQuick });
    
    // Check if this is a "get more results" request
    const isGetMore = query.includes("HELT ANDRA alternativ");

    // Extended wine database for variations
    const allMockWines = [
      {
        name: "Chianti Classico",
        producer: "Castello di Brolio",
        type: "Rött vin",
        country: "Italien",
        region: "Toscana",
        year: "2020",
        price: 189,
        rating: 88,
        systembolagetNumber: "87654",
        description: "Klassisk italiensk chianti med dofter av körsbär och kryddor. Mjuk och rund smak med bra struktur.",
        foodPairing: ["Pasta", "Kött", "Ost"],
        foodPairingDetails: [
          {
            dish: "Pasta Carbonara",
            description: "Klassisk italiensk pasta med krämig sås och pancetta.",
            why: "Chiantins syra och tanniner skär genom den krämiga såsen perfekt.",
            recipe: "Ingredienser (4 portioner):\n- 400 g spaghetti\n- 150 g pancetta, tärnad\n- 2 ägg\n- 50 g parmesanost, riven\n- Salt och peppar\n\nInstruktioner:\n1. Koka pastan al dente.\n2. Stek pancettan tills krispig.\n3. Vispa ihop ägg och parmesan.\n4. Blanda pastan med pancetta och äggblandningen.\n5. Smaka av med salt och peppar.\n\nTillagningstid: 20 minuter\nPro-tips: Tillsätt lite av pastavattnet för en krämigare sås."
          }
        ],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Röd frukt, kryddor och läder. Mjuk tannin.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 189,
            isPrivateImport: false
          },
          {
            name: "Systembolaget Online",
            type: "online",
            url: "https://www.systembolaget.se/sok-dryck",
            stock: "Tillgängligt online",
            price: 189,
            isPrivateImport: false
          }
        ],
            imageUrl: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Barolo",
        producer: "Gaja",
        type: "Rött vin",
        country: "Italien", 
        region: "Piemonte",
        year: "2019",
        price: 850,
        rating: 95,
        systembolagetNumber: "72345",
        description: "Exklusiv barolo från Gaja med kraftig struktur och komplexitet. Perfekt för lagring.",
        foodPairing: ["Kött", "Vilt", "Truffel"],
        foodPairingDetails: [
          {
            dish: "Rostbiff med rotselleripuré",
            description: "Klassisk rostbiff med krämig rotselleripuré och rödvinssås.",
            why: "Vinets kraftiga tanniner och komplexitet matchar rostbiffens rika smaker perfekt.",
            recipe: "Ingredienser (4 portioner):\n- 1 kg rostbiff\n- 500g rotselleri\n- 2 msk olivolja\n- 1 dl rött vin\n- 2 dl köttbuljong\n- 50g smör\n- Salt och peppar\n\nInstruktioner:\n1. Krydda köttet med salt och peppar.\n2. Stek köttet i olivolja tills önskad stekgrad.\n3. Koka rotselleri tills mjuk, mixa med smör till puré.\n4. Gör sås av vin och buljong.\n5. Servera med kött, puré och sås.\n\nTillagningstid: 45 minuter\nPro-tips: Låt köttet vila 10 minuter innan skärning."
          }
        ],
        availability: "better",
        tastingNotes: "Mörka bär, kryddor, mineralitet. Kraftig struktur.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 850,
            isPrivateImport: false
          },
          {
            name: "Systembolaget Online",
            type: "online",
            url: "https://www.systembolaget.se/sok-dryck",
            stock: "Tillgängligt online",
            price: 850,
            isPrivateImport: false
          },
          {
            name: "Vinguiden",
            type: "private-import",
            url: "https://vinguiden.se",
            stock: "I lager",
            price: 750,
            savings: 100,
            isPrivateImport: true,
            minimumOrder: "6 flaskor",
            importerContact: {
              email: "info@vinguiden.se",
              phone: "08-123 45 67",
              orderUrl: "https://vinguiden.se/bestall"
            }
          }
        ],
        imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Brunello di Montalcino",
        producer: "Banfi",
        type: "Rött vin",
        country: "Italien",
        region: "Toscana", 
        year: "2018",
        price: 320,
        rating: 92,
        systembolagetNumber: "67890",
        description: "Elegant brunello med dofter av mörka bär och kryddor. Perfekt balans mellan kraft och elegans.",
        foodPairing: ["Kött", "Vilt", "Ost"],
        foodPairingDetails: [
          {
            dish: "Viltgryta med rotfrukter",
            description: "Mör viltkött gryta med rotfrukter och örter.",
            why: "Brunellons eleganta struktur och kryddiga toner kompletterar vildsvinsköttets djupa smaker.",
            recipe: "Ingredienser (4 portioner):\n- 1 kg viltkött\n- 2 msk olivolja\n- 2 morötter, skivade\n- 2 selleristjälkar, skivade\n- 1 lök, hackad\n- 1 dl rött vin\n- 3 dl viltbuljong\n- 2 msk färska örter\n\nInstruktioner:\n1. Bryn viltköttet i olivolja.\n2. Tillsätt lök, morötter och selleri, fräs tills mjuka.\n3. Häll i vin och buljong, tillsätt örter.\n4. Låt sjuda på låg värme i 2 timmar.\n5. Smaka av med salt och peppar.\n\nTillagningstid: 2,5 timmar\nPro-tips: Servera med potatismos för en klassisk kombination."
          }
        ],
        availability: "better",
        tastingNotes: "Mörka bär, kryddor, läder. Elegant struktur.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 320,
            isPrivateImport: false
          },
          {
            name: "Systembolaget Online",
            type: "online",
            url: "https://www.systembolaget.se/sok-dryck",
            stock: "Tillgängligt online",
            price: 320,
            isPrivateImport: false
          }
        ],
            imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Amarone della Valpolicella",
        producer: "Allegrini",
        type: "Rött vin",
        country: "Italien",
        region: "Veneto",
        year: "2017",
        price: 380,
        rating: 90,
        systembolagetNumber: "54321",
        description: "Kraftig amarone med rik smak av torkad frukt och kryddor. Perfekt till rött kött.",
        foodPairing: ["Kött", "Vilt", "Ost"],
        foodPairingDetails: [
          {
            dish: "Grillad entrecôte",
            description: "Saftig entrecôte grillad till perfektion.",
            why: "Amaronens kraftfulla struktur och torkade fruktkaraktär kompletterar grillat kött perfekt.",
            recipe: "Ingredienser (4 portioner):\n- 4 skivor entrecôte\n- 2 msk olivolja\n- Salt och peppar\n- Rosmarin\n\nInstruktioner:\n1. Krydda köttet med salt och peppar.\n2. Pensla med olivolja och rosmarin.\n3. Grilla på hög värme 3-4 minuter per sida.\n4. Låt vila 5 minuter innan servering.\n\nTillagningstid: 20 minuter\nPro-tips: Använd en grilltermometer för att nå önskad innertemperatur."
          }
        ],
        availability: "better", 
        tastingNotes: "Torkad frukt, kryddor, choklad. Kraftig och rund.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i utvalda butiker",
            price: 380,
            isPrivateImport: false
          },
          {
            name: "Systembolaget Online",
            type: "online",
            url: "https://www.systembolaget.se/sok-dryck",
            stock: "Tillgängligt online",
            price: 380,
            isPrivateImport: false
          },
          {
            name: "Winepeople",
            type: "private-import",
            url: "https://winepeople.se",
            stock: "I lager",
            price: 320,
            savings: 60,
            isPrivateImport: true,
            minimumOrder: "12 flaskor",
            importerContact: {
              email: "bestall@winepeople.se",
              phone: "031-123 45 67", 
              orderUrl: "https://winepeople.se/order"
            }
          }
        ],
            imageUrl: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Nebbiolo d'Alba",
        producer: "Vietti",
        type: "Rött vin",
        country: "Italien",
        region: "Piemonte",
        year: "2021",
        price: 165,
        rating: 87,
        systembolagetNumber: "98765",
        description: "Klassisk nebbiolo med dofter av ros och kryddor. Elegant och balanserad.",
        foodPairing: ["Pasta", "Kött", "Ost"],
        foodPairingDetails: [
          {
            dish: "Risotto med svamp",
            description: "Krämig risotto med smakrika svampar.",
            why: "Nebbiolons eleganta tanniner och syra balanserar den krämiga konsistensen och umami-smaken från svampen.",
            recipe: "Ingredienser (4 portioner):\n- 300 g arborioris\n- 200 g svamp, skivade\n- 1 lök, hackad\n- 1 dl vitt vin\n- 1 liter grönsaksbuljong\n- 50 g parmesanost, riven\n- 2 msk smör\n\nInstruktioner:\n1. Fräs lök och svamp i smör.\n2. Tillsätt riset och rör om.\n3. Häll i vinet och låt det koka in.\n4. Tillsätt buljong, lite i taget, tills riset är krämigt.\n5. Rör ner parmesan och smaka av med salt och peppar.\n\nTillagningstid: 30 minuter\nPro-tips: Använd torkade svampar för mer intensiv smak."
          }
        ],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Ros, kryddor, mineralitet. Elegant tannin.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 165,
            isPrivateImport: false
          },
          {
            name: "Systembolaget Online",
            type: "online",
            url: "https://www.systembolaget.se/sok-dryck",
            stock: "Tillgängligt online",
            price: 165,
            isPrivateImport: false
          }
        ],
            imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
      },
      // Additional wines for "get more" variations
      {
        name: "Barbera d'Alba",
        producer: "Prunotto",
        type: "Rött vin",
        country: "Italien",
        region: "Piemonte",
        year: "2021",
        price: 145,
        rating: 86,
        systembolagetNumber: "12345", // Realistic Systembolaget number
        description: "Fruktig och fräsch Barbera med god syra. Perfekt till vardagsmaten.",
        foodPairing: ["Pizza", "Pasta", "Charkuterier"],
        foodPairingDetails: [
          {
            dish: "Pizza Margherita",
            description: "Klassisk pizza med tomat, mozzarella och basilika.",
            why: "Vinets syra och fruktighet kompletterar tomatens sötma och ostens krämighet.",
            recipe: "Ingredienser (4 portioner):\n- 500g pizzadeg\n- 200g krossade tomater\n- 200g mozzarella\n- Färsk basilika\n- Olivolja\n\nInstruktioner:\n1. Kavla ut degen.\n2. Bred på tomatsås.\n3. Lägg på mozzarella.\n4. Grädda i 250°C i 10-12 minuter.\n5. Toppa med basilika.\n\nTillagningstid: 25 minuter\nPro-tips: Förvärm ugnen ordentligt för krispig botten."
          }
        ],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Körsbär, plommon, kryddor. Fräsch syra.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 145,
            isPrivateImport: false
          }
        ],
        imageUrl: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Valpolicella Ripasso",
        producer: "Zenato",
        type: "Rött vin",
        country: "Italien",
        region: "Veneto",
        year: "2020",
        price: 195,
        rating: 89,
        systembolagetNumber: "45678", // Realistic Systembolaget number
        description: "Ripasso-teknik ger extra djup och komplexitet. Körsbär och kryddor.",
        foodPairing: ["Pasta", "Kött", "Ost"],
        foodPairingDetails: [
          {
            dish: "Ossobuco",
            description: "Klassisk milansk kalvgryta med saffransrisotto.",
            why: "Vinets struktur och fruktighet balanserar den rika grytan perfekt.",
            recipe: "Ingredienser (4 portioner):\n- 4 kalvskank\n- 2 msk olivolja\n- 1 lök, hackad\n- 2 morötter\n- 1 dl vitt vin\n- 400g krossade tomater\n- Buljong\n\nInstruktioner:\n1. Bryn kalvskanken.\n2. Fräs grönsaker.\n3. Häll i vin och tomater.\n4. Sjud i 2 timmar.\n\nTillagningstid: 2,5 timmar\nPro-tips: Servera med gremolata."
          }
        ],
        availability: "better",
        tastingNotes: "Körsbär, kryddor, choklad. Mjuk struktur.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i utvalda butiker",
            price: 195,
            isPrivateImport: false
          }
        ],
            imageUrl: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Primitivo di Manduria",
        producer: "Feudi di San Marzano",
        type: "Rött vin",
        country: "Italien",
        region: "Puglia",
        year: "2021",
        price: 125,
        rating: 85,
        systembolagetNumber: "23456", // Realistic Systembolaget number
        description: "Kraftig och fruktig Primitivo från södra Italien. Mörka bär och kryddor.",
        foodPairing: ["BBQ", "Kött", "Pizza"],
        foodPairingDetails: [
          {
            dish: "BBQ Ribs",
            description: "Grillad revbensspjäll med BBQ-sås.",
            why: "Vinets fruktighet och kraft står emot den söta och kryddiga BBQ-såsen.",
            recipe: "Ingredienser (4 portioner):\n- 2 kg revbensspjäll\n- BBQ-sås\n- Kryddor\n\nInstruktioner:\n1. Krydda revbenen.\n2. Grilla långsamt i 2 timmar.\n3. Pensla med BBQ-sås.\n4. Grilla till karamelliserad yta.\n\nTillagningstid: 2,5 timmar\nPro-tips: Låg värme ger mört kött."
          }
        ],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Mörka bär, choklad, vanilj. Kraftig och rund.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 125,
            isPrivateImport: false
          }
        ],
            imageUrl: "https://images.unsplash.com/photo-1547595628-c61a29f496f0?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Montepulciano d'Abruzzo",
        producer: "Masciarelli",
        type: "Rött vin",
        country: "Italien",
        region: "Abruzzo",
        year: "2021",
        price: 99,
        rating: 84,
        systembolagetNumber: "78901", // Realistic Systembolaget number
        description: "Prisvärt italienskt rödvin med god struktur. Körsbär och kryddor.",
        foodPairing: ["Pasta", "Pizza", "Kött"],
        foodPairingDetails: [
          {
            dish: "Spaghetti Bolognese",
            description: "Klassisk köttfärssås med spaghetti.",
            why: "Vinets syra och tanniner kompletterar den rika köttfärssåsen.",
            recipe: "Ingredienser (4 portioner):\n- 400g spaghetti\n- 500g köttfärs\n- 1 lök\n- 400g krossade tomater\n- Vitlök, basilika\n\nInstruktioner:\n1. Bryn köttfärsen.\n2. Tillsätt lök och vitlök.\n3. Häll i tomater, sjud 30 min.\n4. Koka pastan, blanda.\n\nTillagningstid: 45 minuter\nPro-tips: Låt såsen sjuda länge för bästa smak."
          }
        ],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Körsbär, plommon, kryddor. God struktur.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 99,
            isPrivateImport: false
          }
        ],
            imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
      },
      // FRANKRIKE — Lägg till flera franska röda viner för bättre träffsäkerhet
      {
        name: "Bordeaux Supérieur",
        producer: "Château Haut-Médoc",
        type: "Rött vin",
        country: "Frankrike",
        region: "Bordeaux",
        year: "2020",
        price: 159,
        rating: 89,
        systembolagetNumber: "11223",
        description: "Klassisk Bordeaux med svarta vinbär, ceder och fin struktur.",
        foodPairing: ["Rött kött", "Lamm", "Hårda ostar"],
        foodPairingDetails: [],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Svarta vinbär, ceder, tobak. Medelfyllig med tydliga tanniner.",
        purchaseLocations: [
          { name: "Systembolaget", type: "store", url: "https://www.systembolaget.se", stock: "Finns i de flesta butiker", price: 159, isPrivateImport: false }
        ],
        imageUrl: "https://images.unsplash.com/photo-1547595628-c61a29f496f0?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Bourgogne Pinot Noir",
        producer: "Louis Jadot",
        type: "Rött vin",
        country: "Frankrike",
        region: "Bourgogne",
        year: "2021",
        price: 229,
        rating: 90,
        systembolagetNumber: "33445",
        description: "Elegant Pinot Noir med röda bär, kryddor och silkiga tanniner.",
        foodPairing: ["Kyckling", "Fläsk", "Svamp"],
        foodPairingDetails: [],
        availability: "better",
        tastingNotes: "Hallon, körsbär, skogsgolv. Frisk syra och mjuka tanniner.",
        purchaseLocations: [
          { name: "Systembolaget", type: "store", url: "https://www.systembolaget.se", stock: "Finns i utvalda butiker", price: 229, isPrivateImport: false }
        ],
        imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Côtes du Rhône",
        producer: "Guigal",
        type: "Rött vin",
        country: "Frankrike",
        region: "Rhône",
        year: "2020",
        price: 139,
        rating: 88,
        systembolagetNumber: "55667",
        description: "Fylligt Rhône-vin med mörka bär, peppar och örter.",
        foodPairing: ["Grillat", "Lamm", "Pizza"],
        foodPairingDetails: [],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Mörka bär, vitpeppar, örter. Fylligt och balanserat.",
        purchaseLocations: [
          { name: "Systembolaget", type: "store", url: "https://www.systembolaget.se", stock: "Finns i de flesta butiker", price: 139, isPrivateImport: false }
        ],
        imageUrl: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300&h=400&fit=crop&auto=format&q=80"
      },
      // VITA VINER
      {
        name: "Chablis Premier Cru",
        producer: "Domaine Louis Michel",
        type: "Vitt vin",
        country: "Frankrike",
        region: "Bourgogne",
        year: "2021",
        price: 299,
        rating: 92,
        systembolagetNumber: "11223",
        description: "Elegant Chablis med mineralitet och frisk syra. Perfekt till fisk och skaldjur.",
        foodPairing: ["Fisk", "Skaldjur", "Ost"],
        foodPairingDetails: [
          {
            dish: "Grillad lax",
            description: "Färsk lax grillad med citron och dill.",
            why: "Vinets mineralitet kompletterar laxens feta smak perfekt.",
            recipe: "Ingredienser (4 portioner):\n- 4 laxfiléer\n- 2 msk olivolja\n- 1 citron\n- Färsk dill\n- Salt och peppar\n\nInstruktioner:\n1. Pensla laxen med olivolja.\n2. Krydda med salt och peppar.\n3. Grilla 4-5 minuter per sida.\n4. Pressa över citron och strö dill.\n\nTillagningstid: 15 minuter\nPro-tips: Låt fisken vila 2 minuter innan servering."
          }
        ],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Mineralitet, gröna äpplen, citrus. Frisk syra.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i utvalda butiker",
            price: 299,
            isPrivateImport: false
          }
        ],
        imageUrl: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Sancerre",
        producer: "Domaine Vacheron",
        type: "Vitt vin",
        country: "Frankrike",
        region: "Loire",
        year: "2022",
        price: 249,
        rating: 90,
        systembolagetNumber: "33445",
        description: "Klassisk Sancerre med dofter av stenfrukter och mineralitet. Elegant och balanserad.",
        foodPairing: ["Fisk", "Skaldjur", "Getost"],
        foodPairingDetails: [
          {
            dish: "Vit fisk med citronsås",
            description: "Tunnfilé av vit fisk med krämig citronsås.",
            why: "Vinets syra och mineralitet balanserar den krämiga såsen.",
            recipe: "Ingredienser (4 portioner):\n- 4 fiskfiléer\n- 2 dl grädde\n- 1 citron\n- 2 msk smör\n- Salt och peppar\n\nInstruktioner:\n1. Stek fisken i smör.\n2. Tillsätt grädde och citronjuice.\n3. Låt koka ihop till sås.\n4. Smaka av med salt och peppar.\n\nTillagningstid: 20 minuter\nPro-tips: Använd färsk citron för bästa smak."
          }
        ],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Stenfrukter, mineralitet, citrus. Elegant struktur.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 249,
            isPrivateImport: false
          }
        ],
        imageUrl: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=300&h=400&fit=crop&auto=format&q=80"
      },
      {
        name: "Riesling Trocken",
        producer: "Dr. Loosen",
        type: "Vitt vin",
        country: "Tyskland",
        region: "Mosel",
        year: "2021",
        price: 179,
        rating: 88,
        systembolagetNumber: "55667",
        description: "Torr Riesling med perfekt balans mellan syra och fruktighet. Mineralitet och citrus.",
        foodPairing: ["Asiatisk mat", "Fisk", "Kyckling"],
        foodPairingDetails: [
          {
            dish: "Sushi",
            description: "Traditionell japansk mat med ris och fisk.",
            why: "Vinets syra och mineralitet kompletterar sushins rena smaker.",
            recipe: "Ingredienser (4 portioner):\n- 200g sushiris\n- 100g lax\n- 1 avokado\n- Noriark\n- Soja och wasabi\n\nInstruktioner:\n1. Koka riset enligt anvisning.\n2. Skär lax och avokado i tunna skivor.\n3. Lägg riset på nori.\n4. Tillsätt fisk och avokado.\n5. Rulla ihop och skär i bitar.\n\nTillagningstid: 30 minuter\nPro-tips: Använd färsk fisk av hög kvalitet."
          }
        ],
        availability: preferQuick ? "quick" : "better",
        tastingNotes: "Citrus, mineralitet, gröna äpplen. Frisk syra.",
        purchaseLocations: [
          {
            name: "Systembolaget",
            type: "store",
            url: "https://www.systembolaget.se",
            stock: "Finns i de flesta butiker",
            price: 179,
            isPrivateImport: false
          }
        ],
        imageUrl: "https://images.unsplash.com/photo-1547595628-c61a29f496f0?w=300&h=400&fit=crop&auto=format&q=80"
      }
    ];

    // Apply simple intent filtering from free text (country, type, grape keywords)
    const q = query.toLowerCase();
    
    // Explicit wine type mentions
    const wantsRed = /(rött|rott|red)/.test(q);
    const wantsWhite = /(vitt|white)/.test(q);
    const wantsRose = /(rosé|rose)/.test(q);
    const wantsSparkling = /(mousserande|champagne|cava|prosecco|sparkling)/.test(q);
    
    // Red wine names and contexts that imply red wine
    const redWineContext = /(barolo|amarone|brunello|chianti|bordeaux|cabernet|merlot|syrah|primitivo|montepulciano|nebbiolo|barbera|valpolicella|viltkött|vilt|oxfilé|lammstek|gryta|ragu|kraftfullt|fylligt)/.test(q);
    
    // White wine names and contexts that imply white wine
    const whiteWineContext = /(chablis|sancerre|riesling|sauvignon blanc|chardonnay|albariño|pinot grigio|fisk|skaldjur|ostron)/.test(q);
    
    // Specific wine/region mentions that should be prioritized
    const specificWineMentions = {
      // Italian wines
      barolo: { country: "Italien", region: "Piemonte", type: "Rött vin" },
      amarone: { country: "Italien", region: "Veneto", type: "Rött vin" },
      brunello: { country: "Italien", region: "Toscana", type: "Rött vin" },
      chianti: { country: "Italien", region: "Toscana", type: "Rött vin" },
      nebbiolo: { country: "Italien", region: "Piemonte", type: "Rött vin" },
      barbera: { country: "Italien", region: "Piemonte", type: "Rött vin" },
      valpolicella: { country: "Italien", region: "Veneto", type: "Rött vin" },
      primitivo: { country: "Italien", region: "Puglia", type: "Rött vin" },
      montepulciano: { country: "Italien", region: "Abruzzo", type: "Rött vin" },
      
      // French wines
      bordeaux: { country: "Frankrike", region: "Bordeaux", type: "Rött vin" },
      bourgogne: { country: "Frankrike", region: "Bourgogne", type: "Rött vin" },
      cotes: { country: "Frankrike", region: "Rhône", type: "Rött vin" },
      chablis: { country: "Frankrike", region: "Bourgogne", type: "Vitt vin" },
      sancerre: { country: "Frankrike", region: "Loire", type: "Vitt vin" },
      
      // Other wines
      riesling: { country: "Tyskland", region: "Mosel", type: "Vitt vin" }
    };
    
    // Find specific wine mention
    let specificWine = null;
    for (const [wineName, wineInfo] of Object.entries(specificWineMentions)) {
      if (q.includes(wineName)) {
        specificWine = wineInfo;
        break;
      }
    }
    
    // Determine implied wine type from context
    let impliedRed = redWineContext && !wantsWhite && !wantsSparkling && !wantsRose;
    let impliedWhite = whiteWineContext && !wantsRed && !wantsSparkling && !wantsRose;
    
    
    const countryMap: Record<string, string> = {
      frankrike: "Frankrike",
      france: "Frankrike",
      italien: "Italien",
      italy: "Italien",
      spanien: "Spanien",
      spain: "Spanien",
    };
    let desiredCountry: string | null = null;
    for (const [needle, country] of Object.entries(countryMap)) {
      if (q.includes(needle)) { desiredCountry = country; break; }
    }

    let filteredByQuery = allMockWines.filter((w) => {
      // If we have a specific wine mention, prioritize exact matches
      if (specificWine) {
        // Must match country, region, and type for specific wine mentions
        if (w.country !== specificWine.country || w.type !== specificWine.type) {
          return false;
        }
        // If region is specified, prefer wines from that region
        if (specificWine.region && !w.region.toLowerCase().includes(specificWine.region.toLowerCase())) {
          return false;
        }
        return true;
      }
      
      // General country filtering
      if (desiredCountry && w.country !== desiredCountry) return false;
      
      // Strict wine type filtering (explicit mentions)
      if (wantsWhite && w.type !== "Vitt vin") return false;
      if (wantsRed && w.type !== "Rött vin") return false;
      if (wantsRose && w.type !== "Rosévin") return false;
      if (wantsSparkling && w.type !== "Mousserande vin") return false;
      
      // Context-based filtering (implied from food pairing or wine names)
      if (impliedRed && w.type !== "Rött vin") return false;
      if (impliedWhite && w.type !== "Vitt vin") return false;
      
      return true;
    });
    
    
    // If no matches for specific type, return empty array instead of fallback
    if (filteredByQuery.length === 0) {
      filteredByQuery = [];
    }

    // Select different wines based on whether it's a "get more" request
    let mockWines;
    if (isGetMore) {
      // Show different slice for "get more" requests
      mockWines = filteredByQuery.slice(5);
      // If we don't have enough, shuffle and take from beginning
      if (mockWines.length < 5) {
        const shuffled = [...filteredByQuery].sort(() => Math.random() - 0.5);
        mockWines = shuffled;
      }
    } else {
      // Show filtered wines for initial search (client can further filter)
      mockWines = filteredByQuery;
    }

    // Add sponsored wine at the beginning that matches the search query
        // Try to get real Systembolaget article numbers for wines
        const winesWithRealNumbers = await Promise.all(
          mockWines.map(async (wine) => {
            try {
              const systembolagetData = await fetchSystembolagetProduct(wine.name, wine.producer);
              if (systembolagetData && systembolagetData.productNumber) {
                return {
                  ...wine,
                  systembolagetNumber: systembolagetData.productNumber,
                  price: systembolagetData.price || wine.price,
                  imageUrl: systembolagetData.imageUrl || wine.imageUrl,
                };
              }
            } catch (error) {
              console.error("Failed to fetch Systembolaget data for", wine.name, error);
            }
            return wine;
          })
        );

        const sponsoredWine = getSponsoredWineForSearch(query);
        const finalWines = sponsoredWine ? [sponsoredWine, ...winesWithRealNumbers] : winesWithRealNumbers;

        return NextResponse.json({ 
          wines: finalWines,
          cached: false,
          message: "Mock data with real Systembolaget numbers where available",
          hasSponsored: !!sponsoredWine
        });
  } catch (error) {
    console.error("Error in simple wine search:", error);
    return NextResponse.json(
      { error: "Failed to search for wines" },
      { status: 500 }
    );
  }
}
