import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const { wineName, producer } = await request.json();

    if (!wineName) {
      return NextResponse.json(
        { error: "Wine name is required" },
        { status: 400 }
      );
    }

    // Try to search for wine image on Systembolaget
    // Note: This is a mock implementation since Systembolaget's API requires authentication
    // In production, you would need to:
    // 1. Register for API access with Systembolaget
    // 2. Implement proper authentication
    // 3. Use their search API to find products
    // 4. Extract image URLs from the response

    const searchQuery = `${wineName} ${producer || ""}`.trim();
    
    // Try to find wine images from various sources
    // For now, we'll use a more sophisticated placeholder system
    
    // Generate a wine-themed placeholder based on wine type
    const wineType = wineName.toLowerCase();
    let placeholderType = "generic";
    
    if (wineType.includes("champagne") || wineType.includes("prosecco")) {
      placeholderType = "sparkling";
    } else if (wineType.includes("rosé") || wineType.includes("rose")) {
      placeholderType = "rose";
    } else if (wineType.includes("white") || wineType.includes("vit")) {
      placeholderType = "white";
    } else if (wineType.includes("red") || wineType.includes("röd")) {
      placeholderType = "red";
    }
    
    // Return a wine-themed placeholder URL
    const placeholderImage = `https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop&auto=format&q=80`;
    
    return NextResponse.json({ 
      imageUrl: placeholderImage,
      source: "unsplash",
      wineType: placeholderType,
      note: "Using wine-themed placeholder image"
    });

  } catch (error) {
    console.error("Error fetching wine image:", error);
    return NextResponse.json(
      { error: "Failed to fetch wine image" },
      { status: 500 }
    );
  }
}

// Helper function for future implementation
async function searchSystembolagetImage(searchQuery: string): Promise<string | null> {
  // TODO: Implement real Systembolaget API integration
  // 1. Make authenticated request to Systembolaget API
  // 2. Parse response and extract image URL
  // 3. Return image URL or null
  
  return null;
}

