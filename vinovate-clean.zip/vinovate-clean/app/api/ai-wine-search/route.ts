import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { 
  getCachedResult, 
  cacheSearchResult, 
  recordCacheHit, 
  recordCacheMiss 
} from "@/lib/searchCache";

// Initialize OpenAI only if API key is available
const openai = process.env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

// Smart fallback function for when OpenAI is not available
function generateSmartWineFallback(query: string, wineType: string, maxResults: number) {
  const q = query.toLowerCase();
  
  // Detect country from query
  const countryKeywords = {
    'frankrike': 'Frankrike',
    'france': 'Frankrike', 
    'italien': 'Italien',
    'italy': 'Italien',
    'spanien': 'Spanien',
    'spain': 'Spanien',
    'tyskland': 'Tyskland',
    'germany': 'Tyskland',
    'österrike': 'Österrike',
    'austria': 'Österrike',
    'portugal': 'Portugal',
    'grekland': 'Grekland',
    'greece': 'Grekland',
    'indien': 'Indien',
    'india': 'Indien',
    'australien': 'Australien',
    'australia': 'Australien',
    'chile': 'Chile',
    'argentina': 'Argentina',
    'sydafrika': 'Sydafrika',
    'south africa': 'Sydafrika',
    'nya zeeland': 'Nya Zeeland',
    'new zealand': 'Nya Zeeland',
    'usa': 'USA',
    'amerika': 'USA',
    'danmark': 'Danmark',
    'denmark': 'Danmark'
  };
  
  let detectedCountry = null;
  for (const [keyword, country] of Object.entries(countryKeywords)) {
    if (q.includes(keyword)) {
      detectedCountry = country;
      break;
    }
  }
  
  // Wine database with correct countries
  const wineDatabase = [
    // Danish wines
    {
      name: "Rødvin fra Dyrehøj Vingård",
      producer: "Dyrehøj Vingård",
      country: "Danmark",
      region: "Møn",
      type: "Rött vin",
      grape: "Rondo",
      price: 295,
      rating: 85,
      description: "Dansk röd vin med bärtoner och kryddig karaktär från Danmarks största vingård.",
      foodPairing: ["Kött", "Ost", "Grillat"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "Nu-2026",
      tastingNotes: "Mörka bär, kryddor, medelhög syra",
      availability: "better" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "Beställningsvara", price: 295, isPrivateImport: false }
      ]
    },
    {
      name: "Frederiksdal Kirsebærvin",
      producer: "Frederiksdal",
      country: "Danmark",
      region: "Lolland",
      type: "Rött vin",
      grape: "Körsbär",
      price: 245,
      rating: 88,
      description: "Unik dansk körsbärsvin från Lolland, söt och fruktig.",
      foodPairing: ["Dessert", "Ost", "Choklad"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "Nu-2027",
      tastingNotes: "Sötkörsbär, lätt sötma, elegant finish",
      availability: "better" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "Beställningsvara", price: 245, isPrivateImport: false }
      ]
    },
    // Italian wines
    {
      name: "Chianti Classico",
      producer: "Castello di Ama",
      country: "Italien",
      region: "Toscana",
      type: "Rött vin",
      grape: "Sangiovese",
      price: 245,
      rating: 90,
      description: "Klassisk Chianti med god struktur och elegans.",
      foodPairing: ["Pasta", "Kött", "Ost"],
      systembolagetNumber: "7234",
      imageUrl: undefined,
      drinkingPeriod: "Nu-2028",
      tastingNotes: "Körsbär, läder, tobak",
      availability: "quick" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "I lager", price: 245, isPrivateImport: false }
      ]
    },
    // French wines
    {
      name: "Châteauneuf-du-Pape",
      producer: "Domaine du Vieux Télégraphe",
      country: "Frankrike",
      region: "Rhône",
      type: "Rött vin",
      grape: "Grenache, Syrah, Mourvèdre",
      price: 395,
      rating: 93,
      description: "Kraftfullt rött från södra Rhône med komplex karaktär.",
      foodPairing: ["Kött", "Vilt", "Gryta"],
      systembolagetNumber: "7892",
      imageUrl: undefined,
      drinkingPeriod: "Nu-2030",
      tastingNotes: "Mörka bär, kryddor, läder",
      availability: "quick" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "I lager", price: 395, isPrivateImport: false }
      ]
    },
    // USA wines
    {
      name: "Napa Valley Cabernet Sauvignon",
      producer: "Stag's Leap Wine Cellars",
      country: "USA",
      region: "Napa Valley",
      type: "Rött vin",
      grape: "Cabernet Sauvignon",
      price: 850,
      rating: 94,
      description: "Klassisk Napa Valley Cabernet med kraftfull struktur och mörka bärtoner.",
      foodPairing: ["Kött", "Vilt", "Ost"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "2025-2030",
      tastingNotes: "Mörka bär, vanilj, ekar, kraftfull struktur",
      availability: "better" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "Beställningsvara", price: 850, isPrivateImport: false }
      ]
    },
    {
      name: "Sonoma Coast Chardonnay",
      producer: "Kendall-Jackson",
      country: "USA",
      region: "Sonoma Coast",
      type: "Vitt vin",
      grape: "Chardonnay",
      price: 295,
      rating: 88,
      description: "Elegant kalifornisk Chardonnay med mineralitet och frisk syra.",
      foodPairing: ["Fisk", "Skaldjur", "Kyckling"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "Nu-2027",
      tastingNotes: "Citrus, mineralitet, frisk syra, elegant finish",
      availability: "quick" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "I lager", price: 295, isPrivateImport: false }
      ]
    },
    {
      name: "Sancerre Les Romains",
      producer: "Domaine Vacheron",
      country: "Frankrike",
      region: "Loire",
      type: "Vitt vin",
      grape: "Sauvignon Blanc",
      price: 385,
      rating: 92,
      description: "Klassisk Sancerre med mineralitet och frisk citrus. Perfekt till fisk och skaldjur.",
      foodPairing: ["Räkor", "Fisk", "Skaldjur", "Ost"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "Nu-2028",
      tastingNotes: "Grapefrukt, mineralitet, frisk syra, elegant finish",
      availability: "better" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "Beställningsvara", price: 385, isPrivateImport: false }
      ]
    },
    {
      name: "Gavi di Gavi",
      producer: "La Scolca",
      country: "Italien",
      region: "Piemonte",
      type: "Vitt vin",
      grape: "Cortese",
      price: 245,
      rating: 89,
      description: "Italienskt vitt vin med mineralitet och friskhet. Utmärkt till lättare mat.",
      foodPairing: ["Räkor", "Fisk", "Kyckling", "Pasta"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "Nu-2026",
      tastingNotes: "Citrus, mineralitet, frisk syra, ren finish",
      availability: "quick" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "I lager", price: 245, isPrivateImport: false }
      ]
    },
    {
      name: "Riesling Kabinett",
      producer: "Dr. Loosen",
      country: "Tyskland",
      region: "Mosel",
      type: "Vitt vin",
      grape: "Riesling",
      price: 189,
      rating: 87,
      description: "Klassisk tysk Riesling med friskhet och mineralitet. Perfekt till asiatisk mat.",
      foodPairing: ["Räkor", "Fisk", "Asiatisk mat", "Ost"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "Nu-2030",
      tastingNotes: "Äpplen, citrus, mineralitet, frisk syra",
      availability: "quick" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "I lager", price: 189, isPrivateImport: false }
      ]
    },
    {
      name: "Albariño Rías Baixas",
      producer: "Burgans",
      country: "Spanien",
      region: "Rías Baixas",
      type: "Vitt vin",
      grape: "Albariño",
      price: 159,
      rating: 85,
      description: "Spanskt vitt vin med havsinfluenser och friskhet. Utmärkt till skaldjur.",
      foodPairing: ["Räkor", "Skaldjur", "Fisk", "Tapas"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "Nu-2025",
      tastingNotes: "Citrus, mineralitet, havstoner, frisk syra",
      availability: "quick" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "I lager", price: 159, isPrivateImport: false }
      ]
    },
    {
      name: "Willamette Valley Pinot Noir",
      producer: "Domaine Drouhin Oregon",
      country: "USA",
      region: "Willamette Valley",
      type: "Rött vin",
      grape: "Pinot Noir",
      price: 450,
      rating: 91,
      description: "Oregon Pinot Noir med elegans och komplexitet från Willamette Valley.",
      foodPairing: ["Lax", "Kyckling", "Svamp"],
      systembolagetNumber: undefined,
      imageUrl: undefined,
      drinkingPeriod: "Nu-2028",
      tastingNotes: "Röda bär, kryddor, mjuka tanniner, elegant struktur",
      availability: "better" as const,
      purchaseLocations: [
        { name: "Systembolaget", type: "store" as const, url: "https://systembolaget.se", stock: "Beställningsvara", price: 450, isPrivateImport: false }
      ]
    }
  ];
  
  // Filter by detected country
  let filteredWines = wineDatabase;
  
  if (detectedCountry) {
    filteredWines = wineDatabase.filter(w => w.country === detectedCountry);
  } else {
    // Fallback to old logic if no country detected
    if (q.includes("danmark") || q.includes("danish") || q.includes("danska")) {
      filteredWines = wineDatabase.filter(w => w.country === "Danmark");
    } else if (q.includes("italien") || q.includes("italian") || q.includes("italienska")) {
      filteredWines = wineDatabase.filter(w => w.country === "Italien");
    } else if (q.includes("frankrike") || q.includes("french") || q.includes("franska")) {
      filteredWines = wineDatabase.filter(w => w.country === "Frankrike");
    }
  }
  
  // Filter by wine type
  if (wineType && wineType !== "alla") {
    filteredWines = filteredWines.filter(w => 
      w.type.toLowerCase().includes(wineType.toLowerCase())
    );
  }
  
  // Return requested number of wines
  return filteredWines.slice(0, Math.min(maxResults, filteredWines.length));
}

export async function POST(request: NextRequest) {
  let query: string = '';
  let preferQuick: boolean = true;
  let maxResults: number = 5;
  
  try {
    const requestData = await request.json();
    query = requestData.query;
    preferQuick = requestData.preferQuick ?? true;
    maxResults = requestData.maxResults ?? 5;

    if (!query || query.trim().length === 0) {
      return NextResponse.json(
        { error: "Sökfråga krävs" },
        { status: 400 }
      );
    }

    console.log("AI Wine Search called with:", { query, preferQuick, maxResults });

    // Check cache first
    const cacheKey = `${query}-${preferQuick}-${maxResults}`;
    const cached = getCachedResult(cacheKey, { preferQuick, maxResults }, 'ai-wine');
    if (cached && cached.results.wines) {
      recordCacheHit();
      return NextResponse.json({ 
        wines: cached.results.wines,
        cached: true,
        hitCount: cached.hitCount,
        query: query,
        aiGenerated: true
      });
    }
    
    recordCacheMiss();

    // Infer desired wine type from query (sv/en)
    const q = query.toLowerCase();
    
    // Explicit wine type mentions
    const wantsWhite = /(vitt|white)/.test(q);
    const wantsRed = /(rött|rott|red)/.test(q);
    const wantsRose = /(rosé|rose)/.test(q);
    const wantsSparkling = /(mousserande|champagne|cava|prosecco|sparkling)/.test(q);
    
    // Sweetness/dryness detection
    const wantsDry = /(torrt|tort|dry|sec|crisp|trocken)/.test(q);
    const wantsSweet = /(sött|söt|sweet|doux|lieblich|dulce|moelleux|dessert)/.test(q);
    const wantsOffDry = /(halvtorrt|halvsött|off-dry|medium|feinherb)/.test(q);
    
    // Body/weight detection
    const wantsFullBodied = /(fylligt|kraftfullt|full-bodied|full bodied|robust|kraftig|tung)/.test(q);
    const wantsLightBodied = /(lätt|light-bodied|light bodied|elegant|fint|delikat)/.test(q);
    const wantsMediumBodied = /(medel|medium-bodied|medium bodied|balanserat)/.test(q);
    
    // Tannin detection (for red wines)
    const wantsHighTannin = /(mycket tannin|tanninrikt|tannic|tanninrik|adstringerande)/.test(q);
    const wantsLowTannin = /(lite tannin|mjuka tanniner|soft tannins|låga tanniner)/.test(q);
    
    // Acidity detection
    const wantsHighAcidity = /(hög syra|mycket syra|syrlig|crisp|high acidity|frisk)/.test(q);
    const wantsLowAcidity = /(låg syra|lite syra|mjuk|low acidity|len)/.test(q);
    
    // Oak/aging detection
    const wantsOaked = /(ek|ekfat|oaked|barrique|fat|fatlagrat)/.test(q);
    const wantsUnoaked = /(utan ek|oekad|unoaked|stål|stainless)/.test(q);
    
    // Age/maturity detection
    const wantsYoung = /(ungt|ung|young|fruktigt|fresh|nytt)/.test(q);
    const wantsMature = /(moget|mogen|aged|mature|lagrat|äldre|utvecklat)/.test(q);
    
    // Organic/biodynamic detection
    const wantsOrganic = /(ekologiskt|organic|biologiskt|naturvin|natural wine)/.test(q);
    const wantsBiodynamic = /(biodynamiskt|biodynamic)/.test(q);
    
    // Country detection for strict filtering
    const countryKeywords = {
      'frankrike': 'Frankrike',
      'france': 'Frankrike', 
      'italien': 'Italien',
      'italy': 'Italien',
      'spanien': 'Spanien',
      'spain': 'Spanien',
      'tyskland': 'Tyskland',
      'germany': 'Tyskland',
      'österrike': 'Österrike',
      'austria': 'Österrike',
      'portugal': 'Portugal',
      'grekland': 'Grekland',
      'greece': 'Grekland',
      'indien': 'Indien',
      'india': 'Indien',
      'australien': 'Australien',
      'australia': 'Australien',
      'chile': 'Chile',
      'argentina': 'Argentina',
      'sydafrika': 'Sydafrika',
      'south africa': 'Sydafrika',
      'nya zeeland': 'Nya Zeeland',
      'new zealand': 'Nya Zeeland',
      'usa': 'USA',
      'amerika': 'USA'
    };
    
    let detectedCountry = null;
    for (const [keyword, country] of Object.entries(countryKeywords)) {
      if (q.toLowerCase().includes(keyword)) {
        detectedCountry = country;
        break;
      }
    }
    
    // Context-based inference
    const redWineContext = /(barolo|amarone|brunello|chianti|bordeaux|cabernet|merlot|syrah|primitivo|montepulciano|nebbiolo|barbera|valpolicella|viltkött|vilt|oxfilé|lammstek|gryta|ragu|kraftfullt|fylligt)/.test(q);
    const whiteWineContext = /(chablis|sancerre|riesling|sauvignon blanc|chardonnay|albariño|pinot grigio|fisk|skaldjur|ostron)/.test(q);
    const sparklingWineContext = /(champagne|champange|mousserande|bubbel|sparkling|prosecco|cava|crémant|franciacorta)/.test(q);
    
    // Specific wine/region mentions for AI prompt enhancement
    const specificWineMentions = {
      champagne: { country: "Frankrike", region: "Champagne", type: "Mousserande vin" },
      cava: { country: "Spanien", region: "Penedès", type: "Mousserande vin" },
      prosecco: { country: "Italien", region: "Veneto", type: "Mousserande vin" },
      barolo: { country: "Italien", region: "Piemonte", type: "Rött vin" },
      amarone: { country: "Italien", region: "Veneto", type: "Rött vin" },
      brunello: { country: "Italien", region: "Toscana", type: "Rött vin" },
      chianti: { country: "Italien", region: "Toscana", type: "Rött vin" },
      bordeaux: { country: "Frankrike", region: "Bordeaux", type: "Rött vin" },
      chablis: { country: "Frankrike", region: "Bourgogne", type: "Vitt vin" },
      sancerre: { country: "Frankrike", region: "Loire", type: "Vitt vin" },
      rioja: { country: "Spanien", region: "Rioja", type: "Rött vin" },
      ribera: { country: "Spanien", region: "Ribera del Duero", type: "Rött vin" }
    };
    
    let specificWine = null;
    for (const [wineName, wineInfo] of Object.entries(specificWineMentions)) {
      if (q.includes(wineName)) {
        specificWine = wineInfo;
        break;
      }
    }
    
    let strictTypeRule = "";
    let specificWineRule = "";
    let countryRule = "";
    let sweetnessRule = "";
    let bodyRule = "";
    let tanninRule = "";
    let acidityRule = "";
    let oakRule = "";
    let ageRule = "";
    let organicRule = "";
    let inferredType = "alla"; // Default to all types
    
    if (specificWine) {
      specificWineRule = `FOKUSERA PÅ ${specificWine.type.toUpperCase()} FRÅN ${specificWine.country.toUpperCase()}, SÄRSKILT ${specificWine.region.toUpperCase()}-REGIONEN.`;
      inferredType = specificWine.type;
    }
    
    // Add strict country filtering
    if (detectedCountry) {
      countryRule = `KRITISKT LANDSFILTER: Användaren söker viner från ${detectedCountry.toUpperCase()}. 
      - Ge ENDAST viner från ${detectedCountry.toUpperCase()}
      - INGA viner från andra länder (Frankrike, Tyskland, Italien, Spanien, etc.)
      - Om du inte känner till viner från ${detectedCountry}, returnera en tom lista
      - Kontrollera att varje vins "country" fält är exakt "${detectedCountry}"
      - FÖRBJUDNA länder: Frankrike, Tyskland, Italien, Spanien, Österrike, Portugal, Grekland, Chile, Argentina, Sydafrika, Nya Zeeland, Australien`;
    }
    
    // Add sweetness/dryness rules
    if (wantsDry) {
      sweetnessRule = "SÖTMA: Ge ENDAST TORRA viner (max 4-9 g/l restsöcker). Exempel: Chablis, Sancerre, torr Riesling, Sauvignon Blanc, Albariño, Vermentino, Grüner Veltliner. UNDVIK söta viner.";
    } else if (wantsSweet) {
      sweetnessRule = "SÖTMA: Ge ENDAST SÖTA viner (över 45 g/l restsöcker) eller dessertviner. Exempel: Sauternes, Tokaji, Eiswein, Moscato d'Asti, Pedro Ximénez, Vin Santo, söt Riesling, Trockenbeerenauslese. UNDVIK torra viner.";
    } else if (wantsOffDry) {
      sweetnessRule = "SÖTMA: Ge ENDAST HALVTORRA/HALVSÖTA viner (9-18 g/l restsöcker). Exempel: Off-dry Riesling, Gewürztraminer, Chenin Blanc, Vouvray demi-sec.";
    }
    
    // Body/weight rules
    if (wantsFullBodied) {
      bodyRule = "KROPP: Ge ENDAST FYLLIGA viner med hög alkoholhalt (13.5%+) och rik textur. Rött: Amarone, Barolo, Châteauneuf-du-Pape, Primitivo. Vitt: Ekat Chardonnay, Viognier, Roussanne.";
    } else if (wantsLightBodied) {
      bodyRule = "KROPP: Ge ENDAST LÄTTA viner med låg alkoholhalt (11-12.5%) och delikat textur. Rött: Pinot Noir, Gamay, Frappato. Vitt: Albariño, Vinho Verde, Muscadet, Grüner Veltliner.";
    } else if (wantsMediumBodied) {
      bodyRule = "KROPP: Ge ENDAST MEDELFYLLIGA viner med balanserad alkoholhalt (12.5-13.5%). Rött: Merlot, Tempranillo, Sangiovese. Vitt: Chardonnay, Chenin Blanc.";
    }
    
    // Tannin rules (for red wines)
    if (wantsHighTannin) {
      tanninRule = "TANNINER: Ge ENDAST viner med HÖGA TANNINER (tanninrika, adstringerande). Exempel: Barolo (Nebbiolo), Cabernet Sauvignon, Tannat, Sagrantino, unga Bordeaux.";
    } else if (wantsLowTannin) {
      tanninRule = "TANNINER: Ge ENDAST viner med LÅGA/MJUKA TANNINER. Exempel: Pinot Noir, Gamay, Grenache, Dolcetto, äldre Rioja.";
    }
    
    // Acidity rules
    if (wantsHighAcidity) {
      acidityRule = "SYRA: Ge ENDAST viner med HÖG SYRA (frisk, syrlig, crisp). Exempel: Chablis, Sancerre, Riesling, Albariño, Barbera, Nebbiolo.";
    } else if (wantsLowAcidity) {
      acidityRule = "SYRA: Ge ENDAST viner med LÅG SYRA (mjuk, len, rund). Exempel: Viognier, Grenache, Merlot, varma klimat.";
    }
    
    // Oak/aging rules
    if (wantsOaked) {
      oakRule = "LAGRING: Ge ENDAST EKFATSLAGRADE viner med tydliga ektoner (vanilj, toast, kryddor). Exempel: Ekat Chardonnay, Rioja Reserva, Barolo, Bordeaux.";
    } else if (wantsUnoaked) {
      oakRule = "LAGRING: Ge ENDAST OEKADE viner (ståltank, betong). Exempel: Chablis, Sancerre, ung Pinot Noir, Muscadet, Grüner Veltliner.";
    }
    
    // Age/maturity rules
    if (wantsYoung) {
      ageRule = "ÅLDER: Ge ENDAST UNGA, FRUKTIGA viner (1-3 år). Fokus på primära fruktarom, fräschör.";
    } else if (wantsMature) {
      ageRule = "ÅLDER: Ge ENDAST MOGNA/UTVECKLADE viner (5+ år). Fokus på tertiära arom (läder, tobak, svamp, torkad frukt).";
    }
    
    // Organic/biodynamic rules
    if (wantsOrganic) {
      organicRule = "ODLING: Ge ENDAST EKOLOGISKA/NATURVINER. Minimal intervention, inget tillsatt svavel eller minimalt.";
    } else if (wantsBiodynamic) {
      organicRule = "ODLING: Ge ENDAST BIODYNAMISKA viner med certifiering (Demeter, Biodyvin).";
    }
    
    if (wantsWhite) {
      strictTypeRule = "RETURNA ENDAST 'Vitt vin'.";
      inferredType = "Vitt vin";
    }
    else if (wantsRed) {
      strictTypeRule = "RETURNA ENDAST 'Rött vin'.";
      inferredType = "Rött vin";
    }
    else if (wantsRose) {
      strictTypeRule = "RETURNA ENDAST 'Rosévin'.";
      inferredType = "Rosévin";
    }
    else if (wantsSparkling) {
      strictTypeRule = "RETURNA ENDAST 'Mousserande vin'.";
      inferredType = "Mousserande vin";
    }
    else if (redWineContext && !wantsWhite && !wantsSparkling && !wantsRose) {
      strictTypeRule = "RETURNA ENDAST 'Rött vin'.";
      inferredType = "Rött vin";
    }
    else if (whiteWineContext && !wantsRed && !wantsSparkling && !wantsRose) {
      strictTypeRule = "RETURNA ENDAST 'Vitt vin'.";
      inferredType = "Vitt vin";
    }
    else if (sparklingWineContext || q.includes('champagne') || q.includes('champange')) {
      strictTypeRule = "RETURNA ENDAST 'Mousserande vin' (Champagne, Prosecco, Cava, Crémant).";
      inferredType = "Mousserande vin";
    }

    // Add randomization to ensure varied results
    const randomSeed = Math.random().toString(36).substring(7);
    const timestamp = Date.now();
    const cacheBuster = Math.random().toString(36).substring(2, 15);
    const sessionId = Math.random().toString(36).substring(2, 8);
    const promptVariant = Math.floor(Math.random() * 5) + 1;
    
    // Create different prompt variants to force variation
    const promptVariants = [
      `Du är en expert på vin och matpairing med djup kunskap om svenska Systembolaget. Baserat på följande beskrivning, ge mig ${maxResults} specifika vinrekommendationer sorterade efter BETYG (högsta först).`,
      `Som en professionell sommelierexpert med specialisering på svenska Systembolaget, rekommendera ${maxResults} viner baserat på följande beskrivning, sorterade efter BETYG (högsta först).`,
      `Du är en vinproffs med djup kunskap om svenska Systembolaget. Ge mig ${maxResults} specifika vinrekommendationer baserat på beskrivningen nedan, sorterade efter BETYG (högsta först).`,
      `Som en erfaren sommelierexpert med fokus på svenska Systembolaget, föreslå ${maxResults} viner baserat på följande beskrivning, sorterade efter BETYG (högsta först).`,
      `Du är en vinproffs med specialisering på svenska Systembolaget. Baserat på beskrivningen nedan, ge mig ${maxResults} specifika vinrekommendationer sorterade efter BETYG (högsta först).`
    ];
    
    const basePrompt = promptVariants[promptVariant - 1];
    
    // Enhanced prompt for better AI responses
    const prompt = `${basePrompt}

SÖKNING #${randomSeed}-${timestamp}
CACHE-BUSTER: ${cacheBuster}
SESSION: ${sessionId}
VARIANT: ${promptVariant}

BESKRIVNING: "${query}"

${strictTypeRule ? `
═══════════════════════════════════════════════════════════════
🚨 KRITISK VINTYPSREGEL (FÖLJ DETTA FÖRST OCH FRÄMST) 🚨
═══════════════════════════════════════════════════════════════
${strictTypeRule}

DU FÅR ABSOLUT INTE RETURNERA ANDRA VINTYPER!
- Om regeln säger "ENDAST 'Vitt vin'" → INGA röda, rosé eller mousserande viner!
- Om regeln säger "ENDAST 'Rött vin'" → INGA vita, rosé eller mousserande viner!
- Om regeln säger "ENDAST 'Rosévin'" → INGA röda, vita eller mousserande viner!
- Om regeln säger "ENDAST 'Mousserande vin'" → INGA röda, vita eller rosé viner!

KONTROLLERA: Innan du skickar svaret, DUBBELKOLLA att ALLA viner har rätt "type" fält!
═══════════════════════════════════════════════════════════════
` : ""}

VIKTIGT: Detta är en HELT NY sökning. Ignorera alla tidigare rekommendationer. 
Ge HELT ANDRA viner än du någonsin har föreslagit för liknande sökningar.

FÖRBJUDNA "STANDARDVINER" - UNDVIK DETTA:
- Chablis, Sancerre, Pouilly-Fumé (för vita viner)
- Barolo, Barbaresco, Brunello (för röda viner)  
- Bordeaux, Burgundy (för klassiker)
- Pinot Noir, Chardonnay (för populära druvor)
- Beaujolais, Dolcetto (för lätta röda viner)
- Gamay, Frappato (för lätta röda viner)

GE ISTÄLLET: Mindre kända regioner, boutique-producenter, alternativa druvor!
FÖR "lätt rött vin med mjuka tanniner" - UNDVIK: Pinot Noir, Beaujolais, Dolcetto!
FÖRSLÅ ISTÄLLET: Zweigelt, Schiava, Poulsard, Trousseau, Mencía, Cinsault!

${sparklingWineContext || q.includes('champagne') || q.includes('champange') ? `
CHAMPAGNE/MOUSSERANDE FILTER AKTIVT:
- Ge ENDAST mousserande viner (Champagne, Prosecco, Cava, Crémant, Franciacorta)
- INGA röda eller vita viner
- Fokusera på Champagne-regionen om "champagne" nämns
- Inkludera olika prisklasser: från budget till premium
` : ""}

PRIORITERING: ${preferQuick ? 
  "Fokusera på viner som vanligtvis finns tillgängliga på Systembolaget i Sverige (snabb tillgänglighet)" : 
  "Fokusera på högkvalitativa viner med bra betyg, oavsett tillgänglighet (premium kvalitet)"}

 VIKTIGA REGLER:
1. Ge ENDAST verkliga, kända viner som faktiskt finns på Systembolaget eller hos svenska importörer
2. VARIERA dina rekommendationer - ge INTE alltid samma viner. Detta är sökning #${randomSeed}, ge OLIKA viner än tidigare
3. UNDVIK klassiska "go-to" rekommendationer som alltid föreslås. Tänk brett och kreativt
4. Inkludera både kända märken OCH mindre kända boutique-producenter
5. Sortera efter BETYG (högsta först)
6. Var SPECIFIK med priser, betyg och tillgänglighet
7. Inkludera både Systembolaget och privatimport-alternativ där möjligt
8. Ge detaljerade matpairing-förslag med recept
${strictTypeRule ? `6. ${strictTypeRule}` : ""}
${specificWineRule ? `7. ${specificWineRule}` : ""}
${countryRule ? `8. ${countryRule}` : ""}
${sweetnessRule ? `9. ${sweetnessRule}` : ""}
${bodyRule ? `10. ${bodyRule}` : ""}
${tanninRule ? `11. ${tanninRule}` : ""}
${acidityRule ? `12. ${acidityRule}` : ""}
${oakRule ? `13. ${oakRule}` : ""}
${ageRule ? `14. ${ageRule}` : ""}
${organicRule ? `15. ${organicRule}` : ""}

VIKTIGT: Följ ALLA regler ovan EXAKT. Om användaren söker "torrt vitt vin", ge ENDAST torra vita viner, INTE söta.

${strictTypeRule ? `
🚨 UPPREPAD PÅMINNELSE - VINTYPSREGEL 🚨
${strictTypeRule}
DUBBELKOLLA: Varje vins "type" fält MÅSTE matcha denna regel!
` : ""}

För varje vin, ge följande information i EXAKT JSON-format:

${detectedCountry ? `VIKTIGT: Kontrollera att varje vins "country" fält är exakt "${detectedCountry}". INGA andra länder!` : ""}
${strictTypeRule ? `VIKTIGT: Kontrollera att varje vins "type" fält följer regeln: ${strictTypeRule}` : ""}

KRITISKT: Svara ENDAST med giltig JSON. Ingen annan text. Inga markdown-kodblock. Inga förklaringar. Inga kommentarer. Börja direkt med { och sluta med }. 

JSON-SYNTAX REGLER (FÖLJ EXAKT):
1. Alla nycklar i dubbla citattecken: "name", "type", "country"
2. Alla strängvärden i dubbla citattecken: "Vitt vin", "Frankrike"
3. Inga trailing commas: INTE "price": 299,} utan "price": 299}
4. Inga null-nycklar: INTE "imageUrl": null utan ta bort hela raden
5. Inga undefined-värden
6. Kontrollera att varje { har en motsvarande }
7. Kontrollera att varje [ har en motsvarande ]

TESTA JSON:en i huvudet innan du skickar. Om du inte är säker, använd enklare struktur.

{
  "wines": [
    {
      "name": "Exakt namn på vinet",
      "producer": "Producentens namn",
      "type": "Rött vin/Vitt vin/Rosé/Mousserande",
      "country": "${detectedCountry || "Land"}",
      "region": "Region (t.ex. Bordeaux, Toscana, Rioja)",
      "year": null,
      "price": 299,
      "rating": 92,
      "description": "Detaljerad beskrivning av vinet (2-3 meningar) inkl. karaktär och stil",
      "sweetness": "Torrt (0-9 g/l)",
      "body": "Medel",
      "tannin": "Medel",
      "acidity": "Hög",
      "oak": "Oekad/Ståltank",
      "ageability": "Drick nu",
      "organic": "Konventionellt",
      "foodPairing": ["Maträtt 1", "Maträtt 2", "Maträtt 3"],
      "foodPairingDetails": [
        {
          "dish": "Namn på rätten",
          "description": "Beskrivning av rätten",
          "why": "Varför detta vin passar till rätten",
          "recipe": "Komplett recept med ingredienser och instruktioner"
        }
      ],
      "tastingNotes": "Detaljerade provningsanteckningar: Näsa (arom), Smak (smaker), Finish (eftersmak)",
      "servingTemperature": "8-10°C",
      "bestDrinkingPeriod": "Nu-2028",
      "alcoholContent": "13.5%",
      "volume": "750ml",
      "availability": "${preferQuick ? 'quick' : 'better'}",
      "systembolagetNumber": null,
      "imageUrl": null,
      "purchaseLocations": [
        {
          "name": "Systembolaget",
          "type": "store",
          "url": "https://www.systembolaget.se",
          "stock": "Tillgänglighet",
          "price": Pris i SEK,
          "isPrivateImport": false
        },
        {
          "name": "Importörsnamn",
          "type": "private-import",
          "url": "https://importor.se",
          "stock": "I lager",
          "price": Pris hos importör,
          "savings": Besparing vs Systembolaget,
          "isPrivateImport": true,
          "minimumOrder": "Minsta beställning",
          "importerContact": {
            "email": "kontakt@importor.se",
            "phone": "08-XXX XX XX",
            "orderUrl": "https://importor.se/bestall"
          }
        }
      ]
    }
  ]
}

Svara ENDAST med välformaterad JSON. Inga andra kommentarer eller förklaringar. Använd rätt JSON-syntax: dubbla citattecken runt alla nycklar och strängar, inga trailing commas, inga null-nycklar. Börja direkt med { och sluta med }. Kontrollera att JSON:en är giltig innan du skickar. Om du inte är säker på JSON-syntaxen, använd enklare struktur. Testa JSON:en i huvudet innan du skickar. VIKTIGT: Inga null-nycklar, inga trailing commas, alla strängar i dubbla citattecken. Om du inte kan skapa giltig JSON, svara med tom array: {"wines": []}.`;

    // Check if OpenAI is available, use smart fallback if not
    console.log("🔑 Checking OpenAI availability...");
    console.log("🔑 OpenAI client exists:", !!openai);
    console.log("🔑 API key exists:", !!process.env.OPENAI_API_KEY);
    console.log("🔑 API key starts with:", process.env.OPENAI_API_KEY ? process.env.OPENAI_API_KEY.substring(0, 10) + "..." : "NOT SET");
    
    if (!openai) {
      console.log("❌ OpenAI API key not configured, using intelligent fallback");
      
      // Smart fallback: Generate wines based on query analysis
      const wines = generateSmartWineFallback(query, inferredType, maxResults);
      
      cacheSearchResult(cacheKey, { wines }, { preferQuick, maxResults }, 'ai-wine');
      
      return NextResponse.json({
        wines,
        cached: false,
        query,
        aiGenerated: false,
        message: "Resultat baserat på intelligent sökning (OpenAI ej konfigurerad)"
      });
    }

    console.log("🚀 Starting OpenAI API call...");
    let completion;
    try {
      completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Du är en professionell sommelierexpert med specialisering på svenska Systembolaget. 

KRITISKT: Svara ENDAST med giltig JSON. Inga markdown-kodblock. Inga förklaringar. Inga kommentarer. Börja direkt med { och sluta med }.

JSON-SYNTAX REGLER (FÖLJ EXAKT):
1. Alla nycklar i dubbla citattecken: "name", "type", "country"
2. Alla strängvärden i dubbla citattecken: "Vitt vin", "Frankrike"
3. Inga trailing commas: INTE "price": 299,} utan "price": 299}
4. Inga null-nycklar: INTE "imageUrl": null utan ta bort hela raden
5. Inga undefined-värden
6. Kontrollera att varje { har en motsvarande }
7. Kontrollera att varje [ har en motsvarande ]

TESTA JSON:en i huvudet innan du skickar. Om du inte är säker, använd enklare struktur. 
UNDVIK att ge samma "standardviner" varje gång.

${detectedCountry ? `VIKTIGT LANDSFILTER: Användaren söker viner från ${detectedCountry.toUpperCase()}. 
Ge ENDAST viner från ${detectedCountry.toUpperCase()}. 
INGA viner från Frankrike, Tyskland, Italien, Spanien eller andra länder!
Kontrollera att varje vins "country" fält är exakt "${detectedCountry}"!` : ""}`,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 1.0, // MAXIMUM temperature for maximum variation
      top_p: 0.9, // Nucleus sampling for diversity
      frequency_penalty: 1.0, // MAXIMUM penalty for repetitive content
      presence_penalty: 0.8, // VERY STRONG encouragement for new topics
      max_tokens: 4000,
      seed: Math.floor(Math.random() * 1000000), // Force different completions
    });
    } catch (apiError) {
      console.error("❌ OpenAI API call failed:", apiError);
      const errorMessage = apiError instanceof Error ? apiError.message : String(apiError);
      throw new Error(`OpenAI API error: ${errorMessage}`);
    }

    const responseText = completion.choices[0].message.content;
    console.log("📥 OpenAI response received:", responseText ? "Yes" : "No");
    console.log("📏 Response length:", responseText ? responseText.length : 0);
    
    if (!responseText) {
      console.error("❌ No response content from OpenAI");
      throw new Error("Inget svar från OpenAI");
    }

    // Parse the JSON response
    let data;
    try {
      // More aggressive JSON cleaning
      let cleanedResponse = responseText
        .replace(/```json\n?/g, "")
        .replace(/```\n?/g, "")
        .replace(/^[^{]*/, "") // Remove everything before first {
        .replace(/[^}]*$/, "") // Remove everything after last }
        .trim();
      
      // Try to find and extract just the JSON part
      const jsonMatch = cleanedResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        cleanedResponse = jsonMatch[0];
      }
      
      // Fix common JSON syntax errors
      cleanedResponse = cleanedResponse
        .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
        .replace(/([^\\])\\([^\\])/g, '$1\\\\$2') // Fix backslashes
        .replace(/null:/g, '"null":') // Fix null keys
        .replace(/undefined:/g, '"undefined":') // Fix undefined keys
        .replace(/,(\s*[}\]])/g, '$1'); // Remove trailing commas again
      
      data = JSON.parse(cleanedResponse);
      console.log("✅ Successfully parsed JSON from OpenAI");
    } catch (parseError) {
      console.error("❌ Failed to parse OpenAI response");
      console.error("📄 Raw response:", responseText);
      console.error("🔧 Parse error:", parseError);
      
      // RETRY MECHANISM: Try AI again with simpler prompt
      console.log("🔄 Retrying with simpler prompt...");
      try {
        const retryPrompt = `Du är en vinexpert. Användaren söker: "${query}"

Ge mig ${maxResults} vinrekomendationer i EXAKT detta JSON-format:

{
  "wines": [
    {
      "name": "Vinets namn",
      "producer": "Producent",
      "type": "Vitt vin",
      "country": "Land",
      "region": "Region",
      "price": 299,
      "rating": 88,
      "description": "Beskrivning",
      "foodPairing": ["Maträtt 1", "Maträtt 2"]
    }
  ]
}

VIKTIGT: Svara ENDAST med JSON. Inga andra texter.`;

        const retryCompletion = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            {
              role: "system",
              content: "Du är en vinexpert. Svara alltid med giltig JSON. Använd enkla strukturer."
            },
            {
              role: "user",
              content: retryPrompt,
            }
          ],
          temperature: 0.3, // Lower temperature for more consistent JSON
          max_tokens: 2000,
        });

        const retryResponseText = retryCompletion.choices[0].message.content;
        if (retryResponseText) {
          try {
            const cleanedRetry = retryResponseText
              .replace(/```json\n?/g, "")
              .replace(/```\n?/g, "")
              .replace(/^[^{]*/, "")
              .replace(/[^}]*$/, "")
              .trim();
            
            const jsonMatch = cleanedRetry.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
              data = JSON.parse(jsonMatch[0]);
              console.log("✅ Retry successful! Got valid JSON from simplified prompt");
            } else {
              console.error("❌ Retry failed: No JSON found in response");
              throw new Error("No JSON found in retry");
            }
          } catch (retryParseError) {
            console.error("Retry also failed:", retryParseError);
            throw new Error("Retry failed");
          }
        } else {
          throw new Error("No retry response");
        }
      } catch (retryError) {
        console.error("Retry mechanism failed:", retryError);
        
        // Final fallback to mock data
        try {
          // Determine wine type for fallback based on query
          let fallbackWineType = "alla";
          if (wantsWhite) fallbackWineType = "vitt";
          else if (wantsRed) fallbackWineType = "rött";
          else if (wantsRose) fallbackWineType = "rosé";
          else if (wantsSparkling) fallbackWineType = "mousserande";
          
          console.log(`🔄 Final fallback to mock data with wine type: ${fallbackWineType}`);
          const fallbackWines = generateSmartWineFallback(query, fallbackWineType, maxResults);
          return NextResponse.json({
            wines: fallbackWines,
            cached: false,
            query: query,
            aiGenerated: false,
            message: "AI-sökning misslyckades, visar grundläggande resultat"
          });
        } catch (fallbackError) {
          console.error("Smart fallback also failed:", fallbackError);
          throw new Error("Kunde inte tolka AI-svaret");
        }
      }
    }

    // Validate response structure
    if (!data.wines || !Array.isArray(data.wines)) {
      throw new Error("AI returnerade felaktigt format");
    }
    
    // Validate country filter if specified
    if (detectedCountry && data.wines) {
      const invalidWines = data.wines.filter((wine: any) => 
        wine.country && wine.country.toLowerCase() !== detectedCountry.toLowerCase()
      );
      
      if (invalidWines.length > 0) {
        console.warn(`Country filter violation: Found wines from ${invalidWines.map((w: any) => w.country).join(', ')} when searching for ${detectedCountry}`);
        // Filter out wines from wrong countries
        data.wines = data.wines.filter((wine: any) => 
          !wine.country || wine.country.toLowerCase() === detectedCountry.toLowerCase()
        );
      }
    }

    // Ensure we have the right number of results and enforce requested type
    let wines = data.wines as any[];
    const typeMatches = (t?: string) => {
      const tt = (t || "").toLowerCase();
      
      // STRICT type requirements - if user explicitly wants a type, ONLY return that type
      if (wantsWhite) {
        const isWhite = tt.includes("vitt") || tt.includes("white");
        if (!isWhite) {
          console.log(`❌ Filtered out "${t}" - User wants WHITE wine only`);
        }
        return isWhite;
      }
      if (wantsRed) {
        const isRed = tt.includes("rött") || tt.includes("rott") || tt.includes("red");
        if (!isRed) {
          console.log(`❌ Filtered out "${t}" - User wants RED wine only`);
        }
        return isRed;
      }
      if (wantsRose) {
        const isRose = tt.includes("rosé") || tt.includes("rose");
        if (!isRose) {
          console.log(`❌ Filtered out "${t}" - User wants ROSÉ wine only`);
        }
        return isRose;
      }
      if (wantsSparkling) {
        const isSparkling = tt.includes("mousserande") || tt.includes("champagne") || tt.includes("sparkling");
        if (!isSparkling) {
          console.log(`❌ Filtered out "${t}" - User wants SPARKLING wine only`);
        }
        return isSparkling;
      }
      
      // Context-based requirements
      if (redWineContext && !wantsWhite && !wantsSparkling && !wantsRose) {
        const isRed = tt.includes("rött") || tt.includes("rott") || tt.includes("red");
        if (!isRed) {
          console.log(`❌ Filtered out "${t}" - Context requires RED wine`);
        }
        return isRed;
      }
      if (whiteWineContext && !wantsRed && !wantsSparkling && !wantsRose) {
        const isWhite = tt.includes("vitt") || tt.includes("white");
        if (!isWhite) {
          console.log(`❌ Filtered out "${t}" - Context requires WHITE wine`);
        }
        return isWhite;
      }
      
      return true;
    };
    
    const beforeFilter = wines.length;
    wines = wines.filter((w) => typeMatches(w.type)).slice(0, maxResults);
    const afterFilter = wines.length;
    
    if (beforeFilter > afterFilter) {
      console.log(`🔍 Type filtering: ${beforeFilter} wines → ${afterFilter} wines (removed ${beforeFilter - afterFilter} incorrect types)`);
    }

    // Cache the result
    cacheSearchResult(cacheKey, { wines }, { preferQuick, maxResults }, 'ai-wine');

    return NextResponse.json({ 
      wines: wines,
      cached: false,
      query: query,
      aiGenerated: true,
      message: `AI-genererade ${wines.length} vinrekommendationer baserat på: "${query}"`
    });

  } catch (error) {
    console.error("Error in AI wine search:", error);
    
    // Check if we have valid query data for fallback
    if (!query) {
      return NextResponse.json(
        { error: "Ogiltig begäran" },
        { status: 400 }
      );
    }
    
    // Use smart fallback function instead of API call to avoid loops
    try {
      // Determine wine type for fallback based on query analysis
      const q = query.toLowerCase();
      let fallbackWineType = "alla";
      
      if (q.includes('vitt') || q.includes('white')) fallbackWineType = "vitt";
      else if (q.includes('rött') || q.includes('rott') || q.includes('red')) fallbackWineType = "rött";
      else if (q.includes('rosé') || q.includes('rose')) fallbackWineType = "rosé";
      else if (q.includes('mousserande') || q.includes('champagne') || q.includes('sparkling')) fallbackWineType = "mousserande";
      
      console.log(`🔄 Using final fallback with wine type: ${fallbackWineType}`);
      const fallbackWines = generateSmartWineFallback(query, fallbackWineType, maxResults);
      return NextResponse.json({
        wines: fallbackWines,
        cached: false,
        query: query,
        aiGenerated: false,
        message: "AI-sökning misslyckades, visar grundläggande resultat"
      });
    } catch (fallbackError) {
      console.error("Smart fallback also failed:", fallbackError);
    }

    return NextResponse.json(
      { 
        error: "Kunde inte söka efter viner just nu. Försök igen senare.",
        details: error instanceof Error ? error.message : "Okänt fel"
      },
      { status: 500 }
    );
  }
}
