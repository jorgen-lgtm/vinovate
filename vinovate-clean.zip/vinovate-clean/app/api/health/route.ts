import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({ 
    status: "ok", 
    message: "WineAI API is running",
    openaiConfigured: !!process.env.OPENAI_API_KEY 
  });
}

