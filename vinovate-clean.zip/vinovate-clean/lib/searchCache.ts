import { Wine } from "@/types/wine";
import { Importer } from "@/types/importer";

export interface CachedSearch {
  query: string;
  normalizedQuery: string;
  filters?: any;
  results: {
    wines?: Wine[];
    importers?: Importer[];
  };
  timestamp: number;
  hitCount: number;
  searchType: 'wine' | 'importer' | 'find-importers';
}

// In-memory cache (will reset when server restarts)
// For production, use Redis, MongoDB, or similar
const searchCache = new Map<string, CachedSearch>();
const CACHE_TTL = 7 * 24 * 60 * 60 * 1000; // 7 days
const SIMILARITY_THRESHOLD = 0.8;

/**
 * Normalize query for better matching
 */
export function normalizeQuery(query: string): string {
  return query
    .toLowerCase()
    .trim()
    .replace(/[åä]/g, 'a')
    .replace(/[ö]/g, 'o')
    .replace(/\s+/g, ' ')
    .replace(/[^\w\s]/g, '');
}

/**
 * Calculate similarity between two strings (Jaccard similarity)
 */
export function calculateSimilarity(str1: string, str2: string): number {
  const words1 = new Set(str1.split(' '));
  const words2 = new Set(str2.split(' '));
  
  const intersection = new Set(Array.from(words1).filter(x => words2.has(x)));
  const union = new Set(Array.from(words1).concat(Array.from(words2)));
  
  return intersection.size / union.size;
}

/**
 * Generate cache key
 */
export function generateCacheKey(query: string, filters?: any, searchType?: string): string {
  const normalized = normalizeQuery(query);
  const filterKey = filters ? JSON.stringify(filters) : '';
  return `${searchType || 'wine'}:${normalized}:${filterKey}`;
}

/**
 * Get cached result if exists and not expired
 */
export function getCachedResult(query: string, filters?: any, searchType?: string): CachedSearch | null {
  const cacheKey = generateCacheKey(query, filters, searchType);
  const cached = searchCache.get(cacheKey);
  
  if (cached) {
    // Check if expired
    if (Date.now() - cached.timestamp > CACHE_TTL) {
      searchCache.delete(cacheKey);
      return null;
    }
    
    // Increment hit count
    cached.hitCount++;
    return cached;
  }
  
  // Try to find similar cached query
  const normalized = normalizeQuery(query);
  for (const [key, cachedSearch] of Array.from(searchCache.entries())) {
    if (cachedSearch.searchType === searchType) {
      const similarity = calculateSimilarity(normalized, cachedSearch.normalizedQuery);
      if (similarity >= SIMILARITY_THRESHOLD) {
        cachedSearch.hitCount++;
        return cachedSearch;
      }
    }
  }
  
  return null;
}

/**
 * Cache a search result
 */
export function cacheSearchResult(
  query: string,
  results: { wines?: Wine[], importers?: Importer[] },
  filters?: any,
  searchType?: string
): void {
  const cacheKey = generateCacheKey(query, filters, searchType);
  const normalized = normalizeQuery(query);
  
  searchCache.set(cacheKey, {
    query,
    normalizedQuery: normalized,
    filters,
    results,
    timestamp: Date.now(),
    hitCount: 1,
    searchType: (searchType || 'wine') as any,
  });
  
  // Cleanup old entries if cache is too large
  if (searchCache.size > 1000) {
    cleanupCache();
  }
}

/**
 * Cleanup expired and least used cache entries
 */
function cleanupCache(): void {
  const now = Date.now();
  const entries = Array.from(searchCache.entries());
  
  // Remove expired entries
  entries.forEach(([key, value]) => {
    if (now - value.timestamp > CACHE_TTL) {
      searchCache.delete(key);
    }
  });
  
  // If still too large, remove least used
  if (searchCache.size > 1000) {
    const sorted = entries.sort((a, b) => a[1].hitCount - b[1].hitCount);
    const toRemove = sorted.slice(0, 200);
    toRemove.forEach(([key]) => searchCache.delete(key));
  }
}

/**
 * Get cache statistics
 */
export function getCacheStats() {
  const entries = Array.from(searchCache.values());
  const now = Date.now();
  
  return {
    totalEntries: searchCache.size,
    totalHits: entries.reduce((sum, entry) => sum + entry.hitCount, 0),
    avgHitCount: entries.length > 0 
      ? entries.reduce((sum, entry) => sum + entry.hitCount, 0) / entries.length 
      : 0,
    oldestEntry: entries.length > 0 
      ? Math.min(...entries.map(e => e.timestamp)) 
      : null,
    cacheHitRate: calculateCacheHitRate(),
    topQueries: getTopQueries(10),
  };
}

/**
 * Get most popular queries
 */
export function getTopQueries(limit: number = 10): Array<{ query: string; hits: number }> {
  const entries = Array.from(searchCache.values());
  return entries
    .sort((a, b) => b.hitCount - a.hitCount)
    .slice(0, limit)
    .map(entry => ({ query: entry.query, hits: entry.hitCount }));
}

// Track cache hit rate
let cacheHits = 0;
let cacheMisses = 0;

export function recordCacheHit() {
  cacheHits++;
}

export function recordCacheMiss() {
  cacheMisses++;
}

function calculateCacheHitRate(): number {
  const total = cacheHits + cacheMisses;
  return total > 0 ? cacheHits / total : 0;
}

/**
 * Clear all cache (admin function)
 */
export function clearCache(): void {
  searchCache.clear();
  cacheHits = 0;
  cacheMisses = 0;
}

