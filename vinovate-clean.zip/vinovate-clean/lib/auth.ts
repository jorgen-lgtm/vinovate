// Simple authentication for admin panel
// In production, use a proper auth solution like NextAuth.js

export function checkAdminAuth(password: string): boolean {
  const adminPassword = process.env.ADMIN_PASSWORD || "vinovate2025";
  return password === adminPassword;
}

export function setAdminSession() {
  if (typeof window !== 'undefined') {
    sessionStorage.setItem('vinovate_admin_auth', 'true');
  }
}

export function getAdminSession(): boolean {
  if (typeof window !== 'undefined') {
    return sessionStorage.getItem('vinovate_admin_auth') === 'true';
  }
  return false;
}

export function clearAdminSession() {
  if (typeof window !== 'undefined') {
    sessionStorage.removeItem('vinovate_admin_auth');
  }
}

