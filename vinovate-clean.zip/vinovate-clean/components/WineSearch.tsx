"use client";

import { useState, useEffect } from "react";
import { Search, Clock, Star, Loader2, Building2, X, Wine as WineIcon } from "lucide-react";
import { Wine } from "@/types/wine";
import WineTable from "./WineTable";
import AdvancedFilters from "./AdvancedFilters";
import ImporterSearchGuide from "./ImporterSearchGuide";
import ImporterCard from "./ImporterCard";
import CacheIndicator from "./CacheIndicator";
import PrivateImportInfo from "./PrivateImportInfo";
import { Importer } from "@/types/importer";
import Image from "next/image";
import SponsoredWineCard from "./SponsoredWineCard";
import ResultFilters from "./ResultFilters";
import DebugInfo from "./DebugInfo";

interface WineSearchProps {
  onWineSelect: (wine: Wine) => void;
  externalQuery?: string;
  onQueryChange?: (query: string) => void;
}

export default function WineSearch({ onWineSelect, externalQuery, onQueryChange }: WineSearchProps) {
  const [query, setQuery] = useState(externalQuery || "");
  const [preferQuick, setPreferQuick] = useState(true);
  const [searchCounter, setSearchCounter] = useState(0);
  const [searchType, setSearchType] = useState<'general' | 'importer' | 'find-importers'>('general');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Wine[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [importerName, setImporterName] = useState<string | null>(null);
  const [filters, setFilters] = useState<any>({});
  const [importers, setImporters] = useState<Importer[]>([]);
  const [isCached, setIsCached] = useState(false);
  const [cacheHitCount, setCacheHitCount] = useState<number>(0);
  const [lastQuery, setLastQuery] = useState<string>("");
  const [canGetMore, setCanGetMore] = useState(false);
  const [filteredResults, setFilteredResults] = useState<Wine[]>([]);
  const [displayCount, setDisplayCount] = useState<number>(5);
  const [showFiltered, setShowFiltered] = useState<boolean>(false);
  const [debugInfo, setDebugInfo] = useState<{
    wineCount: number;
    source: "OpenAI" | "Mock" | "Cache";
    aiGenerated?: boolean;
    endpoint?: string;
  } | null>(null);

  const handleQueryChange = (newQuery: string) => {
    setQuery(newQuery);
    if (onQueryChange) {
      onQueryChange(newQuery);
    }
  };

  const handleClearQuery = () => {
    setQuery("");
    if (onQueryChange) {
      onQueryChange("");
    }
    setResults([]);
    setImporters([]);
    setError(null);
    setLastQuery("");
    setCanGetMore(false);
    setFilteredResults([]);
    setShowFiltered(false);
  };

  const handleSearchWithQuery = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError(null);
    setResults([]);
    setImporters([]);
    setImporterName(null);
    
    // Fetch images for wines after getting results
    const fetchWineImages = async (wines: Wine[]) => {
      const winesWithImages = await Promise.all(
        wines.map(async (wine) => {
          if (!wine.imageUrl) {
            try {
              const response = await fetch('/api/systembolaget-image', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                  wineName: wine.name, 
                  producer: wine.producer 
                })
              });
              const imageData = await response.json();
              return { ...wine, imageUrl: imageData.imageUrl };
            } catch (error) {
              console.error('Error fetching wine image:', error);
              return wine;
            }
          }
          return wine;
        })
      );
      return winesWithImages;
    };

    // Build query with filters
    let enhancedQuery = searchQuery;
    if (filters.type) enhancedQuery += ` ${filters.type}`;
    if (filters.country) enhancedQuery += ` från ${filters.country}`;
    if (filters.region) enhancedQuery += ` ${filters.region}`;
    if (filters.grape) enhancedQuery += ` ${filters.grape}`;
    if (filters.priceRange) enhancedQuery += ` ${filters.priceRange}`;

    try {
      let endpoint = "/api/ai-wine-search"; // Use AI-powered search
      let body: any = { query: enhancedQuery, preferQuick, maxResults: 10 };

      // Check if user selected "importers only" in filters
      if (filters.searchMode === 'importers') {
        endpoint = "/api/find-importers";
        body = { query: enhancedQuery };
      }
      // Detect if searching for importers only
      else if (searchQuery.toLowerCase().includes("endast importörer") ||
               searchQuery.toLowerCase().includes("endast importör") ||
               (searchQuery.toLowerCase().includes("importörer") && 
                (searchQuery.toLowerCase().includes("champange") || 
                 searchQuery.toLowerCase().includes("champagne") ||
                 searchQuery.toLowerCase().includes("mousserande")))) {
        endpoint = "/api/find-importers";
        body = { query: enhancedQuery };
      }
      // Detect if searching for importer or producer
      else if (searchType === 'importer' || 
          searchQuery.toLowerCase().includes("importör") || 
          searchQuery.toLowerCase().includes("importörer") ||
          searchQuery.toLowerCase().includes("portfolio") ||
          searchQuery.toLowerCase().includes("portfölj") ||
          searchQuery.toLowerCase().includes("producent") ||
          searchQuery.toLowerCase().includes("producer")) {
        endpoint = "/api/importer-search";
        
        // Extract importer/producer name from query
        let importerName = searchQuery;
        const importerMatch = searchQuery.match(/importör[:\s]+([^\s,]+)/i);
        const producerMatch = searchQuery.match(/producent[:\s]+([^\s,]+)/i);
        
        if (importerMatch) {
          importerName = importerMatch[1];
        } else if (producerMatch) {
          importerName = producerMatch[1];
        } else {
          // Clean up common words
          importerName = searchQuery
            .replace(/portfolio\s+från\s+/i, '')
            .replace(/importör[:\s]*/i, '')
            .replace(/producent[:\s]*/i, '')
            .replace(/producer[:\s]*/i, '')
            .trim();
        }
        
        body = { importerName };
        setSearchType('importer');
      } else if (searchType === 'find-importers') {
        endpoint = "/api/find-importers";
        body = { query: enhancedQuery };
      } else {
        // Use AI search for general wine search
        endpoint = "/api/ai-wine-search";
        body = { query: enhancedQuery, preferQuick, maxResults: 10 };
      }

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error("Sökningen misslyckades");
    }

    const data = await response.json();
      
      // Track if result was cached
      setIsCached(data.cached || false);
      setCacheHitCount(data.hitCount || 0);
      
      if (data.importers) {
        // Result is a list of importers
        setImporters(data.importers);
        setResults([]); // Clear wine results when showing importers
        setSearchType('find-importers');
        
        // Set debug info for importers
        setDebugInfo({
          wineCount: data.importers.length,
          source: data.cached ? "Cache" : (data.aiGenerated ? "OpenAI" : "Mock"),
          aiGenerated: data.aiGenerated,
          endpoint: endpoint
        });
      } else if (data.wines) {
        // Fetch images for wines
        const winesWithImages = await fetchWineImages(data.wines);
        setResults(winesWithImages);
        
        if (data.importer) {
          setImporterName(data.importer);
          setSearchType('importer');
        } else {
          setSearchType('general');
        }
        
        // Set debug info for wines
        setDebugInfo({
          wineCount: winesWithImages.length,
          source: data.cached ? "Cache" : (data.aiGenerated ? "OpenAI" : "Mock"),
          aiGenerated: data.aiGenerated,
          endpoint: endpoint
        });
      }
      
      // Auto-clear search field after successful search and enable "get more"
      if (data.wines || data.importers) {
        setLastQuery(searchQuery);
        setQuery("");
        setCanGetMore(true);
        // Reset filters when new search is performed
        setFilteredResults([]);
        setShowFiltered(false);
      }
    } catch (err) {
      setError("Ett fel uppstod vid sökningen. Försök igen.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  const handleGetMoreResults = async () => {
    if (!lastQuery) return;
    
    setLoading(true);
    setSearchCounter(prev => prev + 1);
    
    // Add variation to get different results with counter, timestamp and random seed
    const timestamp = Date.now();
    const randomSeed = Math.floor(Math.random() * 10000);
    const variation = ` (ge 5 HELT ANDRA alternativ än tidigare sökning #${searchCounter + 1}, timestamp:${timestamp}, seed:${randomSeed}, undvik duplicering, variera urval maximalt)`;
    await handleSearchWithQuery(lastQuery + variation);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    handleSearchWithQuery(query);
  };

  useEffect(() => {
    if (externalQuery && externalQuery !== query) {
      setQuery(externalQuery);
      // Auto-submit when example is clicked
      if (externalQuery.trim()) {
        handleSearchWithQuery(externalQuery);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalQuery]);

  const handleApplyFilters = (newFilters: any) => {
    setFilters(newFilters);
  };
  
  const handleDirectSearch = async () => {
    // Sök direkt baserat på filter utan fritextsökning
    setLoading(true);
    setError(null);
    setResults([]);
    setImporters([]);
    
    try {
      const searchMode = filters.searchMode || 'both';
      
      // Build query from filters
      let filterQuery = '';
      if (filters.type) filterQuery += `${filters.type} `;
      if (filters.country) filterQuery += `från ${filters.country} `;
      if (filters.region) filterQuery += `${filters.region} `;
      if (filters.grape) filterQuery += `${filters.grape} `;
      if (filters.priceRange) filterQuery += `${filters.priceRange} `;
      
      if (!filterQuery.trim()) {
        filterQuery = 'populära viner'; // Default if no filters
      }
      
      if (searchMode === 'wines') {
        const response = await fetch("/api/search-wine-simple", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ 
            query: filterQuery + ' med bäst betyg', 
            preferQuick: false 
          }),
        });
        
        if (response.ok) {
          const data = await response.json();
          setResults(data.wines || []);
          setSearchType('general');
        }
      } else if (searchMode === 'importers') {
        const response = await fetch("/api/find-importers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query: filterQuery }),
        });
        
        if (response.ok) {
          const data = await response.json();
          setImporters(data.importers || []);
          setResults([]); // Clear wine results when searching only importers
          setSearchType('find-importers');
        }
      } else if (searchMode === 'both') {
        // Fetch both wines and importers
        const [winesResponse, importersResponse] = await Promise.all([
          fetch("/api/search-wine-simple", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ 
              query: filterQuery + ' med bäst betyg', 
              preferQuick: false 
            }),
          }),
          fetch("/api/find-importers", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: filterQuery }),
          })
        ]);
        
        if (winesResponse.ok && importersResponse.ok) {
          const winesData = await winesResponse.json();
          const importersData = await importersResponse.json();
          setResults(winesData.wines || []);
          setImporters(importersData.importers || []);
          setSearchType('general');
        }
      }
    } catch (err) {
      setError("Ett fel uppstod vid sökningen. Försök igen.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleViewPortfolio = async (importerName: string) => {
    setLoading(true);
    setError(null);
    setResults([]);
    setImporters([]);
    setSearchType('importer');
    setImporterName(importerName);

    try {
      const response = await fetch("/api/importer-search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ importerName }),
      });

      if (!response.ok) {
        throw new Error("Kunde inte hämta portföljen");
      }

      const data = await response.json();
      
      if (data.wines && data.wines.length > 0) {
        setResults(data.wines);
        setLastQuery(importerName);
        setQuery("");
        
        // Set debug info for portfolio
        setDebugInfo({
          wineCount: data.wines.length,
          source: data.cached ? "Cache" : (data.aiGenerated ? "OpenAI" : "Mock"),
          aiGenerated: data.aiGenerated,
          endpoint: "/api/importer-search"
        });
      } else {
        setError(data.message || `Inga viner hittades för "${importerName}".`);
      }
    } catch (err) {
      setError("Ett fel uppstod när portföljen skulle hämtas. Försök igen.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <AdvancedFilters 
        onApplyFilters={handleApplyFilters}
        onDirectSearch={handleDirectSearch}
      />
      
      <form onSubmit={handleSearch} className="mb-8">
        <div className="bg-white rounded-lg shadow-xl p-6">
          <div className="mb-4">
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-2">
              Vad letar du efter?
            </label>
            <div className="relative">
              <input
                id="search"
                type="text"
                value={query}
                onChange={(e) => handleQueryChange(e.target.value)}
                placeholder="T.ex. 'rött vin till pasta', 'Barolo', 'Importör: Philipson Söderberg', 'Producent: Gaja' eller använd avancerade filter ovan"
                className="w-full px-4 py-3 pl-12 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent text-gray-900"
              />
              <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
              {query && (
                <button
                  type="button"
                  onClick={handleClearQuery}
                  className="absolute right-4 top-3.5 p-0.5 hover:bg-gray-200 rounded-full transition-colors"
                  aria-label="Rensa sökning"
                >
                  <X className="h-4 w-4 text-gray-500 hover:text-gray-700" />
                </button>
              )}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Prioritering
            </label>
            <div className="flex gap-4">
              <button
                type="button"
                onClick={() => setPreferQuick(true)}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-all ${
                  preferQuick
                    ? "border-wine-600 bg-wine-50 text-wine-700"
                    : "border-gray-200 bg-white text-gray-600 hover:border-gray-300"
                }`}
              >
                <Clock className="h-5 w-5" />
                <span className="font-medium">Snabb tillgänglighet</span>
              </button>
              <button
                type="button"
                onClick={() => setPreferQuick(false)}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-all ${
                  !preferQuick
                    ? "border-wine-600 bg-wine-50 text-wine-700"
                    : "border-gray-200 bg-white text-gray-600 hover:border-gray-300"
                }`}
              >
                <Star className="h-5 w-5" />
                <span className="font-medium">Bästa betyg</span>
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || !query.trim()}
            className="w-full bg-wine-600 text-white py-3 rounded-lg font-semibold hover:bg-wine-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Söker...
              </>
            ) : (
              <>
                <Search className="h-5 w-5" />
                Sök vin
              </>
            )}
          </button>
        </div>
      </form>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
          {error}
        </div>
      )}

      <div className="flex items-center justify-center gap-4 mb-4">
        {isCached && <CacheIndicator cached={isCached} hitCount={cacheHitCount} />}
        
        {canGetMore && !loading && (results.length > 0 || importers.length > 0) && (
          <button
            onClick={handleGetMoreResults}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-wine-500 to-wine-600 text-white rounded-lg font-medium hover:from-wine-600 hover:to-wine-700 transition-all shadow-lg transform hover:scale-105"
          >
            <Loader2 className="h-4 w-4" />
            <span>🍷 Ska jag plocka fram 5 nya alternativ?</span>
          </button>
        )}
      </div>

      {/* Debug Info */}
      {debugInfo && (
        <DebugInfo 
          wineCount={debugInfo.wineCount}
          source={debugInfo.source}
          cached={isCached}
          aiGenerated={debugInfo.aiGenerated}
          endpoint={debugInfo.endpoint}
        />
      )}

      {results.length > 0 && searchType === 'importer' && (
        <WineTable wines={results} importer={importerName || undefined} />
      )}

      {results.length > 0 && searchType === 'general' && (
        <>
          <ResultFilters 
            wines={results}
            onFilteredResults={(filtered) => {
              setFilteredResults(filtered);
              setShowFiltered(true);
            }}
            onResultsCountChange={setDisplayCount}
          />
          <div className="grid gap-4">
          {(showFiltered && filteredResults.length > 0 ? filteredResults : results.slice(0, displayCount)).map((wine, index) => {
            // Check if wine is sponsored
            const isSponsored = (wine as any).isSponsored;
            
            if (isSponsored) {
              return (
                <SponsoredWineCard
                  key={index}
                  wine={wine as any}
                  onClick={() => onWineSelect(wine)}
                />
              );
            }
            
            return (
            <div
              key={index}
              onClick={() => onWineSelect(wine)}
              className="bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow cursor-pointer overflow-hidden"
            >
              <div className="flex">
                {/* Wine Image */}
                <div className="relative w-32 h-32 flex-shrink-0 bg-gradient-to-br from-wine-50 to-purple-100">
                  {wine.imageUrl ? (
                    <Image
                      src={wine.imageUrl}
                      alt={wine.name}
                      fill
                      sizes="128px"
                      className="object-contain p-2"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full">
                      <WineIcon className="h-12 w-12 text-wine-300 mb-2" />
                      <p className="text-xs text-gray-400 text-center px-1">Ingen bild</p>
                    </div>
                  )}
                </div>
                
                {/* Wine Details */}
                <div className="flex-1 p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-1">
                        {wine.name}
                      </h3>
                      <p className="text-gray-600 mb-2">
                        {wine.producer} • {wine.country} {wine.year ? `• ${wine.year}` : ''}
                      </p>
                      <p className="text-gray-700 mb-3 line-clamp-2">{wine.description}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-3">
                        <span className="px-3 py-1 bg-wine-100 text-wine-800 rounded-full text-sm">
                          {wine.type}
                        </span>
                        {wine.rating && (
                          <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm flex items-center gap-1">
                            <Star className="h-3 w-3 fill-current" />
                            {wine.rating}/100
                          </span>
                        )}
                        {wine.price && (
                          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                            {wine.price} kr
                          </span>
                        )}
                      </div>

                      <div className="mb-2">
                        <p className="text-sm font-semibold text-gray-700 mb-1">
                          Passar till:
                        </p>
                        <p className="text-sm text-gray-600">
                          {wine.foodPairing.join(", ")}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <button className="mt-4 w-full bg-wine-600 text-white py-2 rounded-lg font-medium hover:bg-wine-700 transition-colors">
                    Visa mer information
                  </button>
                </div>
              </div>
            </div>
            );
          })}
        </div>
        </>
      )}

      {importers.length > 0 && (
        <div className="mt-8">
          <PrivateImportInfo />
          
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-2">
              Matchande Importörer
            </h2>
            <p className="text-purple-200">
              Hittade {importers.length} importörer som matchar dina kriterier. 
              Många erbjuder privatimport med bättre priser!
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {importers.map((importer, index) => (
              <ImporterCard
                key={index}
                importer={importer}
                onViewPortfolio={handleViewPortfolio}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

