"use client";

import { SponsoredImporter } from "@/types/sponsor";
import { ExternalLink, Star } from "lucide-react";
import Image from "next/image";

interface SponsoredBannerProps {
  sponsor: SponsoredImporter;
}

export default function SponsoredBanner({ sponsor }: SponsoredBannerProps) {
  const handleClick = () => {
    // Track click for analytics
    console.log(`Banner clicked: ${sponsor.name}`);
    window.open(sponsor.website, '_blank');
  };

  return (
    <div className="bg-gradient-to-r from-amber-50 via-yellow-50 to-amber-50 border-2 border-amber-300 rounded-lg p-4 shadow-lg mb-6">
      <div className="flex items-center gap-4">
        {/* Logo */}
        {sponsor.logo && (
          <div className="relative w-16 h-16 flex-shrink-0 rounded-lg overflow-hidden bg-white p-1">
            <Image
              src={sponsor.logo}
              alt={sponsor.name}
              fill
              sizes="64px"
              className="object-contain"
            />
          </div>
        )}
        
        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-amber-700 bg-amber-200 px-2 py-0.5 rounded">
              SPONSRAD
            </span>
            <h3 className="text-lg font-bold text-gray-900 truncate">{sponsor.name}</h3>
          </div>
          <p className="text-sm text-gray-700 mb-2 line-clamp-1">{sponsor.description}</p>
          
          <div className="flex items-center gap-2">
            <div className="flex flex-wrap gap-1">
              {sponsor.specialization.slice(0, 3).map((spec, index) => (
                <span
                  key={index}
                  className="px-2 py-0.5 bg-wine-100 text-wine-800 rounded text-xs"
                >
                  {spec}
                </span>
              ))}
            </div>
          </div>
        </div>
        
        {/* CTA Button */}
        <button
          onClick={handleClick}
          className="hidden sm:inline-flex items-center gap-2 px-4 py-2 bg-wine-600 text-white rounded-lg font-medium hover:bg-wine-700 transition-colors shadow-md whitespace-nowrap"
        >
          <ExternalLink className="h-4 w-4" />
          Besök
        </button>
        
        {/* Wine Image */}
        {sponsor.featuredWines.length > 0 && sponsor.featuredWines[0].imageUrl && (
          <div className="hidden lg:block relative w-16 h-20 flex-shrink-0 rounded overflow-hidden shadow-md">
            <Image
              src={sponsor.featuredWines[0].imageUrl}
              alt={sponsor.featuredWines[0].name}
              fill
              sizes="64px"
              className="object-cover"
            />
          </div>
        )}
      </div>
    </div>
  );
}

