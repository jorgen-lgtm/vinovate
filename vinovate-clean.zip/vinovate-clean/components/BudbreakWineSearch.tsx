"use client";

import { useState, useEffect } from "react";
import { Search, Clock, Star, Loader2, Building2, X, Wine as WineIcon } from "lucide-react";
import { Wine } from "@/types/wine";
import WineTable from "./WineTable";
import AdvancedFilters from "./AdvancedFilters";
import ImporterSearchGuide from "./ImporterSearchGuide";
import ImporterCard from "./ImporterCard";
import CacheIndicator from "./CacheIndicator";
import PrivateImportInfo from "./PrivateImportInfo";
import { Importer } from "@/types/importer";
import Image from "next/image";
import SponsoredWineCard from "./SponsoredWineCard";
import ResultFilters from "./ResultFilters";

interface BudbreakWineSearchProps {
  onWineSelect: (wine: Wine) => void;
  externalQuery?: string;
  onQueryChange?: (query: string) => void;
}

export default function BudbreakWineSearch({ onWineSelect, externalQuery, onQueryChange }: BudbreakWineSearchProps) {
  const [query, setQuery] = useState(externalQuery || "");
  const [preferQuick, setPreferQuick] = useState(true);
  const [searchCounter, setSearchCounter] = useState(0);
  const [searchType, setSearchType] = useState<'general' | 'importer' | 'find-importers'>('general');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Wine[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [importerName, setImporterName] = useState<string | null>(null);
  const [filters, setFilters] = useState<any>({});
  const [importers, setImporters] = useState<Importer[]>([]);
  const [isCached, setIsCached] = useState(false);
  const [cacheHitCount, setCacheHitCount] = useState<number>(0);
  const [lastQuery, setLastQuery] = useState<string>("");
  const [canGetMore, setCanGetMore] = useState(false);
  const [filteredResults, setFilteredResults] = useState<Wine[]>([]);
  const [displayCount, setDisplayCount] = useState<number>(5);
  const [showFiltered, setShowFiltered] = useState<boolean>(false);

  const handleQueryChange = (newQuery: string) => {
    setQuery(newQuery);
    // Don't call onQueryChange here to avoid loops
  };

  const handleClearQuery = () => {
    setQuery("");
    setResults([]);
    setImporters([]);
    setError(null);
    setLastQuery("");
    setCanGetMore(false);
    setFilteredResults([]);
    setShowFiltered(false);
  };

    const fetchWineImages = async (wines: Wine[]) => {
      const winesWithImages = await Promise.all(
        wines.map(async (wine) => {
          if (!wine.imageUrl) {
            try {
              const response = await fetch('/api/systembolaget-image', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ wineType: wine.type }),
              });
              const imageData = await response.json();
              return { ...wine, imageUrl: imageData.imageUrl };
            } catch (error) {
              console.error('Error fetching wine image:', error);
              return wine;
            }
          }
          return wine;
        })
      );
      return winesWithImages;
    };

    const handleSearchWithQuery = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError(null);
    setResults([]);
    setImporters([]);
    setImporterName(null);

    // Build query with filters
    let enhancedQuery = searchQuery;
    if (filters.type) enhancedQuery += ` ${filters.type}`;
    if (filters.country) enhancedQuery += ` från ${filters.country}`;
    if (filters.region) enhancedQuery += ` ${filters.region}`;
    if (filters.grape) enhancedQuery += ` ${filters.grape}`;
    if (filters.priceRange) enhancedQuery += ` ${filters.priceRange}`;

    try {
      let endpoint = "/api/budbreak-search"; // Use Budbreak-specific search
      let body: any = { query: enhancedQuery, preferQuick, maxResults: 10 };

      // Check if user selected "importers only" in filters
      if (filters.searchMode === 'importers') {
        endpoint = "/api/find-importers";
        body = { query: enhancedQuery };
      }
      // Detect if searching for importer or producer
      else if (searchType === 'importer' || 
          searchQuery.toLowerCase().includes("importör") || 
          searchQuery.toLowerCase().includes("portfolio") ||
          searchQuery.toLowerCase().includes("portfölj") ||
          searchQuery.toLowerCase().includes("producent") ||
          searchQuery.toLowerCase().includes("producer")) {
        endpoint = "/api/importer-search";
        
        // Extract importer/producer name from query
        let importerName = searchQuery;
        const importerMatch = searchQuery.match(/importör[:\s]+([^\s,]+)/i);
        const producerMatch = searchQuery.match(/producent[:\s]+([^\s,]+)/i);
        
        if (importerMatch) {
          importerName = importerMatch[1];
        } else if (producerMatch) {
          importerName = producerMatch[1];
        } else {
          // Clean up common words
          importerName = searchQuery
            .replace(/portfolio\s+från\s+/i, '')
            .replace(/importör[:\s]*/i, '')
            .replace(/producent[:\s]*/i, '')
            .replace(/producer[:\s]*/i, '')
            .trim();
        }
        
        body = { importerName };
        setImporterName(importerName); // Set importer name for display
        setSearchType('importer');
      } else if (searchType === 'find-importers') {
        endpoint = "/api/find-importers";
        body = { query: enhancedQuery };
      } else {
        // Default to Budbreak search for general wine search
        endpoint = "/api/budbreak-search";
        body = { query: enhancedQuery, preferQuick, maxResults: 10 };
      }

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setIsCached(data.cached || false);
      setCacheHitCount(data.hitCount || 0);
      
      if (data.importers) {
        setImporters(data.importers);
        setResults([]); // Clear wine results when showing importers
        setSearchType('find-importers');
      } else if (data.wines) {
        const winesWithImages = await fetchWineImages(data.wines);
        setResults(winesWithImages);
        setSearchType('general'); // Ensure searchType is 'general' for wine results
      }
      
      if (data.wines || data.importers) {
        setLastQuery(searchQuery);
        setQuery("");
        setCanGetMore(true);
        setFilteredResults([]);
        setShowFiltered(false);
      }
    } catch (err) {
      setError("Ett fel uppstod vid sökningen. Försök igen.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  const handleGetMoreResults = async () => {
    if (!lastQuery) return;
    
    setLoading(true);
    setSearchCounter(prev => prev + 1);
    
    const variation = ` (ge 5 HELT ANDRA alternativ än tidigare sökning #${searchCounter + 1}, undvik duplicering, variera urval)`;
    await handleSearchWithQuery(lastQuery + variation);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    handleSearchWithQuery(query);
  };

  useEffect(() => {
    if (externalQuery !== undefined) {
      setQuery(externalQuery);
      if (externalQuery && externalQuery.trim()) {
        handleSearchWithQuery(externalQuery);
      }
    }
  }, [externalQuery]);

  const handleApplyFilters = (newFilters: any) => {
    setFilters(newFilters);
  };
  
  const handleDirectSearch = async (searchFilters?: any) => {
    const currentFilters = searchFilters || filters;
    setLoading(true);
    setError(null);
    setResults([]);
    setImporters([]);
    
    try {
      const searchMode = currentFilters.searchMode || 'both';
      
      let filterQuery = '';
      if (currentFilters.type) filterQuery += `${currentFilters.type} `;
      if (currentFilters.country) filterQuery += `från ${currentFilters.country} `;
      if (currentFilters.region) filterQuery += `${currentFilters.region} `;
      if (currentFilters.grape) filterQuery += `${currentFilters.grape} `;
      if (currentFilters.priceRange) filterQuery += `${currentFilters.priceRange} `;
      
      if (!filterQuery.trim()) {
        setError("Vänligen ange minst ett filter för direkt sökning.");
        setLoading(false);
        return;
      }

      let endpoint = '/api/budbreak-search'; // Use Budbreak search for direct filter search
      let body: any = { query: filterQuery, preferQuick, maxResults: 10 };

      if (searchMode === 'importer') {
        endpoint = '/api/importer-search';
        body = { importerName: filterQuery };
      } else if (searchMode === 'find-importers') {
        endpoint = '/api/find-importers';
        body = { query: filterQuery };
      }

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setIsCached(data.cached || false);
      setCacheHitCount(data.hitCount || 0);

      if (data.importers) {
        setImporters(data.importers);
        setResults([]); // Clear wine results when showing importers
        setSearchType('find-importers');
      } else if (data.wines) {
        const winesWithImages = await fetchWineImages(data.wines);
        setResults(winesWithImages);
        setSearchType('general');
      }
      
      if (data.wines || data.importers) {
        setLastQuery(filterQuery);
        setQuery("");
        setCanGetMore(true);
        setFilteredResults([]);
        setShowFiltered(false);
      }
    } catch (err) {
      setError("Ett fel uppstod vid sökningen. Försök igen.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const currentResults = showFiltered && filteredResults.length > 0 ? filteredResults : results;
  const winesToDisplay = currentResults.slice(0, displayCount);

  return (
    <div className="max-w-4xl mx-auto">
      <CacheIndicator cached={isCached} hitCount={cacheHitCount} />
      <form onSubmit={handleSearch} className="flex items-center gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => handleQueryChange(e.target.value)}
            placeholder="Sök naturviner (t.ex. 'orange vin', 'naturvin till fisk', 'Radikon')"
            className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent text-gray-900 bg-white"
            disabled={loading}
          />
          {query && (
            <button
              type="button"
              onClick={handleClearQuery}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>
        <button
          type="submit"
          className="px-4 py-2 bg-wine-600 text-white rounded-lg hover:bg-wine-700 transition-colors flex items-center gap-2"
          disabled={loading}
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Söker...
            </>
          ) : (
            <>
              <Search className="h-4 w-4" />
              Sök
            </>
          )}
        </button>
      </form>

      <AdvancedFilters 
        onApplyFilters={handleApplyFilters} 
        onDirectSearch={handleDirectSearch}
      />

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
          {error}
        </div>
      )}

      <div className="flex items-center justify-center gap-4 mb-4">
        {isCached && <CacheIndicator cached={isCached} hitCount={cacheHitCount} />}
        
        {canGetMore && !loading && (results.length > 0 || importers.length > 0) && (
          <button
            onClick={handleGetMoreResults}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-wine-500 to-wine-600 text-white rounded-lg font-medium hover:from-wine-600 hover:to-wine-700 transition-all shadow-lg transform hover:scale-105"
          >
            <Loader2 className="h-4 w-4" />
            <span>🍷 Ska jag plocka fram 5 nya alternativ?</span>
          </button>
        )}
      </div>

      {results.length > 0 && searchType === 'importer' && (
        <WineTable wines={results} importer={importerName || undefined} />
      )}

      {results.length > 0 && searchType === 'general' && (
        <>
          <ResultFilters 
            wines={results}
            onFilteredResults={(filtered) => {
              setFilteredResults(filtered);
              setShowFiltered(true);
            }}
            onResultsCountChange={setDisplayCount}
          />
          <div className="grid gap-4">
          {(showFiltered && filteredResults.length > 0 ? filteredResults : winesToDisplay).map((wine, index) => {
            const isSponsored = (wine as any).isSponsored;
            
            if (isSponsored) {
              return (
                <SponsoredWineCard
                  key={index}
                  wine={wine as any}
                  onClick={() => onWineSelect(wine)}
                />
              );
            }
            
            return (
            <div
              key={index}
              onClick={() => onWineSelect(wine)}
              className="bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow cursor-pointer overflow-hidden"
            >
              <div className="flex">
                <div className="relative w-32 h-32 flex-shrink-0 bg-gradient-to-br from-wine-50 to-purple-100">
                  {wine.imageUrl ? (
                    <Image
                      src={wine.imageUrl}
                      alt={wine.name}
                      fill
                      sizes="128px"
                      className="object-contain p-2"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full">
                      <WineIcon className="h-12 w-12 text-wine-300 mb-2" />
                      <p className="text-xs text-gray-400 text-center px-1">Ingen bild</p>
                    </div>
                  )}
                </div>
                
                <div className="flex-1 p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-1">
                        {wine.name}
                      </h3>
                      <p className="text-gray-600 mb-2">
                        {wine.producer} • {wine.country} {wine.year ? `• ${wine.year}` : ''}
                      </p>
                      <p className="text-gray-700 mb-3 line-clamp-2">{wine.description}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-3">
                        <span className="px-3 py-1 bg-wine-100 text-wine-800 rounded-full text-sm">
                          {wine.type}
                        </span>
                        {wine.rating && (
                          <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm flex items-center gap-1">
                            <Star className="h-3 w-3 fill-current" />
                            {wine.rating}/100
                          </span>
                        )}
                        {wine.price && (
                          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                            {wine.price} kr
                          </span>
                        )}
                        {(wine as any).isSponsored && (
                          <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">
                            🍷 Budbreak.se
                          </span>
                        )}
                      </div>

                      <div className="mb-2">
                        <p className="text-sm font-semibold text-gray-700 mb-1">
                          Passar till:
                        </p>
                        <p className="text-sm text-gray-600">
                          {wine.foodPairing.join(", ")}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <button className="mt-4 w-full bg-wine-600 text-white py-2 rounded-lg font-medium hover:bg-wine-700 transition-colors">
                    Visa mer information
                  </button>
                </div>
              </div>
            </div>
            );
          })}
        </div>
        </>
      )}

      {importers.length > 0 && (
        <div className="mt-8">
          <PrivateImportInfo />
          
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-2">
              Matchande Importörer
            </h2>
            <p className="text-purple-200">
              Hittade {importers.length} importörer som matchar dina kriterier. 
              Många erbjuder privatimport med bättre priser!
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {importers.map((importer, index) => (
              <ImporterCard key={index} importer={importer} onViewPortfolio={() => {}} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
