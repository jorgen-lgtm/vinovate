"use client";

import { useState } from "react";
import { MessageCircle, X, ChevronRight, Sparkles } from "lucide-react";

interface WineGuideDialogProps {
  onComplete: (query: string) => void;
}

export default function WineGuideDialog({ onComplete }: WineGuideDialogProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [answers, setAnswers] = useState({
    occasion: "",
    type: "",
    budget: "",
    taste: "",
    food: ""
  });

  const handleAnswer = (key: string, value: string) => {
    setAnswers(prev => ({ ...prev, [key]: value }));
    setStep(prev => prev + 1);
  };

  const buildQuery = () => {
    let query = "";
    
    if (answers.type) query += `${answers.type} `;
    if (answers.taste) query += `${answers.taste} `;
    if (answers.budget) query += `i prisklassen ${answers.budget} `;
    if (answers.food) query += `till ${answers.food} `;
    if (answers.occasion) query += `för ${answers.occasion}`;
    
    return query.trim() || "italienskt rött vin";
  };

  const handleComplete = () => {
    const query = buildQuery();
    onComplete(query);
    setIsOpen(false);
    resetDialog();
  };

  const resetDialog = () => {
    setStep(1);
    setAnswers({
      occasion: "",
      type: "",
      budget: "",
      taste: "",
      food: ""
    });
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-wine-600 to-wine-700 text-white rounded-full shadow-2xl hover:shadow-3xl hover:scale-105 transition-all font-medium"
      >
        <Sparkles className="h-5 w-5" />
        Hjälp mig hitta mitt perfekta vin
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full my-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-wine-600 to-wine-700 text-white p-6">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Sparkles className="h-6 w-6" />
              Din Personliga Vinguide
            </h2>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-wine-800 rounded-lg p-2 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <p className="text-wine-100 text-sm">
            Jag hjälper dig hitta det perfekta vinet genom att ställa några enkla frågor
          </p>
          <div className="mt-4 flex items-center gap-2">
            {[1, 2, 3, 4, 5].map((s) => (
              <div
                key={s}
                className={`h-2 flex-1 rounded-full ${
                  s <= step ? 'bg-white' : 'bg-wine-500'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Content - Scrollable with better contrast */}
        <div className="p-8 max-h-[calc(90vh-200px)] overflow-y-auto">
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Vad är tillfället?
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: "vardag", label: "🏠 Vardagsmiddag" },
                  { value: "fest", label: "🎉 Fest eller kalas" },
                  { value: "dejt", label: "❤️ Romantisk middag" },
                  { value: "present", label: "🎁 Present" },
                  { value: "vinprovning", label: "🍷 Vinprovning" },
                  { value: "lagring", label: "📦 Lagring/investering" }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleAnswer("occasion", option.value)}
                    className="p-4 text-left border-2 border-gray-300 rounded-lg hover:border-wine-600 hover:bg-wine-50 transition-all bg-white shadow-sm hover:shadow-md"
                  >
                    <span className="text-lg font-semibold text-gray-900">{option.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Vilken typ av vin föredrar du?
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: "rött vin", label: "🍷 Rött vin", color: "red" },
                  { value: "vitt vin", label: "🥂 Vitt vin", color: "yellow" },
                  { value: "rosé", label: "🌸 Rosévin", color: "pink" },
                  { value: "mousserande", label: "🍾 Mousserande", color: "blue" },
                  { value: "vet inte", label: "🤷 Vet inte", color: "gray" }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleAnswer("type", option.value)}
                    className="p-4 text-left border-2 border-gray-200 rounded-lg hover:border-wine-600 hover:bg-wine-50 transition-all"
                  >
                    <span className="text-lg">{option.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Vad är din budget per flaska?
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: "under 150 kr", label: "💰 Under 150 kr" },
                  { value: "150-300 kr", label: "💵 150-300 kr" },
                  { value: "300-500 kr", label: "💳 300-500 kr" },
                  { value: "500-1000 kr", label: "💎 500-1,000 kr" },
                  { value: "över 1000 kr", label: "👑 Över 1,000 kr" },
                  { value: "ingen budget", label: "∞ Ingen budget" }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleAnswer("budget", option.value)}
                    className="p-4 text-left border-2 border-gray-200 rounded-lg hover:border-wine-600 hover:bg-wine-50 transition-all"
                  >
                    <span className="text-base">{option.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Vilken smakprofil?
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: "fruktig och lättdrucket", label: "🍓 Fruktig & lätt" },
                  { value: "kraftig och fyllig", label: "💪 Kraftig & fyllig" },
                  { value: "elegant och komplex", label: "✨ Elegant & komplex" },
                  { value: "torr och mineralisk", label: "🪨 Torr & mineralisk" },
                  { value: "söt och mjuk", label: "🍯 Söt & mjuk" },
                  { value: "vet inte", label: "🤷 Vet inte" }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleAnswer("taste", option.value)}
                    className="p-4 text-left border-2 border-gray-200 rounded-lg hover:border-wine-600 hover:bg-wine-50 transition-all"
                  >
                    <span className="text-base">{option.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Vad ska vinet passa till?
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: "kött", label: "🥩 Kött" },
                  { value: "fisk", label: "🐟 Fisk & skaldjur" },
                  { value: "pasta", label: "🍝 Pasta" },
                  { value: "ost", label: "🧀 Ost" },
                  { value: "vilt", label: "🦌 Vilt" },
                  { value: "vegetariskt", label: "🥗 Vegetariskt" },
                  { value: "dessert", label: "🍰 Dessert" },
                  { value: "ingen mat", label: "🍷 Bara vinet" }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => {
                      handleAnswer("food", option.value);
                      // Move to summary after food selection
                      setTimeout(() => setStep(6), 100);
                    }}
                    className="p-4 text-left border-2 border-gray-200 rounded-lg hover:border-wine-600 hover:bg-wine-50 transition-all"
                  >
                    <span className="text-base">{option.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 6 && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Perfekt! Här är din vinprofil:
              </h3>
              
              <div className="bg-wine-50 rounded-lg p-6 space-y-3">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">🎯</span>
                  <div>
                    <p className="font-semibold text-gray-900">Tillfälle:</p>
                    <p className="text-gray-700 capitalize">{answers.occasion}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">🍷</span>
                  <div>
                    <p className="font-semibold text-gray-900">Vintyp:</p>
                    <p className="text-gray-700 capitalize">{answers.type}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">💰</span>
                  <div>
                    <p className="font-semibold text-gray-900">Budget:</p>
                    <p className="text-gray-700 capitalize">{answers.budget}</p>
                  </div>
                </div>
                {answers.taste && answers.taste !== "vet inte" && (
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">👅</span>
                    <div>
                      <p className="font-semibold text-gray-900">Smak:</p>
                      <p className="text-gray-700 capitalize">{answers.taste}</p>
                    </div>
                  </div>
                )}
                {answers.food && answers.food !== "ingen mat" && (
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">🍽️</span>
                    <div>
                      <p className="font-semibold text-gray-900">Passar till:</p>
                      <p className="text-gray-700 capitalize">{answers.food}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-purple-50 rounded-lg p-4 border-2 border-purple-200">
                <p className="text-sm text-purple-900 mb-2">
                  <strong>Din sökning kommer att vara:</strong>
                </p>
                <p className="text-purple-700 font-mono text-sm">
                  "{buildQuery()}"
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleBack}
                  className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
                >
                  Tillbaka
                </button>
                <button
                  onClick={handleComplete}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-wine-600 to-wine-700 text-white rounded-lg font-medium hover:from-wine-700 hover:to-wine-800 transition-colors flex items-center justify-center gap-2"
                >
                  Hitta viner
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          )}

          {/* Navigation for steps 1-5 */}
          {step < 6 && step > 1 && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <button
                onClick={handleBack}
                className="text-wine-600 hover:text-wine-700 font-medium text-sm"
              >
                ← Tillbaka
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

