"use client";

import { Wine } from "@/types/wine";
import { SlidersHorizontal, X } from "lucide-react";
import React, { useState } from "react";

interface ResultFiltersProps {
  wines: Wine[];
  onFilteredResults: (filtered: Wine[]) => void;
  onResultsCountChange: (count: number) => void;
}

export default function ResultFilters({ wines, onFilteredResults, onResultsCountChange }: ResultFiltersProps) {
  const [showFilters, setShowFilters] = useState(false);
  const [minRating, setMinRating] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(10000);
  const [purchaseType, setPurchaseType] = useState<string>("all");
  const [resultsCount, setResultsCount] = useState<number>(5);
  const [sortBy, setSortBy] = useState<string>("rating");

  // Auto-apply filters when settings change
  React.useEffect(() => {
    applyFilters();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [minRating, maxPrice, purchaseType, resultsCount, sortBy, wines]);

  const applyFilters = () => {
    let filtered = [...wines];

    // Separate sponsored and regular wines
    let sponsoredWines = filtered.filter(wine => (wine as any).isSponsored);
    let regularWines = filtered.filter(wine => !(wine as any).isSponsored);

    // Apply same filters to BOTH sponsored and regular wines
    
    // Filter by rating
    if (minRating > 0) {
      sponsoredWines = sponsoredWines.filter(wine => (wine.rating || 0) >= minRating);
      regularWines = regularWines.filter(wine => (wine.rating || 0) >= minRating);
    }

    // Filter by price
    if (maxPrice < 10000) {
      sponsoredWines = sponsoredWines.filter(wine => (wine.price || 0) <= maxPrice);
      regularWines = regularWines.filter(wine => (wine.price || 0) <= maxPrice);
    }

    // Filter by purchase type
    if (purchaseType === "systembolaget") {
      sponsoredWines = sponsoredWines.filter(wine => 
        wine.purchaseLocations.some(loc => !loc.isPrivateImport)
      );
      regularWines = regularWines.filter(wine => 
        wine.purchaseLocations.some(loc => !loc.isPrivateImport)
      );
    } else if (purchaseType === "private") {
      sponsoredWines = sponsoredWines.filter(wine => 
        wine.purchaseLocations.some(loc => loc.isPrivateImport)
      );
      regularWines = regularWines.filter(wine => 
        wine.purchaseLocations.some(loc => loc.isPrivateImport)
      );
    }

    // Sort both sponsored and regular wines
    const sortFunction = (a: Wine, b: Wine) => {
      if (sortBy === "rating") {
        return (b.rating || 0) - (a.rating || 0);
      } else if (sortBy === "price-asc") {
        return (a.price || 0) - (b.price || 0);
      } else if (sortBy === "price-desc") {
        return (b.price || 0) - (a.price || 0);
      }
      return 0;
    };
    
    sponsoredWines.sort(sortFunction);
    regularWines.sort(sortFunction);

    // Combine and limit to total resultsCount
    const allFiltered = [...sponsoredWines, ...regularWines];
    const finalFiltered = allFiltered.slice(0, resultsCount);

    onFilteredResults(finalFiltered);
    onResultsCountChange(resultsCount);
  };

  const resetFilters = () => {
    setMinRating(0);
    setMaxPrice(10000);
    setPurchaseType("all");
    setResultsCount(5);
    setSortBy("rating");
    onFilteredResults([]);
    onResultsCountChange(5);
  };

  return (
    <div className="mb-6">
      <button
        onClick={() => setShowFilters(!showFilters)}
        className="flex items-center gap-2 px-4 py-2 bg-white text-wine-600 rounded-lg font-medium hover:bg-wine-50 transition-colors shadow-md mb-4"
      >
        <SlidersHorizontal className="h-4 w-4" />
        {showFilters ? 'Dölj resultatfilter' : 'Filtrera resultat'}
      </button>

      {showFilters && (
        <div className="bg-white rounded-lg shadow-lg p-6 mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-gray-900">Filtrera och sortera resultat</h3>
            <button
              onClick={resetFilters}
              className="text-sm text-wine-600 hover:text-wine-700 flex items-center gap-1"
            >
              <X className="h-4 w-4" />
              Rensa filter
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Antal resultat */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Antal viner: <span className="text-wine-600 font-bold">{resultsCount}</span>
              </label>
              <select
                value={resultsCount}
                onChange={(e) => {
                  const newCount = Number(e.target.value);
                  setResultsCount(newCount);
                  onResultsCountChange(newCount);
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600"
              >
                <option value={5}>5 viner</option>
                <option value={10}>10 viner</option>
                <option value={15}>15 viner</option>
                <option value={20}>20 viner</option>
                <option value={50}>50 viner</option>
              </select>
            </div>

            {/* Sortering */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sortera efter: <span className="text-wine-600 font-bold">
                  {sortBy === 'rating' ? 'Betyg' : sortBy === 'price-asc' ? 'Pris ↑' : 'Pris ↓'}
                </span>
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600"
              >
                <option value="rating">Högst betyg först</option>
                <option value="price-asc">Lägst pris först</option>
                <option value="price-desc">Högst pris först</option>
              </select>
            </div>

            {/* Köpställe */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Köpställe: <span className="text-wine-600 font-bold">
                  {purchaseType === 'all' ? 'Alla' : purchaseType === 'systembolaget' ? 'Systembolaget' : 'Privatimport'}
                </span>
              </label>
              <select
                value={purchaseType}
                onChange={(e) => setPurchaseType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600"
              >
                <option value="all">Visa alla</option>
                <option value="systembolaget">Endast Systembolaget</option>
                <option value="private">Endast Privatimport</option>
              </select>
            </div>

            {/* Lägsta betyg */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Lägsta betyg: {minRating > 0 ? minRating : 'Alla'}
              </label>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={minRating}
                onChange={(e) => setMinRating(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Alla</span>
                <span>80</span>
                <span>90</span>
                <span>100</span>
              </div>
            </div>

            {/* Max pris */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Max pris: {maxPrice < 10000 ? `${maxPrice} kr` : 'Obegränsat'}
              </label>
              <input
                type="range"
                min="0"
                max="10000"
                step="100"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0 kr</span>
                <span>500 kr</span>
                <span>1000 kr</span>
                <span>∞</span>
              </div>
            </div>

            {/* Info text */}
            <div className="flex items-end">
              <div className="w-full px-4 py-2 bg-wine-100 text-wine-800 rounded-lg text-sm text-center">
                <p className="font-medium">Filter appliceras automatiskt</p>
                <p className="text-xs mt-1">Justera inställningarna för att filtrera resultat</p>
              </div>
            </div>
          </div>

          {/* Filter summary */}
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex flex-wrap gap-2">
                {minRating > 0 && (
                  <span className="px-3 py-1 bg-wine-100 text-wine-800 rounded-full text-sm">
                    Betyg ≥ {minRating}
                  </span>
                )}
                {maxPrice < 10000 && (
                  <span className="px-3 py-1 bg-wine-100 text-wine-800 rounded-full text-sm">
                    Pris ≤ {maxPrice} kr
                  </span>
                )}
                {purchaseType !== "all" && (
                  <span className="px-3 py-1 bg-wine-100 text-wine-800 rounded-full text-sm">
                    {purchaseType === "systembolaget" ? "Endast Systembolaget" : "Endast Privatimport"}
                  </span>
                )}
              </div>
              <span className="px-4 py-2 bg-gradient-to-r from-purple-600 to-wine-600 text-white rounded-full text-sm font-bold shadow-md">
                Visar upp till {resultsCount} viner
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

