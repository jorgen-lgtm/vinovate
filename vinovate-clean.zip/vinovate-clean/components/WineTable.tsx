"use client";

import React, { useState } from "react";
import { Wine } from "@/types/wine";
import { ChevronDown, ChevronUp, Wine as WineIcon, ShoppingCart } from "lucide-react";
import WineModal from "./WineModal";

interface WineTableProps {
  wines: Wine[];
  importer?: string;
}

export default function WineTable({ wines, importer }: WineTableProps) {
  const [sortField, setSortField] = useState<keyof Wine>("name");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [selectedWine, setSelectedWine] = useState<Wine | null>(null);
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set());

  const handleSort = (field: keyof Wine) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const sortedWines = [...wines].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    
    if (aVal === undefined || aVal === null) return 1;
    if (bVal === undefined || bVal === null) return -1;
    
    if (typeof aVal === "string" && typeof bVal === "string") {
      return sortDirection === "asc" 
        ? aVal.localeCompare(bVal)
        : bVal.localeCompare(aVal);
    }
    
    if (typeof aVal === "number" && typeof bVal === "number") {
      return sortDirection === "asc" ? aVal - bVal : bVal - aVal;
    }
    
    return 0;
  });

  const toggleRow = (index: number) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedRows(newExpanded);
  };

  const SortIcon = ({ field }: { field: keyof Wine }) => {
    if (sortField !== field) return <ChevronDown className="h-4 w-4 text-gray-400" />;
    return sortDirection === "asc" 
      ? <ChevronUp className="h-4 w-4 text-wine-600" />
      : <ChevronDown className="h-4 w-4 text-wine-600" />;
  };

  return (
    <>
      <div className="bg-white rounded-lg shadow-xl p-6 mb-6">
        {importer && (
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {importer}
            </h2>
            <p className="text-gray-600">
              Visar {wines.length} viner i portföljen
            </p>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button
                    onClick={() => handleSort("name")}
                    className="flex items-center gap-1 hover:text-gray-700"
                  >
                    Vin <SortIcon field="name" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button
                    onClick={() => handleSort("type")}
                    className="flex items-center gap-1 hover:text-gray-700"
                  >
                    Typ <SortIcon field="type" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button
                    onClick={() => handleSort("country")}
                    className="flex items-center gap-1 hover:text-gray-700"
                  >
                    Land <SortIcon field="country" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button
                    onClick={() => handleSort("year")}
                    className="flex items-center gap-1 hover:text-gray-700"
                  >
                    År <SortIcon field="year" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <button
                    onClick={() => handleSort("rating")}
                    className="flex items-center gap-1 hover:text-gray-700"
                  >
                    Betyg <SortIcon field="rating" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pris
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Åtgärder
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedWines.map((wine, index) => (
                <React.Fragment key={index}>
                  <tr 
                    className="hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() => toggleRow(index)}
                  >
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3">
                        <WineIcon className="h-5 w-5 text-wine-600 flex-shrink-0" />
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {wine.name}
                          </div>
                          <div className="text-xs text-gray-500">
                            {wine.producer}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">
                      <span className="px-2 py-1 bg-wine-100 text-wine-800 rounded-full text-xs">
                        {wine.type}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">
                      {wine.country}
                      {wine.region && (
                        <div className="text-xs text-gray-500">{wine.region}</div>
                      )}
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">
                      {wine.year || "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">
                      {wine.rating ? (
                        <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs font-semibold">
                          {wine.rating}/100
                        </span>
                      ) : (
                        "-"
                      )}
                    </td>
                    <td className="px-4 py-4 text-sm">
                      {wine.importerPrice && wine.systembolagetPrice ? (
                        <div>
                          <div className="text-gray-900 font-medium">
                            Importör: {wine.importerPrice} kr
                          </div>
                          <div className="text-gray-600 text-xs">
                            Systembolaget: {wine.systembolagetPrice} kr
                          </div>
                          {wine.importerPrice < wine.systembolagetPrice && (
                            <div className="text-green-600 text-xs font-semibold">
                              Spara {wine.systembolagetPrice - wine.importerPrice} kr!
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-gray-900 font-medium">
                          {wine.price ? `${wine.price} kr` : "-"}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-4 text-sm">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedWine(wine);
                        }}
                        className="text-wine-600 hover:text-wine-700 font-medium"
                      >
                        Visa detaljer →
                      </button>
                    </td>
                  </tr>
                  
                  {expandedRows.has(index) && (
                    <tr className="bg-wine-50">
                      <td colSpan={7} className="px-4 py-4">
                        <div className="grid md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-2">
                              🍽️ Vad ska man äta till?
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {wine.foodPairing.map((food, i) => (
                                <span
                                  key={i}
                                  className="px-3 py-1 bg-white text-wine-700 rounded-full text-xs"
                                >
                                  {food}
                                </span>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-2">
                              ⏰ När ska man dricka?
                            </h4>
                            <p className="text-gray-700">
                              {wine.bestDrinkingPeriod || "Kan drickas nu"}
                            </p>
                            {wine.servingTemperature && (
                              <p className="text-gray-600 text-xs mt-1">
                                🌡️ Serveringstemperatur: {wine.servingTemperature}
                              </p>
                            )}
                          </div>
                          
                          <div className="md:col-span-2">
                            <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                              <ShoppingCart className="h-4 w-4" />
                              Var kan man köpa?
                            </h4>
                            <div className="grid md:grid-cols-2 gap-3">
                              {wine.purchaseLocations.map((location, i) => (
                                <div key={i} className="bg-white p-3 rounded-lg">
                                  <p className="font-medium text-gray-900">
                                    {location.name}
                                  </p>
                                  <p className="text-xs text-gray-600">
                                    {location.type === 'store' ? 'Butik' : 'Online'}
                                    {location.stock && ` • ${location.stock}`}
                                  </p>
                                  {location.url && (
                                    <a
                                      href={location.url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-xs text-wine-600 hover:underline"
                                    >
                                      Besök webbplats →
                                    </a>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedWine && (
        <WineModal wine={selectedWine} onClose={() => setSelectedWine(null)} />
      )}
    </>
  );
}

