"use client";

import { Sparkles } from "lucide-react";
import { getSeasonalExamples, getCurrentSeason, getSeasonName } from "@/lib/seasonalExamples";

interface ExampleQueriesProps {
  onSelectExample: (query: string) => void;
}

export default function ExampleQueries({ onSelectExample }: ExampleQueriesProps) {
  const seasonalExamples = getSeasonalExamples();
  const season = getCurrentSeason();
  const seasonName = getSeasonName();
  
  const seasonIcons = {
    spring: '🌸',
    summer: '☀️',
    autumn: '🍂',
    winter: '❄️',
  };

  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-yellow-300" />
          <h3 className="text-lg font-semibold text-white">
            {seasonIcons[season]} {seasonName}-förslag
          </h3>
        </div>
        <span className="text-xs text-purple-200 bg-white/10 px-3 py-1 rounded-full">
          Säsongsanpassat
        </span>
      </div>
      <div className="flex flex-wrap gap-2">
        {seasonalExamples.map((example, index) => (
          <button
            key={index}
            onClick={() => onSelectExample(example.query)}
            className="px-4 py-2 bg-white/20 hover:bg-white/30 text-white rounded-full text-sm transition-colors"
          >
            {example.query}
          </button>
        ))}
      </div>
    </div>
  );
}

