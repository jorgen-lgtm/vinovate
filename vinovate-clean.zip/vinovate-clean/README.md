# 🍷 Vinovate

**Där passion möter innovation**

Vinovate är en AI-driven vinrekommendationsapp som hjälper dig hitta det perfekta vinet för varje tillfälle.

## Funktioner

- 🔍 Intelligent vinsökning med AI
- 🍽️ Matpairing med rustika recept
- 🏪 Privatimport och Systembolaget-integration
- 📊 Avancerade filter (land, region, druva, pris)
- 🎯 Importörsökning
- 💼 Sponsorsystem för importörer

## Tech Stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- OpenAI API (GPT-4o)

## Deployment

Denna app är optimerad för Vercel deployment.

© 2025 Jörgen Andersson
