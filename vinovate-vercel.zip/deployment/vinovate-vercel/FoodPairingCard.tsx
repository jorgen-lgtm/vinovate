"use client";

import { UtensilsCrossed } from "lucide-react";
import RecipeCard from "./RecipeCard";

interface FoodPairing {
  dish: string;
  description: string;
  why: string;
  recipe?: string;
}

interface FoodPairingCardProps {
  wineName: string;
  wineType: string;
  pairings: FoodPairing[];
}

export default function FoodPairingCard({ wineName, wineType, pairings }: FoodPairingCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-xl p-6 mt-6">
      <div className="flex items-center gap-3 mb-6">
        <UtensilsCrossed className="h-6 w-6 text-wine-600" />
        <h3 className="text-2xl font-bold text-gray-900">
          Perfekta maträtter till {wineName}
        </h3>
      </div>

      <p className="text-gray-600 mb-6">
        {wineType} passar utmärkt till följande rustika maträtter. Klicka på varje rätt för att se det fullständiga receptet!
      </p>

      <div className="space-y-4">
        {pairings.map((pairing, index) => (
          <RecipeCard
            key={index}
            dish={pairing.dish}
            description={pairing.description}
            recipe={pairing.recipe || "Recept kommer snart"}
            why={pairing.why}
          />
        ))}
      </div>

      <div className="mt-6 p-4 bg-purple-50 rounded-lg">
        <p className="text-sm text-gray-700">
          <strong>Pro-tips:</strong> Servera {wineType.toLowerCase()} i lagom temperatur 
          och låt det andas några minuter innan servering för att maximera smakupplevelsen 
          tillsammans med maten.
        </p>
      </div>
    </div>
  );
}

