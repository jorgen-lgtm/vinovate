"use client";

import { useState, useEffect } from "react";
import { TrendingUp, Users, DollarSign, Eye, Package, Lock, LogOut, Plus, Edit, Trash2 } from "lucide-react";
import { getAdminSession, setAdminSession, clearAdminSession } from "@/lib/auth";

interface SponsorStats {
  totalActiveSponsors: number;
  sponsorsByLevel: {
    premium: number;
    standard: number;
    basic: number;
  };
  totalFeaturedWines: number;
  adPlacements: {
    searchResults: number;
    sidebar: number;
    banner: number;
  };
  estimatedMonthlyRevenue: number;
}

interface SponsorData {
  id: string;
  name: string;
  description: string;
  website: string;
  email: string;
  phone: string;
  sponsorshipLevel: string;
  isActive: boolean;
  specialization: string[];
  featuredWines: any[];
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [stats, setStats] = useState<SponsorStats | null>(null);
  const [sponsors, setSponsors] = useState<SponsorData[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    // Check if already authenticated
    if (getAdminSession()) {
      setIsAuthenticated(true);
      fetchData();
    } else {
      setLoading(false);
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");

    try {
      const response = await fetch('/api/admin/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });

      if (response.ok) {
        setAdminSession();
        setIsAuthenticated(true);
        fetchData();
      } else {
        setAuthError("Felaktigt lösenord");
      }
    } catch (error) {
      setAuthError("Inloggning misslyckades");
    }
  };

  const handleLogout = () => {
    clearAdminSession();
    setIsAuthenticated(false);
    setPassword("");
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsRes, sponsorsRes] = await Promise.all([
        fetch('/api/sponsors/stats'),
        fetch('/api/sponsors')
      ]);
      
      const statsData = await statsRes.json();
      const sponsorsData = await sponsorsRes.json();
      
      setStats(statsData);
      setSponsors(sponsorsData.sponsors || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSponsorStatus = async (sponsorId: string, currentStatus: boolean) => {
    // In production, call API to update database
    const updatedSponsors = sponsors.map(s => 
      s.id === sponsorId ? { ...s, isActive: !currentStatus } : s
    );
    setSponsors(updatedSponsors);
    fetchData(); // Refresh stats
    
    // Show success message
    alert(`Sponsor ${currentStatus ? 'inaktiverad' : 'aktiverad'}`);
  };

  // Login screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-wine-800 to-red-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-2xl p-8 max-w-md w-full">
          <div className="text-center mb-8">
            <Lock className="h-16 w-16 text-wine-600 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Vinovate Admin</h1>
            <p className="text-gray-600">Logga in för att hantera sponsorer</p>
          </div>

          <form onSubmit={handleLogin}>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Admin-lösenord
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-wine-600 focus:border-transparent"
                placeholder="Ange lösenord"
                required
              />
            </div>

            {authError && (
              <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-700 rounded-lg text-sm">
                {authError}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-wine-600 text-white py-3 rounded-lg font-medium hover:bg-wine-700 transition-colors"
            >
              Logga in
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-500">
            <p>Standard lösenord: <code className="bg-gray-100 px-2 py-1 rounded">vinovate2025</code></p>
            <p className="mt-2 text-xs">Ändra lösenord i .env.local (ADMIN_PASSWORD)</p>
          </div>
        </div>
      </div>
    );
  }

  // Loading screen
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-wine-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Laddar...</p>
        </div>
      </div>
    );
  }

  // Admin dashboard
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-wine-600 text-white py-6 shadow-lg">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Vinovate Admin</h1>
            <p className="text-wine-100 mt-1">Där passion möter innovation - Sponsorhantering</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-wine-700 hover:bg-wine-800 rounded-lg transition-colors"
          >
            <LogOut className="h-4 w-4" />
            Logga ut
          </button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-600 font-medium">Aktiva Sponsorer</h3>
              <Users className="h-8 w-8 text-wine-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats?.totalActiveSponsors || 0}</p>
            <p className="text-sm text-gray-500 mt-2">
              Premium: {stats?.sponsorsByLevel.premium || 0} | 
              Standard: {stats?.sponsorsByLevel.standard || 0} | 
              Basic: {stats?.sponsorsByLevel.basic || 0}
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-600 font-medium">Månadsinkomst</h3>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900">
              {stats?.estimatedMonthlyRevenue.toLocaleString('sv-SE')} kr
            </p>
            <p className="text-sm text-green-600 mt-2">
              <TrendingUp className="h-4 w-4 inline mr-1" />
              Estimerad månadsintäkt
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-600 font-medium">Utvalda Viner</h3>
              <Package className="h-8 w-8 text-purple-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900">{stats?.totalFeaturedWines || 0}</p>
            <p className="text-sm text-gray-500 mt-2">Totalt antal sponsrade viner</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-600 font-medium">Annonsplatser</h3>
              <Eye className="h-8 w-8 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900">
              {(stats?.adPlacements.searchResults || 0) + 
               (stats?.adPlacements.sidebar || 0) + 
               (stats?.adPlacements.banner || 0)}
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Sök: {stats?.adPlacements.searchResults || 0} | 
              Sidebar: {stats?.adPlacements.sidebar || 0} | 
              Banner: {stats?.adPlacements.banner || 0}
            </p>
          </div>
        </div>

        {/* Sponsor Management */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Hantera Sponsorer</h2>
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="flex items-center gap-2 px-4 py-2 bg-wine-600 text-white rounded-lg hover:bg-wine-700 transition-colors"
            >
              <Plus className="h-4 w-4" />
              Lägg till sponsor
            </button>
          </div>

          {/* Add Sponsor Form */}
          {showAddForm && (
            <div className="mb-6 p-6 bg-gray-50 rounded-lg border-2 border-wine-200">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Lägg till ny sponsor</h3>
              <p className="text-sm text-gray-600 mb-4">
                I produktion kommer detta formulär att spara till databas. Just nu är det endast för demonstration.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Företagsnamn"
                  className="px-4 py-2 border rounded-lg"
                />
                <input
                  type="email"
                  placeholder="Email"
                  className="px-4 py-2 border rounded-lg"
                />
                <input
                  type="text"
                  placeholder="Telefon"
                  className="px-4 py-2 border rounded-lg"
                />
                <input
                  type="url"
                  placeholder="Webbplats"
                  className="px-4 py-2 border rounded-lg"
                />
                <select className="px-4 py-2 border rounded-lg">
                  <option>Premium - 15,000 kr/mån</option>
                  <option>Standard - 8,000 kr/mån</option>
                  <option>Basic - 3,000 kr/mån</option>
                </select>
                <button className="px-4 py-2 bg-wine-600 text-white rounded-lg hover:bg-wine-700">
                  Spara sponsor
                </button>
              </div>
            </div>
          )}

          {/* Sponsors List */}
          <div className="space-y-4">
            {sponsors.map((sponsor) => (
              <div
                key={sponsor.id}
                className={`p-4 rounded-lg border-2 ${
                  sponsor.isActive 
                    ? 'bg-green-50 border-green-300' 
                    : 'bg-gray-50 border-gray-300'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-bold text-gray-900">{sponsor.name}</h3>
                      <span className={`px-2 py-1 text-xs font-semibold rounded ${
                        sponsor.sponsorshipLevel === 'premium'
                          ? 'bg-yellow-200 text-yellow-800'
                          : sponsor.sponsorshipLevel === 'standard'
                          ? 'bg-blue-200 text-blue-800'
                          : 'bg-gray-200 text-gray-800'
                      }`}>
                        {sponsor.sponsorshipLevel.toUpperCase()}
                      </span>
                      <span className={`px-2 py-1 text-xs font-semibold rounded ${
                        sponsor.isActive
                          ? 'bg-green-200 text-green-800'
                          : 'bg-red-200 text-red-800'
                      }`}>
                        {sponsor.isActive ? 'AKTIV' : 'INAKTIV'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{sponsor.description}</p>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {sponsor.specialization.map((spec, i) => (
                        <span key={i} className="px-2 py-1 bg-wine-100 text-wine-800 text-xs rounded">
                          {spec}
                        </span>
                      ))}
                    </div>
                    <div className="text-xs text-gray-500">
                      📧 {sponsor.email} | 📞 {sponsor.phone} | 🌐 {sponsor.website}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Utvalda viner: {sponsor.featuredWines.length}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => toggleSponsorStatus(sponsor.id, sponsor.isActive)}
                      className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                        sponsor.isActive
                          ? 'bg-red-100 text-red-700 hover:bg-red-200'
                          : 'bg-green-100 text-green-700 hover:bg-green-200'
                      }`}
                    >
                      {sponsor.isActive ? 'Inaktivera' : 'Aktivera'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sponsorship Packages Info */}
        <div className="bg-gradient-to-r from-wine-600 to-wine-700 rounded-lg shadow-md p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">Intresserad av att annonsera?</h2>
          <p className="mb-6 text-wine-100">
            Nå tusentals vinentusiaster varje månad! Kontakta oss för att diskutera ett skräddarsytt sponsorpaket.
          </p>
          <div className="flex flex-wrap gap-4">
            <a
              href="mailto:annons@vinovate.se"
              className="px-6 py-3 bg-white text-wine-600 rounded-lg font-medium hover:bg-gray-100 transition-colors"
            >
              📧 annons@vinovate.se
            </a>
            <a
              href="tel:+46701234567"
              className="px-6 py-3 bg-wine-500 text-white rounded-lg font-medium hover:bg-wine-400 transition-colors"
            >
              📞 070-123 45 67
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
