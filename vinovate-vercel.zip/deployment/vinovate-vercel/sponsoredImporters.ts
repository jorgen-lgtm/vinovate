import { SponsoredImporter } from "@/types/sponsor";

// Mock data for sponsored importers
// In production, this would come from a database
export const sponsoredImporters: SponsoredImporter[] = [
  {
    id: "demo-sponsor",
    name: "Vinovate Demo Wines",
    description: "Demo-importör för att visa sponsorfunktionalitet. Exklusiva italienska och franska viner med fokus på kvalitet.",
    logo: "https://images.unsplash.com/photo-1474552226712-ac0f0961a954?w=200&h=200&fit=crop",
    website: "https://demo.vinovate.se",
    email: "demo@vinovate.se",
    phone: "08-111 22 33",
    specialization: ["Italien", "Frankrike", "Premium", "Rött vin", "Vitt vin"],
    
    sponsorshipLevel: "premium",
    sponsorshipStartDate: "2025-01-01",
    sponsorshipEndDate: "2025-12-31",
    isActive: true, // DEMO - Aktiverad för demonstration
    
    featuredWines: [
      {
        name: "Super Tuscan Reserva",
        producer: "Vinovate Selections",
        type: "Rött vin",
        country: "Italien",
        region: "Toscana",
        year: "2019",
        price: 450,
        rating: 94,
        description: "Exklusiv Super Tuscan med Cabernet Sauvignon och Sangiovese. Kraftfull struktur och elegant finish.",
        imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop",
        systembolagetNumber: "DEMO001"
      },
      {
        name: "Chablis Premier Cru",
        producer: "Vinovate Selections",
        type: "Vitt vin",
        country: "Frankrike",
        region: "Bourgogne",
        year: "2021",
        price: 320,
        rating: 92,
        description: "Elegant Chablis med mineralitet och frisk syra. Perfekt till fisk och skaldjur.",
        imageUrl: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300&h=400&fit=crop",
        systembolagetNumber: "DEMO002"
      }
    ],
    
    adSettings: {
      showInSearchResults: true,
      showInSidebar: true,
      showBanner: true,
      priority: 10
    }
  },
  {
    id: "sponsor-1",
    name: "Vinguiden Premium",
    description: "Sveriges ledande importör av exklusiva italienska viner. Specialiserade på Barolo, Brunello och Amarone.",
    logo: "https://images.unsplash.com/photo-1474552226712-ac0f0961a954?w=200&h=200&fit=crop",
    website: "https://vinguiden.se",
    email: "info@vinguiden.se",
    phone: "08-123 45 67",
    specialization: ["Italien", "Piemonte", "Toscana", "Rött vin"],
    
    sponsorshipLevel: "premium",
    sponsorshipStartDate: "2025-01-01",
    sponsorshipEndDate: "2025-12-31",
    isActive: false, // Inaktiverad som standard - aktivera via admin
    
    featuredWines: [
      {
        name: "Barolo Sperss",
        producer: "Gaja",
        type: "Rött vin",
        country: "Italien",
        region: "Piemonte",
        year: "2019",
        price: 750,
        rating: 96,
        description: "Exceptionell Barolo från Gaja. Kraftfull struktur med elegant finish. Perfekt för lagring.",
        imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=300&h=400&fit=crop",
        systembolagetNumber: "8765402"
      },
      {
        name: "Brunello di Montalcino Riserva",
        producer: "Biondi-Santi",
        type: "Rött vin",
        country: "Italien",
        region: "Toscana",
        year: "2016",
        price: 1200,
        rating: 97,
        description: "Legendarisk Brunello från vinets födelseplats. Komplex och åldringsvärd.",
        imageUrl: "https://images.unsplash.com/photo-1547595628-c61a29f496f0?w=300&h=400&fit=crop",
        systembolagetNumber: "9876543"
      }
    ],
    
    adSettings: {
      showInSearchResults: true,
      showInSidebar: true,
      showBanner: true,
      priority: 10
    }
  },
  {
    id: "sponsor-2",
    name: "Winepeople Selections",
    description: "Handplockade viner från små producenter i Italien och Frankrike. Fokus på kvalitet och hållbarhet.",
    logo: "https://images.unsplash.com/photo-1569529465841-dfecdab7503b?w=200&h=200&fit=crop",
    website: "https://winepeople.se",
    email: "bestall@winepeople.se",
    phone: "031-123 45 67",
    specialization: ["Italien", "Frankrike", "Ekologiskt", "Biodynamiskt"],
    
    sponsorshipLevel: "standard",
    sponsorshipStartDate: "2025-01-01",
    sponsorshipEndDate: "2025-06-30",
    isActive: false, // Inaktiverad som standard - aktivera via admin
    
    featuredWines: [
      {
        name: "Amarone Classico",
        producer: "Allegrini",
        type: "Rött vin",
        country: "Italien",
        region: "Veneto",
        year: "2017",
        price: 320,
        rating: 91,
        description: "Kraftfull Amarone med rik smak av torkad frukt. Ekologiskt odlad.",
        imageUrl: "https://images.unsplash.com/photo-1584916201218-f4242ceb4809?w=300&h=400&fit=crop",
        systembolagetNumber: "9234567"
      }
    ],
    
    adSettings: {
      showInSearchResults: true,
      showInSidebar: true,
      showBanner: false,
      priority: 7
    }
  },
  {
    id: "sponsor-3",
    name: "Italienska Vinakademien",
    description: "Experter på italienska viner med 25 års erfarenhet. Privatimport av exklusiva etiketter.",
    logo: "https://images.unsplash.com/photo-1566754436-d9e8ba4e5f8d?w=200&h=200&fit=crop",
    website: "https://vinakademien.se",
    email: "kontakt@vinakademien.se",
    phone: "08-987 65 43",
    specialization: ["Italien", "Piemonte", "Toscana", "Sicilien"],
    
    sponsorshipLevel: "basic",
    sponsorshipStartDate: "2025-01-01",
    sponsorshipEndDate: "2025-03-31",
    isActive: false, // Inaktiverad som standard - aktivera via admin
    
    featuredWines: [
      {
        name: "Chianti Classico Gran Selezione",
        producer: "Castello di Ama",
        type: "Rött vin",
        country: "Italien",
        region: "Toscana",
        year: "2019",
        price: 280,
        rating: 90,
        description: "Premium Chianti med djup komplexitet. Perfekt till italiensk mat.",
        imageUrl: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=300&h=400&fit=crop",
        systembolagetNumber: "7654321"
      }
    ],
    
    adSettings: {
      showInSearchResults: true,
      showInSidebar: false,
      showBanner: false,
      priority: 5
    }
  }
];

// Get active sponsored importers sorted by priority
export function getActiveSponsoredImporters(): SponsoredImporter[] {
  const now = new Date();
  return sponsoredImporters
    .filter(sponsor => {
      if (!sponsor.isActive) return false;
      const startDate = new Date(sponsor.sponsorshipStartDate);
      const endDate = new Date(sponsor.sponsorshipEndDate);
      return now >= startDate && now <= endDate;
    })
    .sort((a, b) => b.adSettings.priority - a.adSettings.priority);
}

// Get a random sponsored wine for search results that matches the query
export function getSponsoredWineForSearch(query?: string): any {
  const activeSponsors = getActiveSponsoredImporters();
  if (activeSponsors.length === 0) return null;
  
  // Extract wine type from query
  let desiredWineType: string | null = null;
  let specificWine = null;
  
  if (query) {
    const lowerQuery = query.toLowerCase();
    
    // Explicit wine type mentions
    if (/(vitt|white)/.test(lowerQuery)) desiredWineType = "Vitt vin";
    else if (/(rött|rott|red)/.test(lowerQuery)) desiredWineType = "Rött vin";
    else if (/(rosé|rose)/.test(lowerQuery)) desiredWineType = "Rosévin";
    else if (/(mousserande|champagne|cava|prosecco|sparkling)/.test(lowerQuery)) desiredWineType = "Mousserande vin";
    
    // Context-based inference
    else if (/(barolo|amarone|brunello|chianti|bordeaux|cabernet|merlot|syrah|primitivo|montepulciano|nebbiolo|barbera|valpolicella|viltkött|vilt|oxfilé|lammstek|gryta|ragu|kraftfullt|fylligt)/.test(lowerQuery)) {
      desiredWineType = "Rött vin";
    }
    else if (/(chablis|sancerre|riesling|sauvignon blanc|chardonnay|albariño|pinot grigio|fisk|skaldjur|ostron)/.test(lowerQuery)) {
      desiredWineType = "Vitt vin";
    }
    
    // Specific wine/region mentions for sponsored wines
    const specificWineMentions = {
      barolo: { country: "Italien", region: "Piemonte", type: "Rött vin" },
      amarone: { country: "Italien", region: "Veneto", type: "Rött vin" },
      brunello: { country: "Italien", region: "Toscana", type: "Rött vin" },
      chianti: { country: "Italien", region: "Toscana", type: "Rött vin" },
      bordeaux: { country: "Frankrike", region: "Bordeaux", type: "Rött vin" },
      chablis: { country: "Frankrike", region: "Bourgogne", type: "Vitt vin" },
      sancerre: { country: "Frankrike", region: "Loire", type: "Vitt vin" }
    };
    
    for (const [wineName, wineInfo] of Object.entries(specificWineMentions)) {
      if (lowerQuery.includes(wineName)) {
        specificWine = wineInfo;
        break;
      }
    }
  }
  
  // Filter sponsors based on query if provided
  let relevantSponsors = activeSponsors;
  if (query) {
    const lowerQuery = query.toLowerCase();
    relevantSponsors = activeSponsors.filter(sponsor => {
      // Check if sponsor specializes in what user is searching for
      const matchesSpecialization = sponsor.specialization.some(spec => 
        lowerQuery.includes(spec.toLowerCase()) || spec.toLowerCase().includes(lowerQuery)
      );
      
      // Check if any featured wines match the query
      const hasMatchingWine = sponsor.featuredWines.some(wine => {
        const wineMatches = wine.name.toLowerCase().includes(lowerQuery) ||
          wine.country.toLowerCase().includes(lowerQuery) ||
          wine.region.toLowerCase().includes(lowerQuery) ||
          wine.type.toLowerCase().includes(lowerQuery);
        
        // If we have a specific wine type requirement, check it
        if (desiredWineType && wine.type !== desiredWineType) {
          return false;
        }
        
        return wineMatches;
      });
      
      return matchesSpecialization || hasMatchingWine;
    });
  }
  
  if (relevantSponsors.length === 0) return null;
  
  // Weighted random selection based on priority
  const totalPriority = relevantSponsors.reduce((sum, s) => sum + s.adSettings.priority, 0);
  let random = Math.random() * totalPriority;
  
  for (const sponsor of relevantSponsors) {
    random -= sponsor.adSettings.priority;
    if (random <= 0 && sponsor.featuredWines.length > 0) {
      // Find best matching wine from sponsor
      let selectedWine = sponsor.featuredWines[0];
      if (query) {
        const lowerQuery = query.toLowerCase();
        const matchingWines = sponsor.featuredWines.filter(wine => {
          // If we have a specific wine mention, prioritize exact matches
          if (specificWine) {
            if (wine.country !== specificWine.country || wine.type !== specificWine.type) {
              return false;
            }
            if (specificWine.region && !wine.region.toLowerCase().includes(specificWine.region.toLowerCase())) {
              return false;
            }
            return true;
          }
          
          const wineMatches = wine.name.toLowerCase().includes(lowerQuery) ||
            wine.country.toLowerCase().includes(lowerQuery) ||
            wine.region.toLowerCase().includes(lowerQuery) ||
            wine.type.toLowerCase().includes(lowerQuery);
          
          // If we have a specific wine type requirement, check it
          if (desiredWineType && wine.type !== desiredWineType) {
            return false;
          }
          
          return wineMatches;
        });
        if (matchingWines.length > 0) {
          selectedWine = matchingWines[Math.floor(Math.random() * matchingWines.length)];
        } else if (desiredWineType) {
          // If no matching wines but we have a type requirement, try to find any wine of that type
          const typeMatchingWines = sponsor.featuredWines.filter(wine => wine.type === desiredWineType);
          if (typeMatchingWines.length > 0) {
            selectedWine = typeMatchingWines[Math.floor(Math.random() * typeMatchingWines.length)];
          } else {
            // No wine of the required type, return null
            return null;
          }
        }
      }
      
      const wine = selectedWine;
      return {
        ...wine,
        isSponsored: true,
        sponsorName: sponsor.name,
        sponsorWebsite: sponsor.website,
        sponsorEmail: sponsor.email,
        sponsorPhone: sponsor.phone,
        foodPairing: ["Kött", "Pasta", "Ost"], // Default
        availability: "better",
        tastingNotes: wine.description,
        purchaseLocations: [
          {
            name: sponsor.name,
            type: "private-import",
            url: sponsor.website,
            stock: "I lager",
            price: wine.price,
            isPrivateImport: true,
            minimumOrder: "6 flaskor",
            importerContact: {
              email: sponsor.email,
              phone: sponsor.phone,
              orderUrl: sponsor.website
            }
          },
          {
            name: "Systembolaget",
            type: "store",
            stock: "Finns i utvalda butiker",
            price: wine.price + 50,
            isPrivateImport: false
          }
        ]
      };
    }
  }
  
  return null;
}

// Get sponsors for sidebar ads
export function getSidebarSponsors(): SponsoredImporter[] {
  return getActiveSponsoredImporters()
    .filter(s => s.adSettings.showInSidebar)
    .slice(0, 2); // Max 2 sidebar ads
}

// Get sponsors for banner ads
export function getBannerSponsors(): SponsoredImporter[] {
  return getActiveSponsoredImporters()
    .filter(s => s.adSettings.showBanner)
    .slice(0, 1); // Max 1 banner ad
}

// Sponsorship packages for potential advertisers
export const sponsorshipPackages = [
  {
    id: "premium",
    name: "Premium Paket",
    level: "premium" as const,
    price: 15000,
    features: {
      searchResultPlacements: 100,
      sidebarAds: true,
      bannerAds: true,
      featuredWinesCount: 5,
      priority: 10
    },
    description: "Maximal synlighet med garanterad placering i varje sökning och alla annonsplatser."
  },
  {
    id: "standard",
    name: "Standard Paket",
    level: "standard" as const,
    price: 8000,
    features: {
      searchResultPlacements: 50,
      sidebarAds: true,
      bannerAds: false,
      featuredWinesCount: 3,
      priority: 7
    },
    description: "Bra synlighet med regelbunden placering i sökresultat och sidebar."
  },
  {
    id: "basic",
    name: "Basic Paket",
    level: "basic" as const,
    price: 3000,
    features: {
      searchResultPlacements: 20,
      sidebarAds: false,
      bannerAds: false,
      featuredWinesCount: 1,
      priority: 5
    },
    description: "Grundläggande synlighet med placering i sökresultat."
  }
];

