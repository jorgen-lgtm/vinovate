"use client";

import { useState } from "react";
import { ChefHat, Clock, Users, ChevronDown, ChevronUp, Sparkles } from "lucide-react";

interface RecipeCardProps {
  dish: string;
  description: string;
  recipe: string;
  why: string;
}

export default function RecipeCard({ dish, description, recipe, why }: RecipeCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  // Parse recipe into structured format
  const parseRecipe = (recipeText: string) => {
    const lines = recipeText.split('\n').filter(line => line.trim());
    const ingredients: string[] = [];
    const instructions: string[] = [];
    let currentSection: 'ingredients' | 'instructions' | 'other' = 'other';
    let cookingTime = '';
    let tips = '';

    lines.forEach(line => {
      const lowerLine = line.toLowerCase();
      if (lowerLine.includes('ingrediens') || lowerLine.includes('ingredient')) {
        currentSection = 'ingredients';
      } else if (lowerLine.includes('instruktion') || lowerLine.includes('steg') || lowerLine.includes('gör så')) {
        currentSection = 'instructions';
      } else if (lowerLine.includes('tillagning') || lowerLine.includes('tid:')) {
        cookingTime = line.replace(/^[^\d]*/, '').trim();
      } else if (lowerLine.includes('tips') || lowerLine.includes('pro-tip')) {
        tips = line.replace(/^[^:]*:?\s*/, '').trim();
      } else if (line.trim().startsWith('-') || line.trim().match(/^\d+[\.\)]/)) {
        if (currentSection === 'ingredients') {
          ingredients.push(line.replace(/^[-\d\.\)]\s*/, '').trim());
        } else if (currentSection === 'instructions') {
          instructions.push(line.replace(/^[-\d\.\)]\s*/, '').trim());
        }
      }
    });

    return { ingredients, instructions, cookingTime, tips };
  };

  const { ingredients, instructions, cookingTime, tips } = parseRecipe(recipe);

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden hover:border-wine-300 hover:shadow-lg transition-all">
      <div
        className="bg-gradient-to-r from-wine-50 to-purple-50 p-5 cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <ChefHat className="h-5 w-5 text-wine-600" />
              <h4 className="text-xl font-bold text-gray-900">{dish}</h4>
            </div>
            <p className="text-sm text-gray-700 mb-3">{description}</p>
            
            <div className="flex items-center gap-4 text-xs text-gray-600">
              {cookingTime && (
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  <span>{cookingTime}</span>
                </div>
              )}
              <div className="flex items-center gap-1">
                <Users className="h-3 w-3" />
                <span>4 portioner</span>
              </div>
            </div>
          </div>
          
          <button className="p-2 hover:bg-white/50 rounded-full transition-colors">
            {isExpanded ? (
              <ChevronUp className="h-5 w-5 text-wine-600" />
            ) : (
              <ChevronDown className="h-5 w-5 text-wine-600" />
            )}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="p-5 bg-white">
          {/* Why it pairs well */}
          <div className="mb-6 p-4 bg-wine-50 rounded-lg">
            <div className="flex items-start gap-2">
              <Sparkles className="h-4 w-4 text-wine-600 flex-shrink-0 mt-1" />
              <div>
                <p className="text-sm font-semibold text-wine-900 mb-1">
                  Varför passar det här vinet?
                </p>
                <p className="text-sm text-wine-800">{why}</p>
              </div>
            </div>
          </div>

          {/* Ingredients */}
          {ingredients.length > 0 && (
            <div className="mb-6">
              <h5 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                📋 Ingredienser
              </h5>
              <ul className="space-y-2">
                {ingredients.map((ingredient, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-gray-700">
                    <span className="text-wine-600 font-bold">•</span>
                    <span>{ingredient}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Instructions */}
          {instructions.length > 0 && (
            <div className="mb-6">
              <h5 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                👨‍🍳 Gör så här
              </h5>
              <ol className="space-y-3">
                {instructions.map((instruction, index) => (
                  <li key={index} className="flex gap-3 text-sm text-gray-700">
                    <span className="flex-shrink-0 w-6 h-6 bg-wine-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                      {index + 1}
                    </span>
                    <span className="pt-0.5">{instruction}</span>
                  </li>
                ))}
              </ol>
            </div>
          )}

          {/* Pro tips */}
          {tips && (
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-gray-700">
                <strong className="text-yellow-900">💡 Pro-tips:</strong>{' '}
                {tips}
              </p>
            </div>
          )}

          {/* If no structured data, show raw recipe */}
          {ingredients.length === 0 && instructions.length === 0 && (
            <div className="prose prose-sm max-w-none">
              <p className="text-sm text-gray-700 whitespace-pre-line">{recipe}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

