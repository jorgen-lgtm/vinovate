"use client";

import { useState } from "react";
import BudbreakWineSearch from "@/components/BudbreakWineSearch";
import WineModal from "@/components/WineModal";
import { Wine } from "@/types/wine";
import { getSeasonalGreeting } from "@/lib/seasonalExamples";
import SponsoredBanner from "@/components/SponsoredBanner";
import SponsoredSidebar from "@/components/SponsoredSidebar";
import { getBannerSponsors, getSidebarSponsors } from "@/data/sponsoredImporters";

export default function DemoBB() {
  const [selectedWine, setSelectedWine] = useState<Wine | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const seasonalGreeting = getSeasonalGreeting();
  
  // Demo sponsors - Budbreak.se som huvudsponsor
  const bannerSponsors = [
    {
      id: "budbreak-demo",
      name: "Budbreak.se",
      description: "Ärliga, ursprungstypiska viner av genuina vinbönder som vi respekterar och beundrar",
      logo: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjgwIiB2aWV3Qm94PSIwIDAgMjAwIDgwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8ZGVmcz4KPGxpbmVhckdyYWRpZW50IGlkPSJncmFkIiB4MT0iMCUiIHkxPSIwJSIgeDI9IjEwMCUiIHkyPSIxMDAlIj4KPHN0b3Agb2Zmc2V0PSIwJSIgc3R5bGU9InN0b3AtY29sb3I6IzJENzM0QjtzdG9wLW9wYWNpdHk6MSIgLz4KPHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojMzg0QTU2O3N0b3Atb3BhY2l0eToxIiAvPgo8L2xpbmVhckdyYWRpZW50Pgo8L2RlZnM+CjxyZWN0IHdpZHRoPSIyMDAiIGhlaWdodD0iODAiIGZpbGw9InVybCgjZ3JhZCkiIHJ4PSI4Ii8+Cjx0ZXh0IHg9IjEwMCIgeT0iNDUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5CdWRicmVhay5zZTwvdGV4dD4KPC9zdmc+",
      website: "https://budbreak.se",
      email: "info@budbreak.se",
      phone: "08-123 45 67",
      specialization: ["Naturviner", "Biodynamiska viner", "Orange viner", "Pet Nat", "Kvalitetsviner", "Små producenter"],
      sponsorshipLevel: "premium" as const,
      sponsorshipStartDate: "2025-01-01",
      sponsorshipEndDate: "2025-12-31",
      isActive: true,
      featuredWines: [],
      adSettings: {
        showInSearchResults: true,
        showInSidebar: true,
        showBanner: true,
        priority: 10
      }
    }
  ];
  
  const sidebarSponsors = [
    {
      id: "budbreak-sidebar",
      name: "Budbreak.se",
      description: "Ärliga, ursprungstypiska viner av genuina vinbönder",
      logo: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjgwIiB2aWV3Qm94PSIwIDAgMjAwIDgwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8ZGVmcz4KPGxpbmVhckdyYWRpZW50IGlkPSJncmFkIiB4MT0iMCUiIHkxPSIwJSIgeDI9IjEwMCUiIHkyPSIxMDAlIj4KPHN0b3Agb2Zmc2V0PSIwJSIgc3R5bGU9InN0b3AtY29sb3I6IzJENzM0QjtzdG9wLW9wYWNpdHk6MSIgLz4KPHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojMzg0QTU2O3N0b3Atb3BhY2l0eToxIiAvPgo8L2xpbmVhckdyYWRpZW50Pgo8L2RlZnM+CjxyZWN0IHdpZHRoPSIyMDAiIGhlaWdodD0iODAiIGZpbGw9InVybCgjZ3JhZCkiIHJ4PSI4Ii8+Cjx0ZXh0IHg9IjEwMCIgeT0iNDUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5CdWRicmVhay5zZTwvdGV4dD4KPC9zdmc+",
      website: "https://budbreak.se",
      email: "info@budbreak.se",
      phone: "08-123 45 67",
      specialization: ["Naturviner", "Biodynamiska viner", "Kvalitetsviner"],
      sponsorshipLevel: "premium" as const,
      sponsorshipStartDate: "2025-01-01",
      sponsorshipEndDate: "2025-12-31",
      isActive: true,
      featuredWines: [],
      adSettings: {
        showInSearchResults: true,
        showInSidebar: true,
        showBanner: false,
        priority: 10
      }
    }
  ];

  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-900 via-wine-800 to-red-900">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <div className="mb-4">
            <div className="inline-block bg-white/10 backdrop-blur-sm rounded-lg px-6 py-3 mb-4">
              <p className="text-yellow-300 font-semibold text-lg">
                🍷 DEMO FÖR BUDBREAK.SE
              </p>
            </div>
          </div>
          <h1 className="text-6xl font-bold text-white mb-4 tracking-tight">
            🍷 Vinovate
          </h1>
          <p className="text-2xl text-purple-100 mb-3 font-semibold">
            Där passion möter innovation
          </p>
          <p className="text-lg text-purple-200 mb-2">
            Upptäck ditt perfekta vin med AI-driven precision
          </p>
          <p className="text-sm text-purple-300 italic">
            {seasonalGreeting}
          </p>
        </header>

        <div className="max-w-7xl mx-auto">
          {/* Banner ad - Full width across top */}
          {bannerSponsors.length > 0 && (
            <div className="mb-6">
              <SponsoredBanner sponsor={bannerSponsors[0]} />
            </div>
          )}
          
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Main content area */}
            <div className="lg:col-span-3">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 mb-6">
                <h2 className="text-2xl font-bold text-white mb-4">
                  🎯 Demo för Budbreak.se
                </h2>
                <div className="text-purple-100 space-y-2">
                  <p>• <strong>Huvudsponsor:</strong> Budbreak.se visas i banner och sidebar</p>
                  <p>• <strong>Prislista:</strong> Alla Budbreak-viner är inlästa med riktiga priser</p>
                  <p>• <strong>Producenter:</strong> Komplett portfölj från naturvinsimportören</p>
                  <p>• <strong>Fokus:</strong> Ärliga, ursprungstypiska viner från genuina vinbönder</p>
                </div>
                
              </div>
              
              <BudbreakWineSearch 
                onWineSelect={setSelectedWine} 
                externalQuery={searchQuery}
                onQueryChange={setSearchQuery}
              />
            </div>
            
            {/* Sidebar with ads */}
            <div className="lg:col-span-1">
              <div className="sticky top-4">
                <SponsoredSidebar sponsors={sidebarSponsors} />
              </div>
            </div>
          </div>
        </div>

        {selectedWine && (
          <WineModal
            wine={selectedWine}
            onClose={() => setSelectedWine(null)}
          />
        )}
        
        
        <div className="mt-12 text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-4xl mx-auto">
            <h3 className="text-xl font-bold text-white mb-4">
              📊 Demo-statistik för Budbreak.se
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-purple-100">
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-2xl font-bold text-yellow-300">50</p>
                <p className="text-sm">Viner i demo-portföljen</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-2xl font-bold text-yellow-300">12</p>
                <p className="text-sm">Producenter</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-2xl font-bold text-yellow-300">8</p>
                <p className="text-sm">Länder</p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-2xl font-bold text-yellow-300">100%</p>
                <p className="text-sm">Naturviner & Biodynamiska</p>
              </div>
            </div>
            
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4 text-purple-100">
              <div className="bg-white/5 rounded-lg p-4">
                <h4 className="text-lg font-semibold text-white mb-3">Vintyper</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Naturviner:</span>
                    <span className="text-yellow-300 font-semibold">32 viner</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Orange viner:</span>
                    <span className="text-yellow-300 font-semibold">8 viner</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Biodynamiska:</span>
                    <span className="text-yellow-300 font-semibold">10 viner</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4">
                <h4 className="text-lg font-semibold text-white mb-3">Länder</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Frankrike:</span>
                    <span className="text-yellow-300 font-semibold">18 viner</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Italien:</span>
                    <span className="text-yellow-300 font-semibold">12 viner</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Spanien:</span>
                    <span className="text-yellow-300 font-semibold">8 viner</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Övriga:</span>
                    <span className="text-yellow-300 font-semibold">12 viner</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="mt-16 pb-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mt-4 text-white/40 text-xs">
            <p>© 2025 Jörgen Andersson • Drick ansvarsfullt 🍷</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
