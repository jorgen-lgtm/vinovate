import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { 
  getCachedResult, 
  cacheSearchResult, 
  recordCacheHit, 
  recordCacheMiss 
} from "@/lib/searchCache";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json();

    if (!query) {
      return NextResponse.json(
        { error: "Query is required" },
        { status: 400 }
      );
    }

    // Check cache first
    const cached = getCachedResult(query, {}, 'find-importers');
    if (cached && cached.results.importers) {
      recordCacheHit();
      return NextResponse.json({ 
        importers: cached.results.importers,
        cached: true,
        hitCount: cached.hitCount
      });
    }
    
    recordCacheMiss();

    const prompt = `Du är en expert på svenska vinimportörer och vinmarknaden. Baserat på följande sökkriterier, ge mig 5 svenska vinimportörer som bäst matchar.

Sökkriterier: "${query}"

För varje importör, ge följande information i JSON-format:

{
  "importers": [
    {
      "name": "Importörens namn",
      "description": "Kort beskrivning (2-3 meningar) om importörens profil och specialitet",
      "specialties": ["Specialitet 1", "Specialitet 2", "Specialitet 3"],
      "focusRegions": ["Region 1", "Region 2", "Region 3"],
      "priceRange": "Budget/Medium/Premium/Luxury",
      "portfolioSize": "Cirka antal viner i sortiment (t.ex. '300+ viner')",
      "strengths": ["Styrka 1", "Styrka 2", "Styrka 3"],
      "bestFor": "Vad de är bäst för (t.ex. 'Bordeaux-älskare', 'Budgetmedvetna', 'Premium italienska viner')",
      "contact": {
        "website": "webbadress (om känd)",
        "phone": "telefonnummer (om känt)",
        "email": "e-postadress (om känd)"
      },
      "topWines": [
        {
          "name": "Ett känt vin från deras sortiment",
          "producer": "Producent",
          "price": "Ca-pris i SEK"
        }
      ]
    }
  ]
}

VIKTIGT:
1. Ge VERKLIGA svenska vinimportörer (t.ex. Philipson Söderberg, Wineworld, Kobrand, Domaine Select, Vinguiden, etc.)
2. Matcha importörer baserat på kriterierna (land, prisklass, typ av vin, etc.)
3. Sortera efter hur väl de matchar kriterierna (bästa matchen först)
4. Ge realistisk information om varje importör
5. Om kriterier inkluderar specifika regioner/länder, prioritera importörer som är starka där

Exempel på kända svenska vinimportörer:
- Philipson Söderberg (Premium, Frankrike, Italien)
- Wineworld (Bred portfolio, alla prisklasser)
- Kobrand (Exklusivt, champagne, toppviner)
- Domaine Select (Boutique-producenter, kvalitet)
- Vinguiden (Italien, Frankrike, medelpris)
- Bibendum Wine (Storbritannien, klassiska viner)
- Terroir Wines (Naturviner, biodynamiskt)
- Nordic Wine Group (Skandinavisk profil)

KRITISKA REGLER:
1. Matcha importörer EXAKT till kriterierna
2. Om "italienska viner" - ge importörer som FRÄMST fokuserar på Italien (inte bara har några italienska viner)
3. Om "budget" - ge importörer kända för bra pris/kvalitet-förhållande
4. Om "premium" - ge exklusiva importörer
5. Ge VERKLIGA svenska importörer med korrekt information

Svara ENDAST med välformaterad JSON. Ingen annan text.`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Du är en expert på svenska vinimportörer och vinmarknaden. Svara alltid med välformaterad JSON. Matcha importörer EXAKT till kriterierna.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.5,
      max_tokens: 2500,
    });

    const responseText = completion.choices[0].message.content;
    
    if (!responseText) {
      throw new Error("No response from OpenAI");
    }

    let result;
    try {
      const cleanedResponse = responseText
        .replace(/```json\n?/g, "")
        .replace(/```\n?/g, "")
        .trim();
      result = JSON.parse(cleanedResponse);
    } catch (parseError) {
      console.error("Failed to parse OpenAI response:", responseText);
      throw new Error("Failed to parse importer recommendations");
    }

    // Cache the result
    cacheSearchResult(query, { importers: result.importers }, {}, 'find-importers');

    return NextResponse.json({
      ...result,
      cached: false
    });
  } catch (error) {
    console.error("Error in find importers:", error);
    return NextResponse.json(
      { error: "Failed to find importers" },
      { status: 500 }
    );
  }
}

