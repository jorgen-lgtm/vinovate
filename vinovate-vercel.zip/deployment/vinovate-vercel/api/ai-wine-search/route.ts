import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { 
  getCachedResult, 
  cacheSearchResult, 
  recordCacheHit, 
  recordCacheMiss 
} from "@/lib/searchCache";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(request: NextRequest) {
  let query: string = '';
  let preferQuick: boolean = true;
  let maxResults: number = 5;
  
  try {
    const requestData = await request.json();
    query = requestData.query;
    preferQuick = requestData.preferQuick ?? true;
    maxResults = requestData.maxResults ?? 5;

    if (!query || query.trim().length === 0) {
      return NextResponse.json(
        { error: "Sökfråga krävs" },
        { status: 400 }
      );
    }

    console.log("AI Wine Search called with:", { query, preferQuick, maxResults });

    // Check cache first
    const cacheKey = `${query}-${preferQuick}-${maxResults}`;
    const cached = getCachedResult(cacheKey, { preferQuick, maxResults }, 'ai-wine');
    if (cached && cached.results.wines) {
      recordCacheHit();
      return NextResponse.json({ 
        wines: cached.results.wines,
        cached: true,
        hitCount: cached.hitCount,
        query: query,
        aiGenerated: true
      });
    }
    
    recordCacheMiss();

    // Infer desired wine type from query (sv/en)
    const q = query.toLowerCase();
    
    // Explicit wine type mentions
    const wantsWhite = /(vitt|white)/.test(q);
    const wantsRed = /(rött|rott|red)/.test(q);
    const wantsRose = /(rosé|rose)/.test(q);
    const wantsSparkling = /(mousserande|champagne|cava|prosecco|sparkling)/.test(q);
    
    // Context-based inference
    const redWineContext = /(barolo|amarone|brunello|chianti|bordeaux|cabernet|merlot|syrah|primitivo|montepulciano|nebbiolo|barbera|valpolicella|viltkött|vilt|oxfilé|lammstek|gryta|ragu|kraftfullt|fylligt)/.test(q);
    const whiteWineContext = /(chablis|sancerre|riesling|sauvignon blanc|chardonnay|albariño|pinot grigio|fisk|skaldjur|ostron)/.test(q);
    
    // Specific wine/region mentions for AI prompt enhancement
    const specificWineMentions = {
      barolo: { country: "Italien", region: "Piemonte", type: "Rött vin" },
      amarone: { country: "Italien", region: "Veneto", type: "Rött vin" },
      brunello: { country: "Italien", region: "Toscana", type: "Rött vin" },
      chianti: { country: "Italien", region: "Toscana", type: "Rött vin" },
      bordeaux: { country: "Frankrike", region: "Bordeaux", type: "Rött vin" },
      chablis: { country: "Frankrike", region: "Bourgogne", type: "Vitt vin" },
      sancerre: { country: "Frankrike", region: "Loire", type: "Vitt vin" }
    };
    
    let specificWine = null;
    for (const [wineName, wineInfo] of Object.entries(specificWineMentions)) {
      if (q.includes(wineName)) {
        specificWine = wineInfo;
        break;
      }
    }
    
    let strictTypeRule = "";
    let specificWineRule = "";
    
    if (specificWine) {
      specificWineRule = `FOKUSERA PÅ ${specificWine.type.toUpperCase()} FRÅN ${specificWine.country.toUpperCase()}, SÄRSKILT ${specificWine.region.toUpperCase()}-REGIONEN.`;
    }
    
    if (wantsWhite) strictTypeRule = "RETURNA ENDAST 'Vitt vin'.";
    else if (wantsRed) strictTypeRule = "RETURNA ENDAST 'Rött vin'.";
    else if (wantsRose) strictTypeRule = "RETURNA ENDAST 'Rosévin'.";
    else if (wantsSparkling) strictTypeRule = "RETURNA ENDAST 'Mousserande vin'.";
    else if (redWineContext && !wantsWhite && !wantsSparkling && !wantsRose) strictTypeRule = "RETURNA ENDAST 'Rött vin'.";
    else if (whiteWineContext && !wantsRed && !wantsSparkling && !wantsRose) strictTypeRule = "RETURNA ENDAST 'Vitt vin'.";

    // Enhanced prompt for better AI responses
    const prompt = `Du är en expert på vin och matpairing med djup kunskap om svenska Systembolaget. Baserat på följande beskrivning, ge mig ${maxResults} specifika vinrekommendationer sorterade efter BETYG (högsta först).

BESKRIVNING: "${query}"

PRIORITERING: ${preferQuick ? 
  "Fokusera på viner som vanligtvis finns tillgängliga på Systembolaget i Sverige (snabb tillgänglighet)" : 
  "Fokusera på högkvalitativa viner med bra betyg, oavsett tillgänglighet (premium kvalitet)"}

 VIKTIGA REGLER:
1. Ge ENDAST verkliga, kända viner som faktiskt finns på Systembolaget eller hos svenska importörer
2. Sortera efter BETYG (högsta först)
3. Var SPECIFIK med priser, betyg och tillgänglighet
4. Inkludera både Systembolaget och privatimport-alternativ där möjligt
5. Ge detaljerade matpairing-förslag med recept
${strictTypeRule ? `6. ${strictTypeRule}` : ""}
${specificWineRule ? `7. ${specificWineRule}` : ""}

För varje vin, ge följande information i EXAKT JSON-format:

{
  "wines": [
    {
      "name": "Exakt namn på vinet",
      "producer": "Producentens namn",
      "type": "Rött vin/Vitt vin/Rosé/Mousserande",
      "country": "Land",
      "region": "Region (t.ex. Bordeaux, Toscana, Rioja)",
      "year": "Årgång (eller null)",
      "price": Pris i SEK (siffra),
      "rating": Betyg 1-100 (siffra),
      "description": "Detaljerad beskrivning av vinet (2-3 meningar)",
      "foodPairing": ["Maträtt 1", "Maträtt 2", "Maträtt 3"],
      "foodPairingDetails": [
        {
          "dish": "Namn på rätten",
          "description": "Beskrivning av rätten",
          "why": "Varför detta vin passar till rätten",
          "recipe": "Komplett recept med ingredienser och instruktioner"
        }
      ],
      "tastingNotes": "Detaljerade provningsanteckningar",
      "servingTemperature": "Rekommenderad serveringstemperatur",
      "bestDrinkingPeriod": "När vinet är bäst att dricka",
      "alcoholContent": "Alkoholhalt (t.ex. 13.5%)",
      "volume": "Volym (t.ex. 750ml)",
      "availability": "${preferQuick ? 'quick' : 'better'}",
      "systembolagetNumber": "Artikelnummer om känt (annars null)",
      "imageUrl": null,
      "purchaseLocations": [
        {
          "name": "Systembolaget",
          "type": "store",
          "url": "https://www.systembolaget.se",
          "stock": "Tillgänglighet",
          "price": Pris i SEK,
          "isPrivateImport": false
        },
        {
          "name": "Importörsnamn",
          "type": "private-import",
          "url": "https://importor.se",
          "stock": "I lager",
          "price": Pris hos importör,
          "savings": Besparing vs Systembolaget,
          "isPrivateImport": true,
          "minimumOrder": "Minsta beställning",
          "importerContact": {
            "email": "kontakt@importor.se",
            "phone": "08-XXX XX XX",
            "orderUrl": "https://importor.se/bestall"
          }
        }
      ]
    }
  ]
}

Svara ENDAST med välformaterad JSON. Inga andra kommentarer eller förklaringar.`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Du är en professionell sommelierexpert med specialisering på svenska Systembolaget. Svara alltid med välformaterad JSON. Ge verkliga viner med korrekt information.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.3, // Lower temperature for more consistent results
      max_tokens: 4000,
    });

    const responseText = completion.choices[0].message.content;
    
    if (!responseText) {
      throw new Error("Inget svar från OpenAI");
    }

    // Parse the JSON response
    let data;
    try {
      // Remove markdown code blocks if present
      const cleanedResponse = responseText
        .replace(/```json\n?/g, "")
        .replace(/```\n?/g, "")
        .trim();
      data = JSON.parse(cleanedResponse);
    } catch (parseError) {
      console.error("Failed to parse OpenAI response:", responseText);
      throw new Error("Kunde inte tolka AI-svaret");
    }

    // Validate response structure
    if (!data.wines || !Array.isArray(data.wines)) {
      throw new Error("AI returnerade felaktigt format");
    }

    // Ensure we have the right number of results and enforce requested type
    let wines = data.wines as any[];
    const typeMatches = (t?: string) => {
      const tt = (t || "").toLowerCase();
      
      // Explicit type requirements
      if (wantsWhite) return tt.includes("vitt") || tt.includes("white");
      if (wantsRed) return tt.includes("rött") || tt.includes("rott") || tt.includes("red");
      if (wantsRose) return tt.includes("rosé") || tt.includes("rose");
      if (wantsSparkling) return tt.includes("mousserande") || tt.includes("champagne") || tt.includes("sparkling");
      
      // Context-based requirements
      if (redWineContext && !wantsWhite && !wantsSparkling && !wantsRose) {
        return tt.includes("rött") || tt.includes("rott") || tt.includes("red");
      }
      if (whiteWineContext && !wantsRed && !wantsSparkling && !wantsRose) {
        return tt.includes("vitt") || tt.includes("white");
      }
      
      return true;
    };
    wines = wines.filter((w) => typeMatches(w.type)).slice(0, maxResults);

    // Cache the result
    cacheSearchResult(cacheKey, { wines }, { preferQuick, maxResults }, 'ai-wine');

    return NextResponse.json({ 
      wines: wines,
      cached: false,
      query: query,
      aiGenerated: true,
      message: `AI-genererade ${wines.length} vinrekommendationer baserat på: "${query}"`
    });

  } catch (error) {
    console.error("Error in AI wine search:", error);
    
    // Check if we have valid query data for fallback
    if (!query) {
      return NextResponse.json(
        { error: "Ogiltig begäran" },
        { status: 400 }
      );
    }
    
    // Fallback to simple search if AI fails
    try {
      const fallbackResponse = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/api/search-wine-simple`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, preferQuick })
      });
      
      if (fallbackResponse.ok) {
        const fallbackData = await fallbackResponse.json();
        return NextResponse.json({
          ...fallbackData,
          aiGenerated: false,
          message: "AI-sökning misslyckades, visar grundläggande resultat"
        });
      }
    } catch (fallbackError) {
      console.error("Fallback search also failed:", fallbackError);
    }

    return NextResponse.json(
      { 
        error: "Kunde inte söka efter viner just nu. Försök igen senare.",
        details: error instanceof Error ? error.message : "Okänt fel"
      },
      { status: 500 }
    );
  }
}
