import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { 
  getCachedResult, 
  cacheSearchResult, 
  recordCacheHit, 
  recordCacheMiss 
} from "@/lib/searchCache";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(request: NextRequest) {
  try {
    const { query, preferQuick } = await request.json();

    if (!query) {
      return NextResponse.json(
        { error: "Query is required" },
        { status: 400 }
      );
    }

    // Check cache first
    const cached = getCachedResult(query, { preferQuick }, 'wine');
    if (cached && cached.results.wines) {
      recordCacheHit();
      return NextResponse.json({ 
        wines: cached.results.wines,
        cached: true,
        hitCount: cached.hitCount
      });
    }
    
    recordCacheMiss();

    // Check if user is searching for wine to go with specific food
    const foodKeywords = ['pasta', 'biff', 'kött', 'fisk', 'kyckling', 'lamm', 'ost', 'skaldjur', 
                          'sushi', 'pizza', 'grillat', 'carbonara', 'bolognese', 'lasagne'];
    const queryLower = query.toLowerCase();
    const mentionedFoods = foodKeywords.filter(food => queryLower.includes(food));
    const hasSpecificFood = mentionedFoods.length > 0;
    
    // Use OpenAI to get wine recommendations
    const prompt = `Du är en expert på vin och matpairing. Baserat på följande förfrågan, ge mig 5 specifika vinrekommendationer sorterade efter BETYG (högsta först).
    
Förfrågan: "${query}"
Prioritering: ${preferQuick ? "Fokusera på viner som vanligtvis finns tillgängliga på Systembolaget i Sverige" : "Fokusera på högkvalitativa viner med bra betyg, oavsett tillgänglighet"}

${hasSpecificFood ? `VIKTIGT: Användaren söker vin till specifik(a) maträtt(er): ${mentionedFoods.join(', ')}. 
I foodPairingDetails, inkludera ENDAST recept och förslag för dessa maträtter (${mentionedFoods.join(', ')}).
Ge detaljerade, rustika recept specifikt för dessa rätter.` : ''}

För varje vin, ge mig följande information i JSON-format:
- name: Namnet på vinet
- producer: Producenten
- type: Typ av vin (t.ex. "Rött vin", "Vitt vin", "Rosé", "Mousserande")
- country: Land
- region: Region (om tillgänglig)
- year: Årgång (om relevant, annars null)
- price: Ungefärligt pris i SEK (om känt, annars null)
- rating: Betyg 1-100 (om känt, annars null)
- description: En kort beskrivning av vinet (2-3 meningar)
- foodPairing: Array med 3-5 maträtter som passar till vinet
- foodPairingDetails: Array med minst 4 objekt som innehåller:
  {
    "dish": "Namn på rätten (gärna rustikt, t.ex. 'Långkokt lammgryta', 'Rostbiff med rotfrukter')",
    "description": "Kort beskrivning av rätten och dess karaktär",
    "why": "Detaljerad förklaring varför detta vin passar till rätten (smakprofiler, strukturer)",
    "recipe": "Komplett RUSTIKT recept med:\n- Ingredienser (4 portioner)\n- Steg-för-steg instruktioner\n- Tillagningsid\n- Pro-tips för bästa resultat"
  }
  
VIKTIGT: Ge RUSTIKA, klassiska recept med fyllig smak som passar till vinet. Exempel: långkok, grytor, stekt kött, hemlagat bröd, rotfrukter.
- tastingNotes: Senaste provningsanteckningar om tillgängliga (beskrivning av smak, doft, etc.)
- servingTemperature: Rekommenderad serveringstemperatur
- bestDrinkingPeriod: När vinet är bäst att dricka
- imageUrl: null (vi hanterar detta senare)
- systembolagetNumber: Artikelnummer på Systembolaget om känt (annars null)
- availability: "${preferQuick ? 'quick' : 'better'}"
- purchaseLocations: Array med minst 3 inköpsställen, t.ex.:
  [
    { 
      "name": "Importörens namn", 
      "type": "private-import", 
      "url": "https://importorwebbplats.se", 
      "stock": "I lager",
      "price": Pris hos importör (ofta billigare),
      "savings": Hur mycket man sparar vs Systembolaget,
      "isPrivateImport": true,
      "minimumOrder": "Minsta beställning (t.ex. '6 flaskor', '1 kartong')",
      "importerContact": {
        "email": "kontakt@importor.se",
        "phone": "08-XXX XX XX",
        "orderUrl": "https://importor.se/bestall"
      }
    },
    { "name": "Systembolaget", "type": "store", "url": "https://www.systembolaget.se", "stock": "Finns i de flesta butiker" },
    { "name": "Systembolaget Online", "type": "online", "url": "https://www.systembolaget.se", "stock": "Beställningsvara" }
  ]

VIKTIGT om privatimport:
- Svenska importörer kan sälja direkt till konsument (privatimport)
- Ofta billigare än Systembolaget
- Kan kräva minimiorder (t.ex. 6 flaskor, 1 kartong = 12 flaskor)
- Leverans till dörren
- Ge realistiska svenska importörer som erbjuder privatimport

KRITISKA REGLER:
1. Sortera vinerna efter BETYG (högsta först)
2. RESPEKTERA prisklassen EXAKT - om "200-300 kr" anges, ge ENDAST viner i det spannet
3. RESPEKTERA landet/regionen EXAKT - om "Italien" anges, ge ENDAST italienska viner
4. Ge verkliga, kända viner med korrekt information
5. Var SPECIFIK och KORREKT med priser och betyg

Svara ENDAST med en JSON-array med EXAKT 5 vinobjekt sorterade efter betyg. Inga andra kommentarer eller förklaringar.`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Du är en professionell sommelierexpert. Svara alltid med välformaterad JSON. Följ EXAKT användarens filter och kriterier.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.5,  // Lowered from 0.7 for more consistent results
      max_tokens: 3000,  // Limit response size for faster results
    });

    const responseText = completion.choices[0].message.content;
    
    if (!responseText) {
      throw new Error("No response from OpenAI");
    }

    // Parse the JSON response
    let wines;
    try {
      // Remove markdown code blocks if present
      const cleanedResponse = responseText
        .replace(/```json\n?/g, "")
        .replace(/```\n?/g, "")
        .trim();
      wines = JSON.parse(cleanedResponse);
    } catch (parseError) {
      console.error("Failed to parse OpenAI response:", responseText);
      throw new Error("Failed to parse wine recommendations");
    }

    // Enrich with Systembolaget data if available
    const enrichedWines = await Promise.all(
      wines.map(async (wine: any) => {
        try {
          // Try to fetch from Systembolaget API
          const systembolagetData = await fetchSystembolagetData(wine.name, wine.producer);
          if (systembolagetData) {
            return {
              ...wine,
              imageUrl: systembolagetData.imageUrl,
              price: systembolagetData.price || wine.price,
              systembolagetNumber: systembolagetData.productNumber,
            };
          }
        } catch (error) {
          console.error("Failed to fetch Systembolaget data:", error);
        }
        return wine;
      })
    );

    // Cache the result
    cacheSearchResult(query, { wines: enrichedWines }, { preferQuick }, 'wine');

    return NextResponse.json({ 
      wines: enrichedWines,
      cached: false 
    });
  } catch (error) {
    console.error("Error in wine search:", error);
    console.error("Error details:", {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    });
    return NextResponse.json(
      { error: "Failed to search for wines", details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

async function fetchSystembolagetData(wineName: string, producer?: string): Promise<{
  imageUrl?: string;
  price?: number;
  productNumber?: string;
} | null> {
  try {
    // Import the Systembolaget API function
    const { fetchSystembolagetProduct } = await import('@/lib/systembolaget');
    
    // Fetch real data from Systembolaget API
    const systembolagetData = await fetchSystembolagetProduct(wineName, producer);
    
    if (systembolagetData) {
      return {
        imageUrl: systembolagetData.imageUrl,
        price: systembolagetData.price,
        productNumber: systembolagetData.productNumber,
      };
    }
    
    return null;
  } catch (error) {
    console.error("Systembolaget API error:", error);
    return null;
  }
}

