"use client";

import { useState } from "react";
import WineSearch from "@/components/WineSearch";
import WineModal from "@/components/WineModal";
import Footer from "@/components/Footer";
import { Wine } from "@/types/wine";
import { getSeasonalGreeting } from "@/lib/seasonalExamples";
import SponsoredBanner from "@/components/SponsoredBanner";
import SponsoredSidebar from "@/components/SponsoredSidebar";
import { getBannerSponsors, getSidebarSponsors } from "@/data/sponsoredImporters";

export default function Home() {
  const [selectedWine, setSelectedWine] = useState<Wine | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const seasonalGreeting = getSeasonalGreeting();
  
  // Get sponsored content
  const bannerSponsors = getBannerSponsors();
  const sidebarSponsors = getSidebarSponsors();

  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-900 via-wine-800 to-red-900">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <h1 className="text-6xl font-bold text-white mb-4 tracking-tight">
            🍷 Vinovate
          </h1>
          <p className="text-2xl text-purple-100 mb-3 font-semibold">
            Där passion möter innovation
          </p>
          <p className="text-lg text-purple-200 mb-2">
            Upptäck ditt perfekta vin med AI-driven precision
          </p>
          <p className="text-sm text-purple-300 italic">
            {seasonalGreeting}
          </p>
        </header>

        <div className="max-w-7xl mx-auto">
          {/* Banner ad - Full width across top */}
          {bannerSponsors.length > 0 && (
            <div className="mb-6">
              <SponsoredBanner sponsor={bannerSponsors[0]} />
            </div>
          )}
          
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Main content area */}
            <div className="lg:col-span-3">
              <WineSearch 
                onWineSelect={setSelectedWine} 
                externalQuery={searchQuery}
                onQueryChange={setSearchQuery}
              />
            </div>
            
            {/* Sidebar with ads */}
            <div className="lg:col-span-1">
              <div className="sticky top-4">
                <SponsoredSidebar sponsors={sidebarSponsors} />
              </div>
            </div>
          </div>
        </div>

        {selectedWine && (
          <WineModal
            wine={selectedWine}
            onClose={() => setSelectedWine(null)}
          />
        )}
        
        
        <Footer />
      </div>
    </main>
  );
}
