export type Season = 'spring' | 'summer' | 'autumn' | 'winter';

export interface SeasonalExample {
  query: string;
  icon?: string;
}

export const seasonalExamples = {
  spring: [
    "Fräscht vitt vin till vårsallad",
    "Rosé till terassen",
    "Lätt rött vin till lamm",
    "Prosecco till brunch",
    "Vårlig Sauvignon Blanc",
  ],
  summer: [
    "Kallskänkt rosé till sommar",
    "Fräsch Albariño till skaldjur",
    "Mousserande till midsommar",
    "Vitt vin till grillad fisk",
    "Lätt rött till grill under 150 kr",
  ],
  autumn: [
    "Rött vin till viltkött",
    "Barolo till svampragu",
    "Kraftfullt vin till höstgryta",
    "Amarone till viltfond",
    "Bordeaux till oxfilé",
  ],
  winter: [
    "Fylligt rött vin till julbord",
    "Portvin till dessert",
    "Kraftig Syrah till lammstek",
    "Barolo till hjortfilé",
    "Varmt vin till glögg",
  ],
};

/**
 * Get current season based on month
 */
export function getCurrentSeason(): Season {
  const month = new Date().getMonth() + 1; // 1-12
  
  if (month >= 3 && month <= 5) return 'spring';    // Mars-Maj
  if (month >= 6 && month <= 8) return 'summer';    // Juni-Augusti
  if (month >= 9 && month <= 11) return 'autumn';   // September-November
  return 'winter';                                   // December-Februari
}

/**
 * Get seasonal examples
 */
export function getSeasonalExamples(): SeasonalExample[] {
  const season = getCurrentSeason();
  const examples = seasonalExamples[season];
  
  // Add seasonal context
  const seasonNames = {
    spring: '🌸 Vår',
    summer: '☀️ Sommar',
    autumn: '🍂 Höst',
    winter: '❄️ Vinter',
  };
  
  return examples.map(query => ({
    query,
    icon: getSeasonIcon(season),
  }));
}

/**
 * Get season icon
 */
function getSeasonIcon(season: Season): string {
  const icons = {
    spring: '🌸',
    summer: '☀️',
    autumn: '🍂',
    winter: '❄️',
  };
  return icons[season];
}

/**
 * Get season name in Swedish
 */
export function getSeasonName(): string {
  const season = getCurrentSeason();
  const names = {
    spring: 'Vår',
    summer: 'Sommar',
    autumn: 'Höst',
    winter: 'Vinter',
  };
  return names[season];
}

/**
 * Get seasonal greeting
 */
export function getSeasonalGreeting(): string {
  const season = getCurrentSeason();
  const greetings = {
    spring: 'Välkommen till våren! Upptäck fräscha viner för säsongen.',
    summer: 'Sommarens bästa viner väntar! Hitta perfekt vin till grillen.',
    autumn: 'Höstens viner är här! Kraftfulla röda till säsongens rätter.',
    winter: 'Vinterens värme i glaset! Hitta fylliga viner till kalla kvällar.',
  };
  return greetings[season];
}

